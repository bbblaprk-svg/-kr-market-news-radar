"""PULSE EDGE V12.6 - leaf sector FIRST decision gate.

Core invariant: leaf S2/S3 MUST be computed from each primary process-group's
own verified LS OpenAPI observations and comparable 3-frame traded-value history.
No parent-state, anchor, theme-tag or individual-stock score may promote it.
All traded value describes activity, NOT net inflow.
"""
from __future__ import annotations
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from statistics import median
from engine_ls_core import (KST, COVERAGE_MIN, DEEP_FRESH_SEC, clean_row, frame_gate,
                    fresh, is_common_stock, number, timeparse, truth, source_ok)
from taxonomy_v123 import LEAVES, PARENTS, VERSION, attach_taxonomy, safe_code
from risk_v1262 import derive_levels

RELEASE='PULSE_EDGE_V12_7_3_LS_PROVIDER_EARLY_ROTATION_FIRST'
S_ORDER={'S3':0,'S2':1,'S5':2,'S4':3,'S1':4,'S0':5,'DATA_LOST':6,
         'INSUFFICIENT_COVERAGE':7,'THIN_SECTOR_OBSERVE':8,'NO_VERIFIED_MEMBERS':9}
MIN_MEMBERS=3
MIN_TURNOVER_PER_MINUTE_KRW=50_000_000
SECTOR_MICRO_FRESH_SEC=30
ENTRY_EVIDENCE_TTL_SEC=DEEP_FRESH_SEC

DISPLAY_STAGE_ORDER={'EARLY_ROTATION':0,'S2_MONEY_MOVE':1,'S3_CONFIRMED':2,'WEAKENING':3,'S5_EXIT':4,'OVERHEATED':5,'OTHER':6,'DATA_UNVERIFIED':7}

def _gate_progress(checks):
    known=[v for v in checks if v is not None]
    if not known:return None
    return round(100*sum(bool(v) for v in known)/len(checks),1) if len(known)==len(checks) else None

def _rotation_display(state, *, complete, relative, share_growth, shift_pp, breadth, adv_count, leader_share, rs, rs_velocity, diffusion_growth, previous_relative=None, rs_acceleration=None, buy_count=None, hold_count=None):
    """Display-only rotation stage. It NEVER changes S2/S3 eligibility or ENTRY gates."""
    s2_checks=[
        relative is not None and relative>=1.2 if relative is not None else None,
        share_growth is not None and share_growth>=1.15 if share_growth is not None else None,
        shift_pp is not None and shift_pp>0 if shift_pp is not None else None,
        breadth is not None and breadth>=.50 if breadth is not None else None,
        adv_count>=2 if adv_count is not None else None,
        leader_share is not None and leader_share<=.80 if leader_share is not None else None,
        rs is not None and rs>=0 if rs is not None else None,
        rs_velocity is not None and rs_velocity>=0 if rs_velocity is not None else None,
        diffusion_growth is not None and diffusion_growth>=0 if diffusion_growth is not None else None,
    ]
    s3_checks=[
        relative is not None and relative>=1.4 if relative is not None else None,
        previous_relative is not None and previous_relative>=1.2 if previous_relative is not None else None,
        share_growth is not None and share_growth>=1.25 if share_growth is not None else None,
        shift_pp is not None and shift_pp>0 if shift_pp is not None else None,
        breadth is not None and breadth>=.55 if breadth is not None else None,
        adv_count>=2 if adv_count is not None else None,
        leader_share is not None and leader_share<=.70 if leader_share is not None else None,
        rs is not None and rs>0 if rs is not None else None,
        rs_velocity is not None and rs_velocity>0 if rs_velocity is not None else None,
        diffusion_growth is not None and diffusion_growth>=0 if diffusion_growth is not None else None,
        rs_acceleration is not None and rs_acceleration>=-.002 if rs_acceleration is not None else None,
        buy_count is not None and buy_count>=2 and hold_count is not None and hold_count>=2 if buy_count is not None and hold_count is not None else None,
    ]
    s2_progress=_gate_progress(s2_checks);s3_progress=_gate_progress(s3_checks)
    if state=='S3':stage='S3_CONFIRMED'
    elif state=='S2':stage='S2_MONEY_MOVE'
    elif state=='S5':stage='S5_EXIT'
    elif state=='S4':stage='OVERHEATED'
    elif not complete:stage='DATA_UNVERIFIED'
    elif (state=='S1' and s2_progress is not None and s2_progress>=66.7 and
          share_growth is not None and share_growth>=1.05 and shift_pp is not None and shift_pp>0 and
          breadth is not None and breadth>=.40 and rs is not None and rs>=0 and
          rs_velocity is not None and rs_velocity>=0):stage='EARLY_ROTATION'
    elif (state in ('S0','S1') and share_growth is not None and share_growth<1 and
          rs_velocity is not None and rs_velocity<0 and breadth is not None and breadth<.50):stage='WEAKENING'
    else:stage='OTHER'
    return stage,s2_progress,s3_progress

def _rotation_sort_key(a):
    return (DISPLAY_STAGE_ORDER.get(a.get('rotation_stage'),99),
            -(a.get('s2_gate_progress_pct') or -1),
            -(a.get('s3_gate_progress_pct') or -1),
            -(a.get('nonmega_share_growth') or -1),
            -(a.get('relative_turnover') or -1),
            a.get('sector') or '')


def _matching_history(a,b):
    if not isinstance(a,dict) or not isinstance(b,dict) or not source_ok(a) or not source_ok(b):
        return False
    t=timeparse(a.get('generated_at'));p=timeparse(b.get('generated_at'))
    if not t or not p or t.astimezone(KST).date()!=p.astimezone(KST).date():return False
    if a.get('venue')!=b.get('venue') or a.get('session')!=b.get('session'):return False
    if not (30 <= (t-p).total_seconds() <= 900):return False
    # Every frame needs to belong to a real active identical session.
    from engine_ls_core import session
    return session(a.get('venue'),t)==a.get('session') and session(b.get('venue'),p)==b.get('session')


def _code_rows(frame):
    if not isinstance(frame,dict) or not isinstance(frame.get('stocks'),list):return None
    data={}
    for r in frame['stocks']:
        if not isinstance(r,dict):return None
        k=safe_code(r.get('code'))
        if k in data or not k:return None
        data[k]=r
    return data


def _safe_float_map(frame,key):
    v=frame.get(key)
    return v if isinstance(v,dict) else {}


def _empty(frame,now):
    return dict(release=RELEASE,taxonomy_version=VERSION,as_of=now.isoformat(),
        source='LS_OPENAPI_ONLY',venue=frame.get('venue') if isinstance(frame,dict) else None,
        session=frame.get('session') if isinstance(frame,dict) else None,
        data_status=frame_gate(frame,now),sectors=[],leaf_money=[],parent_money=[],
        candidates=[],qualified_count=0,classification={},warnings=[],alerts=[],
        hard_gate='FINE_SECTOR_MONEY_FLOW_GATE',rotation_observation='TRADED_VALUE_SHARE_NOT_NET_FLOW')


def scan_fine_first(frame,previous=None,older=None,now=None,reviewed=None,baseline=None,previous_states=None):
    now=now or datetime.now(timezone.utc)
    result=_empty(frame,now)
    if result['data_status']!='LIVE_FRAME':return result
    reviewed=reviewed or {}
    previous_states=previous_states or {}
    baseline=baseline if isinstance(baseline,dict) and baseline.get('provenance')=='LOCAL_COMPUTED_FROM_LS_ARCHIVE' else {}
    current=_code_rows(frame);prev=_code_rows(previous);prev2=_code_rows(older)
    if current is None:
        result['data_status']='LS INVALID_CURRENT_SYMBOLS';return result
    x=attach_taxonomy(frame,reviewed)
    clean=[clean_row(r,x,now) for r in x['stocks']]
    rows=[r for r in clean if r and is_common_stock(r)]
    observed=set(r['code'] for r in rows)
    classified={r['code'] for r in rows if r['primary_leaf'] in LEAVES or r['is_mega_anchor']}
    total=frame.get('eligible_universe_total')
    if type(total)!=int or total<=0:total=None
    coverage=len(rows)/total if total else 0
    universe_complete=bool(frame.get('taxonomy_universe_confirmed') is True and total and len(rows)==total
          and len(classified)==len(rows) and frame.get('trading_day_confirmed') is True)
    result['classification']={'observed_eligible':len(rows),'eligible_universe_total':total,
        'reviewed_nonanchor':sum(r['primary_leaf'] in LEAVES and not r['is_mega_anchor'] for r in rows),
        'anchor_count':sum(bool(r['is_mega_anchor']) for r in rows),
        'unclassified_count':len(rows)-len(classified), 'coverage_ratio':round(coverage,5),
        'full_taxonomy_universe_verified':universe_complete}
    # A previous/older sample with different members changes denominators. No rotation judgment.
    historical=(_matching_history(frame,previous) and _matching_history(previous,older)
        and prev is not None and prev2 is not None
        and set(current)==set(prev)==set(prev2))
    if historical:
        dt1=(timeparse(frame['generated_at'])-timeparse(previous['generated_at'])).total_seconds()
        dt2=(timeparse(previous['generated_at'])-timeparse(older['generated_at'])).total_seconds()
        historical=abs(dt1-dt2)/max(dt1,dt2)<=0.20
    else:dt1=0;dt2=0
    good_history=bool(historical and universe_complete and
        previous.get('taxonomy_universe_confirmed') is True and
        older.get('taxonomy_universe_confirmed') is True and
        previous.get('eligible_universe_total')==total and older.get('eligible_universe_total')==total)
    # V12.6: NEVER trust external baseline_verified flags or strength values.
    # Only a locally rebuilt 20 trading-day archive can produce these references.
    baseline_valid=bool(baseline.get('verified') is True and baseline.get('venue')==frame.get('venue')
        and baseline.get('session')==frame.get('session') and baseline.get('taxonomy_version')==VERSION)
    baseline_strength=baseline.get('current_strength',{}) if baseline_valid else {}
    prev_baseline_valid=baseline_valid
    prior_strength=baseline.get('previous_strength',{}) if baseline_valid else {}
    days=baseline.get('days',{}) if baseline_valid else {}
    # Never let remote member_total assertions set a leaf denominator.
    # Counts are derived from the currently full, locally reviewed eligible universe.
    totals=defaultdict(int)
    if universe_complete:
        for r in rows:
            if r['primary_leaf'] in LEAVES and not r['is_mega_anchor']:
                totals[r['primary_leaf']]+=1
    benchmark_scope=f"{frame.get('venue')}:{frame.get('session')}"
    benchmark_verified=(frame.get('benchmark_scope')==benchmark_scope and number(frame.get('market_return')) is not None)
    if not universe_complete:result['warnings'].append('MASTER_OR_CLASSIFICATION_INCOMPLETE__NO_PROMOTION')
    if not historical:result['warnings'].append('NEED_THREE_MATCHED_SAME_SESSION_FRAMES')
    if not baseline_valid:result['warnings'].append('NEED_VERIFIED_SAME_TIME_20D_BASELINE')
    if not benchmark_verified:result['warnings'].append('BENCHMARK_VENUE_SESSION_NOT_VERIFIED')

    delta_current={};delta_prior={};invalid_deltas=set()
    if historical:
        for r in rows:
            k=r['code'];a=r['_turnover'];b=number(prev[k].get('turnover_cum'))
            c=number(prev2[k].get('turnover_cum'))
            # Strict: reset or a dropped cumulative observation poisons the relevant leaf.
            if a is None or b is None or c is None or min(a,b,c)<0 or not (a>=b>=c):
                invalid_deltas.add(k);continue
            delta_current[k]=a-b;delta_prior[k]=b-c
    # All eligible rows, incl Samsung anchor, participate in parent totals at most once.
    current_total=sum(delta_current.values());prior_total=sum(delta_prior.values())
    nonmega_current=sum(d for r in rows if not r['is_mega_anchor'] for d in [delta_current.get(r['code'],0)])
    nonmega_prior=sum(d for r in rows if not r['is_mega_anchor'] for d in [delta_prior.get(r['code'],0)])
    per_parent=defaultdict(list);per_leaf=defaultdict(list)
    for r in rows:
        parent=r.get('parent_sector');leaf=r.get('primary_leaf')
        if parent in PARENTS:per_parent[parent].append(r)
        if leaf in LEAVES and not r['is_mega_anchor']:per_leaf[leaf].append(r)
    for parent,ps in per_parent.items():
        gross=sum(delta_current.get(r['code'],0) for r in ps)
        nonmega=sum(delta_current.get(r['code'],0) for r in ps if not r['is_mega_anchor'])
        result['parent_money'].append({'parent_id':parent,'parent':PARENTS[parent],
            'gross_interval_turnover_krw':round(gross),'nonmega_interval_turnover_krw':round(nonmega),
            'mega_interval_turnover_krw':round(gross-nonmega),
            'anchor_share':round(1-nonmega/gross,5) if gross else None,
            'purpose':'CONTEXT_ONLY__NOT_ENTRY_GATE'})
    result['parent_money'].sort(key=lambda v:-v['gross_interval_turnover_krw'])

    good_eligible={}
    for leaf,meta in LEAVES.items():
        members=per_leaf[leaf]
        member_count=totals.get(leaf)
        member_total_valid=(type(member_count)==int and member_count>=len(members) and member_count>=1)
        leaf_coverage=len(members)/member_count if member_total_valid else None
        valid=[r for r in members if r['_valid'] and r['code'] not in invalid_deltas
               and r['code'] in delta_current and r['code'] in delta_prior]
        clean_rate=len(valid)/len(members) if members else 0
        curr=sum(delta_current[r['code']] for r in valid)
        prev_interval=sum(delta_prior[r['code']] for r in valid)
        present=curr/nonmega_current if nonmega_current else None
        past=prev_interval/nonmega_prior if nonmega_prior else None
        shift_pp=(present-past)*100 if present is not None and past is not None else None
        share_growth=present/past if present is not None and past and past>0 else None
        # No broad-sector/parent turnover can be recycled as leaf-level strength.
        relative=number(baseline_strength.get(leaf)) if baseline_valid else None
        previous_relative=number(prior_strength.get(leaf)) if prev_baseline_valid else None
        hist_days=days.get(leaf)
        day_coverage=(type(hist_days)==int and hist_days>=20)
        good_price=[r for r in valid if r['_current_price'] and r['_prev_close'] and r['_prev_close']>0]
        advancing=[r for r in good_price if r['_current_price']>r['_prev_close']]
        breadth=(len(advancing)/len(members)) if members else None
        adv_count=len(advancing)
        delta_pairs=[(r,delta_current[r['code']]) for r in valid if delta_current[r['code']]>0]
        leader_share=max((d for _,d in delta_pairs),default=0)/curr if curr else None
        # Freshness is checked independently for every stock, before S3.
        buy_count=sum(truth(r.get('buy_dominance_verified')) and
            fresh(r.get('micro_event_time'),now,SECTOR_MICRO_FRESH_SEC) for r in good_price)
        hold_count=sum(truth(r.get('price_hold')) and
            fresh(r.get('hold_event_time') or r.get('micro_event_time'),now,SECTOR_MICRO_FRESH_SEC) for r in good_price)
        avg_ret=median([(r['_current_price']/r['_prev_close']-1) for r in good_price]) if good_price else None
        benchmark=number(frame.get('market_return')) if benchmark_verified else None
        rs=avg_ret-benchmark if avg_ret is not None and benchmark is not None else None
        # Cross-section evolution is measured from the same members in 3 same-session frames.
        def historical_rs(point):
            if not isinstance(point,dict) or point.get('benchmark_scope')!=benchmark_scope:
                return None,None
            bench=number(point.get('market_return'))
            rec=_code_rows(point) or {}
            returns=[];advance=0
            for mem in members:
                historic=rec.get(mem['code'],{})
                px=number(historic.get('price'));old=number(historic.get('prev_close'))
                if px is None or old is None or old<=0:return None,None
                returns.append(px/old-1)
                advance+=px>old
            return (median(returns)-bench if bench is not None and returns else None,
                    advance/len(members) if members else None)
        rs_prev, breadth_prev=historical_rs(previous) if historical else (None,None)
        rs_old, breadth_old=historical_rs(older) if historical else (None,None)
        rs_velocity=rs-rs_prev if rs is not None and rs_prev is not None else None
        rs_acceleration=rs-2*rs_prev+rs_old if rs is not None and rs_prev is not None and rs_old is not None else None
        diffusion_growth=breadth-breadth_prev if breadth is not None and breadth_prev is not None else None
        supply_liquidity=curr>=MIN_TURNOVER_PER_MINUTE_KRW*(dt1/60) if dt1 else False
        core_evidence=bool(good_history and member_total_valid and leaf_coverage is not None and leaf_coverage>=COVERAGE_MIN
                 and clean_rate>=COVERAGE_MIN and len(members)>=MIN_MEMBERS and benchmark_verified
                 and prev_interval>0 and share_growth is not None and rs is not None)
        # Exit detection must not be disabled merely because CURRENT turnover fell below the promotion floor.
        # A previously confirmed S2/S3 leaf with intact observations can therefore transition to S5.
        exit_ready=bool(core_evidence and previous_states.get(leaf) in ('S2','S3'))
        exit_signal=bool(exit_ready and share_growth<=.75 and breadth is not None and breadth<.40 and rs<0)
        complete=bool(core_evidence and baseline_valid and prev_baseline_valid and day_coverage and
                 curr>0 and supply_liquidity)
        reasons=[]
        if not good_history:reasons.append('NEED_FULL_THREE_FRAME_COVERAGE')
        if not member_total_valid or (leaf_coverage is not None and leaf_coverage<COVERAGE_MIN):reasons.append('LEAF_MEMBER_COVERAGE_INCOMPLETE')
        if len(members)<MIN_MEMBERS:reasons.append('THIN_FINE_SECTOR_UNDER_3_MEMBERS')
        if clean_rate<COVERAGE_MIN:reasons.append('INVALID_OR_STALE_LEAF_ROWS')
        if not (baseline_valid and prev_baseline_valid and day_coverage and relative is not None and previous_relative is not None):reasons.append('NO_20D_VERIFIED_LEAF_REFERENCE')
        if not benchmark_verified:reasons.append('NO_SAME_VENUE_SESSION_BENCHMARK')
        if not supply_liquidity:reasons.append('MIN_LIQUIDITY_NOT_MET')
        if share_growth is None or shift_pp is None:reasons.append('SHARE_ACCELERATION_UNAVAILABLE')
        if not members:state='NO_VERIFIED_MEMBERS'
        elif len(members)<MIN_MEMBERS:state='THIN_SECTOR_OBSERVE'
        elif previous_states.get(leaf) in ('S2','S3') and not core_evidence:state='DATA_LOST'
        elif exit_signal:state='S5'
        elif not complete or relative is None or previous_relative is None or rs is None or share_growth is None:state='INSUFFICIENT_COVERAGE'
        elif (avg_ret is not None and avg_ret>=.10 and relative>=1.4 and breadth is not None and breadth>=.65):state='S4'
        elif (relative>=1.4 and previous_relative>=1.2 and share_growth>=1.25 and shift_pp>0
              and breadth is not None and breadth>=.55 and adv_count>=2 and
              leader_share is not None and leader_share<=.70 and rs>0 and rs_velocity is not None and rs_velocity>0
              and diffusion_growth is not None and diffusion_growth>=0
              and rs_acceleration is not None and rs_acceleration>=-.002
              and buy_count>=2 and hold_count>=2):state='S3'
        elif (relative>=1.2 and share_growth>=1.15 and shift_pp>0 and breadth is not None and breadth>=.50
              and adv_count>=2 and leader_share is not None and leader_share<=.80 and rs>=0
              and rs_velocity is not None and rs_velocity>=0 and diffusion_growth is not None and diffusion_growth>=0):state='S2'
        elif relative<1 and (breadth or 0)<.50:state='S0'
        else:state='S1'
        # A cold-start sector must first be confirmed as S2 over a distinct poll.
        # Stale/other venue session state never reaches the caller via previous_states.
        if state=='S3' and previous_states.get(leaf) not in ('S2','S3'):
            state='S2'
            reasons.append('S3_AWAITS_PREVIOUS_S2_CONFIRMATION')
        rotation_stage,s2_progress,s3_progress=_rotation_display(state,complete=complete,relative=relative,
           share_growth=share_growth,shift_pp=shift_pp,breadth=breadth,adv_count=adv_count,leader_share=leader_share,
           rs=rs,rs_velocity=rs_velocity,diffusion_growth=diffusion_growth,previous_relative=previous_relative,
           rs_acceleration=rs_acceleration,buy_count=buy_count,hold_count=hold_count)
        info={'sector':leaf,'leaf_id':leaf,'label':meta['label'],'parent_id':meta['parent'],
           'state':state,'rotation_stage':rotation_stage,'display_priority':DISPLAY_STAGE_ORDER.get(rotation_stage,99),
           's2_gate_progress_pct':s2_progress,'s3_gate_progress_pct':s3_progress,
           'early_rotation_watch':rotation_stage=='EARLY_ROTATION','entry_gate_unchanged':True,
           'gate_priority':'FINE_LEAF_FIRST','eligible_for_deep':state in ('S2','S3'),
           'gross_interval_turnover_krw':round(curr),'nonmega_interval_turnover_krw':round(curr),
           'prior_interval_turnover_krw':round(prev_interval),'observed':len(members),
           'registered_leaf_total':member_count if member_total_valid else None,
           'coverage':round(leaf_coverage,4) if leaf_coverage is not None else None,
           'valid_delta_ratio':round(clean_rate,4),'breadth':round(breadth,4) if breadth is not None else None,
           'buy_dominance_count':buy_count,'price_hold_count':hold_count,
           'sector_micro_ttl_sec':SECTOR_MICRO_FRESH_SEC,'exit_gate_independent_of_promotion_liquidity':True,'leader_share':round(leader_share,4) if leader_share is not None else None,
           'rs':round(rs,6) if rs is not None else None,
           'rs_velocity':round(rs_velocity,6) if rs_velocity is not None else None,
           'rs_acceleration':round(rs_acceleration,6) if rs_acceleration is not None else None,
           'diffusion_growth':round(diffusion_growth,5) if diffusion_growth is not None else None,
           'relative_turnover':relative,
           'relative_prev':previous_relative,'baseline_days':hist_days if day_coverage else None,
           'nonmega_share_current':round(present,7) if present is not None else None,
           'nonmega_share_prior':round(past,7) if past is not None else None,
           'nonmega_share_delta_pp':round(shift_pp,6) if shift_pp is not None else None,
           'nonmega_share_growth':round(share_growth,5) if share_growth is not None else None,
           'block_reasons':reasons if state not in ('S2','S3') else [r for r in reasons if r=='S3_AWAITS_PREVIOUS_S2_CONFIRMATION'],
           'measurement':'OBSERVED_INTERVAL_TURNOVER_NOT_NET_BUY'}
        result['sectors'].append(info)
        if members:result['leaf_money'].append(info.copy())
        if state in ('S2','S3'):good_eligible[leaf]=info
    result['thin_watch']=[{'sector':s['sector'],'label':s['label'],
        'observed':s['observed'],'state':'THIN_SECTOR_OBSERVE','entry_allowed':False,
        'watch_signal':('EARLY_ROTATION_WATCH' if (s.get('nonmega_share_growth') or 0)>=1.15
             and (s.get('nonmega_share_delta_pp') or 0)>0 and (s.get('rs') or -1)>=0 else 'LOW_CONFIDENCE'),
        'nonmega_share_growth':s.get('nonmega_share_growth'),'rs':s.get('rs')}
        for s in result['sectors'] if s['state']=='THIN_SECTOR_OBSERVE'][:10]
    result['sectors'].sort(key=lambda a:(S_ORDER.get(a['state'],9),-a['gross_interval_turnover_krw'],a['sector']))
    # Display ranking is state-first and acceleration-first; gross turnover is no longer the primary display rank.
    result['leaf_money'].sort(key=_rotation_sort_key)
    result['rotation_board']={
        'EARLY_ROTATION':[x for x in result['leaf_money'] if x.get('rotation_stage')=='EARLY_ROTATION'][:10],
        'S2_MONEY_MOVE':[x for x in result['leaf_money'] if x.get('rotation_stage')=='S2_MONEY_MOVE'][:10],
        'S3_CONFIRMED':[x for x in result['leaf_money'] if x.get('rotation_stage')=='S3_CONFIRMED'][:10],
        'WEAKENING_OR_EXIT':[x for x in result['leaf_money'] if x.get('rotation_stage') in ('WEAKENING','S5_EXIT')][:10],
    }
    result['fine_sector_gate']={'baseline_source':'LOCAL_ARCHIVE' if baseline_valid else 'NOT_VERIFIED',
        'reviewed_leaf_count':len(LEAVES),'qualifying_leaf_count':len(good_eligible),
        'allow_deep_scan':bool(good_eligible),'verified_current_universe':universe_complete,
        'matched_three_frames':bool(historical),'state_first_score_last':True,
        'evaluated_before_stock_gates':True}
    # No individual candidate is even considered until fine sector states are established.
    for r in rows:
        leaf=r['primary_leaf']
        if leaf not in good_eligible or r['is_mega_anchor']:continue
        kind=str(r.get('gem_type') or '').upper()
        if kind not in ('A','B','C'):continue
        price=r['_current_price']
        levels,level_error=derive_levels(r,price,frame['venue'],frame['session'],now) if price else (None,'NO_PRICE')
        stop=levels['stop'] if levels else None
        target=levels['target'] if levels else None
        pct=price/r['_prev_close']-1 if price is not None and r['_prev_close'] and r['_prev_close']>0 else None
        risk_ok=bool(price is not None and stop is not None and target is not None and
              0<stop<price<target and (target-price)/(price-stop)>=2 and
              (price-stop)/price<=.10)
        micro_ts=r.get('micro_event_time')
        hold_ts=r.get('hold_event_time') or micro_ts
        absorb_ts=r.get('absorption_event_time') or micro_ts
        compression_ts=r.get('compression_event_time') or micro_ts
        structure_ts=r.get('structure_event_time') or micro_ts
        price_ok=bool(price is not None and r['_vwap'] is not None and price>=r['_vwap']
                      and truth(r.get('price_hold')) and fresh(hold_ts,now,DEEP_FRESH_SEC))
        absorption_ok=truth(r.get('absorption_verified')) and fresh(absorb_ts,now,DEEP_FRESH_SEC)
        compression_flag_ok=truth(r.get('compression_verified')) and fresh(compression_ts,now,DEEP_FRESH_SEC)
        compression_ok=absorption_ok and compression_flag_ok
        required_times=[micro_ts,hold_ts,absorb_ts,compression_ts]
        shape_ok=True;shape_reason=None
        if kind=='A':
            shape_ok=pct is not None and -.01<=pct<=.03;shape_reason='GEM_A_UNDEREXTENDED_RANGE'
            compression_ok=compression_ok and shape_ok
        elif kind=='B':
            shape_ok=bool(pct is not None and .03<=pct<=.07 and truth(r.get('high_base_verified')) and fresh(structure_ts,now,DEEP_FRESH_SEC))
            shape_reason='GEM_B_HIGH_BASE_FRESH';compression_ok=compression_ok and shape_ok;required_times.append(structure_ts)
        else:
            shape_ok=bool(truth(r.get('leader_diffusion_verified')) and fresh(structure_ts,now,DEEP_FRESH_SEC))
            shape_reason='GEM_C_LEADER_DIFFUSION_FRESH';compression_ok=compression_ok and shape_ok;required_times.append(structure_ts)
        micro_ok=truth(r.get('buy_dominance_verified')) and fresh(micro_ts,now,DEEP_FRESH_SEC)
        parsed_times=[timeparse(t) for t in required_times]
        evidence_times_ok=all(t is not None for t in parsed_times)
        evidence_valid_until=(min(t+timedelta(seconds=ENTRY_EVIDENCE_TTL_SEC) for t in parsed_times)
                              if evidence_times_ok else None)
        evidence_remaining=(evidence_valid_until-now).total_seconds() if evidence_valid_until else None
        evidence_live=bool(evidence_remaining is not None and evidence_remaining>=0)
        missing=[v for v,ok in [('STOCK_LIVE',r['_valid']),('STOCK_PRICE_HOLD_FRESH',price_ok),
                  ('STOCK_ABSORPTION_FRESH',absorption_ok),('STOCK_COMPRESSION_FRESH',compression_flag_ok),
                  ('STOCK_MICRO_BUY',micro_ok),('ENTRY_EVIDENCE_TTL',evidence_live),
                  (shape_reason,shape_ok),('STOCK_RISK_2R',risk_ok),('RISK_BAR_PROVENANCE',bool(levels))] if not ok]
        ok=not missing and compression_ok
        state=('ENTRY' if ok and good_eligible[leaf]['state']=='S3' else
                'PRE-ENTRY' if ok and good_eligible[leaf]['state']=='S2' else 'WATCH')
        result['candidates'].append({'code':r['code'],'name':r.get('name'),'sector':leaf,
             'fine_sector_state':good_eligible[leaf]['state'],'gem_type':kind,'state':state,
             'price':price,'stop_price':stop,'target_price':target,
             'risk_basis':levels['basis'] if levels else None,'risk_error':level_error,
             'evidence_valid_until':evidence_valid_until.isoformat() if evidence_valid_until else None,
             'entry_valid_for_sec':round(max(0,evidence_remaining),3) if evidence_remaining is not None else None,
             'reasons_missing':missing,
             'gate_basis':'FINE_SECTOR_S2_S3_ONLY__ALL_STOCK_EVIDENCE_FRESH'})
    rank={'ENTRY':0,'PRE-ENTRY':1,'WATCH':2}
    result['candidates'].sort(key=lambda c:(rank[c['state']],S_ORDER[c['fine_sector_state']],
        -good_eligible[c['sector']]['nonmega_share_growth'],-good_eligible[c['sector']]['relative_turnover'],c['code']))
    sector_counts=defaultdict(int)
    for c in result['candidates']:
        if c['state']=='ENTRY':
            sector=c['sector'];ctx=good_eligible[sector]
            cap=3 if len(good_eligible)==1 and ctx['breadth']>=.65 else 2
            if sector_counts[sector]>=cap:
                c['state']='WATCH';c['reasons_missing'].append('FINE_SECTOR_CONCENTRATION_CAP')
            else:sector_counts[sector]+=1
    result['candidates'].sort(key=lambda c:(rank[c['state']],S_ORDER[c['fine_sector_state']],
        -good_eligible[c['sector']]['nonmega_share_growth'],-good_eligible[c['sector']]['relative_turnover'],c['code']))
    result['candidates']=result['candidates'][:5]
    result['qualified_count']=sum(c['state']=='ENTRY' for c in result['candidates'])
    return result
