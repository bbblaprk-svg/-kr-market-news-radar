"""V12.4 offline Kiwoom master -> evidence-gated process membership converter.
No network, credentials, order APIs, or upstream changes. This file never guesses leaves.
Input is a user-exported JSON from the existing READ-ONLY V8.3 master GET.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,re
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
from taxonomy_v123 import ANCHOR_CODES,LEAVES,safe_code

MIN_CAP=200_000_000_000
FIELDS=['code','name','market','market_cap_krw','nxt_eligible','kiwoom_major_sector','primary_leaf','reviewed','theme_tags','evidence_url','reviewed_at','review_note']

def iso_parse(x):
    if not x:return None
    try:
        z=datetime.fromisoformat(x.replace('Z','+00:00'))
        return z if z.tzinfo else None
    except (TypeError,ValueError):return None

def normalize_master(payload):
    if not isinstance(payload,dict):raise ValueError('MASTER_NOT_OBJECT')
    stocks=payload.get('stocks')
    if not isinstance(stocks,list):raise ValueError('MASTER_STOCKS_NOT_ARRAY')
    source_count=payload.get('count');venue=payload.get('venue')
    if venue!='KRX':raise ValueError('FULL_MASTER_REQUIRES_KRX_NOT_NXT_SUBSET')
    if type(source_count)!=int or source_count<=0:raise ValueError('MASTER_COUNT_MISSING')
    if len(stocks)!=source_count:raise ValueError('TRUNCATED_MASTER_RESPONSE__USE_LIMIT_3000')
    stamp=iso_parse(payload.get('fetched_at'))
    if not stamp:raise ValueError('MASTER_FETCH_TIME_UNKNOWN')
    verified=[];seen=set()
    for r in stocks:
        if not isinstance(r,dict):raise ValueError('MASTER_ROW_NOT_OBJECT')
        code=safe_code(r.get('code'));name=str(r.get('name') or '').strip()
        if not re.fullmatch(r'\d{6}',code or '') or not name:raise ValueError('INVALID_CODE_OR_NAME')
        if code in seen:raise ValueError('DUPLICATE_MASTER_CODE')
        seen.add(code)
        try:cap=int(r.get('prev_mcap_krw') or 0)
        except (TypeError,ValueError):cap=0
        # V8.3 input master includes buffer names as low as 90% of configured floor.
        # Include only eligible >= 200B and mark that cap is indicative / not live.
        if cap<MIN_CAP:continue
        verified.append({'code':code,'name':name,'market':str(r.get('marketName') or r.get('marketCode') or ''),
          'market_cap_krw':cap,'nxt_eligible':r.get('nxtEnable') is True,
          'kiwoom_major_sector':str(r.get('sector') or ''),'primary_leaf':'', 'reviewed':'no',
          'theme_tags':'','evidence_url':'','reviewed_at':'','review_note':''})
    return verified, {'reported_master_rows':source_count,'master_rows_complete':True,
       'eligible_master_rows':len(verified),'nxt_eligible_rows':sum(r['nxt_eligible'] for r in verified),
       'fetched_at':stamp.isoformat(),'venue':'KRX','cap_basis':'PREV_CAP_NOT_LIVE',
       'source':'KIWOOM_V83_MASTER_EXPORT','master_sha256':hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True).encode()).hexdigest()}

def evidence_load(path):
    out={}
    if not path:return out
    with open(path,encoding='utf-8-sig',newline='') as f:
        for r in csv.DictReader(f):
            code=safe_code(r.get('code'));leaf=(r.get('primary_leaf') or '').strip()
            yes=str(r.get('reviewed') or '').strip().lower()=='yes'
            evidence=str(r.get('evidence_url') or '').strip()
            reviewed=iso_parse(str(r.get('reviewed_at') or '').strip())
            if not yes:continue
            if code in out:raise ValueError('DUPLICATE_EVIDENCE')
            if not re.fullmatch(r'\d{6}',code or '') or leaf not in LEAVES or not evidence.startswith('https://') or not reviewed:
                raise ValueError(f'INVALID_REVIEWED_EVIDENCE_{code}')
            tags=[x for x in str(r.get('theme_tags') or '').split('|') if x]
            if any(x not in LEAVES for x in tags):raise ValueError('INVALID_OVERLAY_TAG')
            out[code]={'leaf':leaf,'tags':tags,'evidence_url':evidence,'reviewed_at':reviewed.isoformat(),
                       'review_note':str(r.get('review_note') or '')}
    return out

def build(master_path,evidence_path,output_dir):
    master_path=Path(master_path);output_dir=Path(output_dir);output_dir.mkdir(parents=True,exist_ok=True)
    payload=json.loads(master_path.read_text(encoding='utf-8-sig'))
    rows,meta=normalize_master(payload);evidence=evidence_load(evidence_path)
    reviewed_rows=[];unmatched=set(evidence)
    for r in rows:
        code=r['code']
        if code in ANCHOR_CODES:
            r['review_note']='MEGACAP_ANCHOR_BUILT_IN';r['reviewed']='anchor'
        elif code in evidence:
            ev=evidence[code];r.update(primary_leaf=ev['leaf'],reviewed='yes',theme_tags='|'.join(ev['tags']),
                evidence_url=ev['evidence_url'],reviewed_at=ev['reviewed_at'],review_note=ev['review_note'])
            reviewed_rows.append({'code':code,'primary_leaf':ev['leaf'],'reviewed':'yes','theme_tags':'|'.join(ev['tags'])})
            unmatched.discard(code)
    with (output_dir/'all_stock_review_queue.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
    with (output_dir/'membership_reviewed.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['code','primary_leaf','reviewed','theme_tags']);w.writeheader();w.writerows(reviewed_rows)
    # Never treat verified subset as full leaf member totals.
    verified=sum(r['reviewed']=='yes' for r in rows);anchors=sum(r['reviewed']=='anchor' for r in rows)
    total=len(rows); classified=verified+anchors
    nxt_total=sum(r['nxt_eligible'] for r in rows)
    nxt_classified=sum(r['nxt_eligible'] and r['reviewed'] in ('yes','anchor') for r in rows)
    meta.update({'verified_leaf_count':verified,'mega_anchor_count':anchors,'unclassified_count':total-classified,
      'classified_ratio':round(classified/total,6) if total else 0,
      'coverage_ready':bool(total and classified==total and not unmatched),
      'coverage_ready_nxt':bool(nxt_total and nxt_total==nxt_classified and not unmatched),
      'nxt_classified_rows':nxt_classified,
      'source_evidence_unmatched':sorted(unmatched),'requires_full_master_and_complete_leaf_mapping':True,
      'live_quote_verified':False,'decision_status':'MAPPING_COMPLETE_NOT_LIVE' if total and classified==total else 'MAPPING_INCOMPLETE',
      'explicit_mapping_not_sector_keyword_guess':True})
    (output_dir/'master_audit.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    return meta

def main():
    ap=argparse.ArgumentParser(description='Read existing V8.3 master export; never write to existing Kiwoom services')
    ap.add_argument('--master',required=True,help='Downloaded V8.3 GET /master/KRX?limit=3000 JSON')
    ap.add_argument('--evidence',default=str(Path(__file__).with_name('company_evidence_seed.csv')))
    ap.add_argument('--out',default='review_output')
    args=ap.parse_args();print(json.dumps(build(args.master,args.evidence,args.out),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
