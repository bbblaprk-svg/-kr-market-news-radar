"""Independent local audit gate for LS provider. Remote frame flags alone cannot enable ENTRY."""
import os,json,hashlib
from pathlib import Path
from datetime import datetime,timezone,timedelta
from engine_v127_ls import scan_fine_first

def _load_audit():
    p=Path(os.getenv('LS_V127_MASTER_AUDIT_FILE','ls_master_audit.json'))
    if not p.is_file():return {'status':'MISSING'}
    try:return json.loads(p.read_text(encoding='utf-8'))
    except Exception:return {'status':'INVALID'}

def guarded_scan_fine(frame,previous=None,now=None,reviewed=None,older=None,baseline=None,previous_states=None):
    now=now or datetime.now(timezone.utc);out=scan_fine_first(frame,previous,older,now,reviewed,baseline,previous_states);audit=_load_audit();venue=frame.get('venue') if isinstance(frame,dict) else None;problems=[]
    if audit.get('status')!='VERIFIED':problems.append('LS_MASTER_AUDIT_NOT_VERIFIED')
    stamp=audit.get('verified_at')
    try:
        ts=datetime.fromisoformat(str(stamp).replace('Z','+00:00'))
        if ts.tzinfo is None or not timedelta(0)<=now-ts<=timedelta(days=7):problems.append('LS_MASTER_AUDIT_EXPIRED')
    except Exception:problems.append('LS_MASTER_AUDIT_TIME_UNAVAILABLE')
    expected=(audit.get('nxt_eligible_rows') if venue=='NXT' else audit.get('krx_eligible_rows'))
    if not isinstance(frame,dict) or frame.get('eligible_universe_total')!=expected:problems.append('LS_MASTER_COUNT_MISMATCH')
    if frame.get('taxonomy_universe_confirmed') is not True:problems.append('TAXONOMY_NOT_VERIFIED')
    if out.get('classification',{}).get('unclassified_count',0)>0:problems.append('UNCLASSIFIED_OBSERVED_SYMBOLS')
    out['mapping_status']={'ready':not problems,'blocked_reasons':problems,'master_status':audit.get('status')}
    if problems:
        for s in out.get('sectors',[]):
            if s.get('state') in ('S2','S3'):
                s['state']='INSUFFICIENT_COVERAGE';s['eligible_for_deep']=False;s.setdefault('block_reasons',[]).extend(problems)
        for c in out.get('candidates',[]):
            if c.get('state') in ('ENTRY','PRE-ENTRY'):
                c['state']='WATCH_DATA_LIMITED';c.setdefault('reasons_missing',[]).extend(problems)
        out['qualified_count']=0;out.setdefault('warnings',[]).extend(problems);out.setdefault('fine_sector_gate',{})['allow_deep_scan']=False
    return out
