"""Locally derive support/risk and next historical supply zone from timestamped bars.
No arbitrary upstream stop_price or target_price is accepted as sufficient proof.
"""
from datetime import datetime
from engine_ls_core import KST, number, timeparse, session

def derive_levels(row,price,venue,sess,now):
    bars=row.get('risk_bars_1m');daily=row.get('supply_daily_bars')
    if not isinstance(bars,list) or len(bars)<5:return None,'MISSING_RECENT_INTRADAY_BARS'
    if not isinstance(daily,list) or len(daily)<5:return None,'MISSING_HISTORICAL_SUPPLY_BARS'
    lows=[];timestamps=[]
    for b in bars:
        if not isinstance(b,dict) or b.get('venue')!=venue or b.get('session')!=sess:return None,'MIXED_SESSION_RISK_BARS'
        t=timeparse(b.get('timestamp'));lo=number(b.get('low'));hi=number(b.get('high'))
        if not t or not (0<lo<=hi) or not 0<=(now-t).total_seconds()<=1200 or session(venue,t)!=sess:
            return None,'INVALID_OR_STALE_RISK_BARS'
        lows.append(lo);timestamps.append(t)
    if len(set(timestamps))<5 or timestamps!=sorted(timestamps):return None,'DUPLICATE_OR_UNSORTED_RISK_BARS'
    gaps=[(b-a).total_seconds() for a,b in zip(timestamps,timestamps[1:])]
    if any(not 45<=g<=75 for g in gaps):return None,'NONCONTIGUOUS_1M_RISK_BARS'
    if (now-timestamps[-1]).total_seconds()>90:return None,'LATEST_RISK_BAR_STALE'
    if any(t.astimezone(KST).date()!=now.astimezone(KST).date() for t in timestamps):return None,'RISK_BARS_WRONG_TRADING_DAY'
    highs=[];dates=set()
    for b in daily:
        if not isinstance(b,dict):return None,'INVALID_HISTORICAL_SUPPLY_BARS'
        d=b.get('trading_date');hi=number(b.get('high'))
        try:dt=datetime.strptime(d,'%Y-%m-%d').date()
        except (ValueError,TypeError):return None,'INVALID_HISTORICAL_SUPPLY_BARS'
        if dt>=now.astimezone(KST).date() or hi is None or hi<=0 or d in dates:
            return None,'INVALID_HISTORICAL_SUPPLY_BARS'
        dates.add(d)
        if hi>price:highs.append(hi)
    if len(dates)<5:return None,'INSUFFICIENT_HISTORICAL_SUPPLY_BARS'
    if not highs:return None,'NO_PROVEN_NEXT_SUPPLY_ZONE'
    stop=round(min(lows)*.997,3)
    target=min(highs)
    if not 0<stop<price<target:return None,'RISK_LEVELS_NOT_VALID'
    ratio=(target-price)/(price-stop)
    if ratio<2 or (price-stop)/price>.10:return None,'HISTORICAL_SUPPLY_LESS_THAN_2R'
    return {'stop':stop,'target':target,'rr':round(ratio,3),
            'basis':'RECENT_SAME_SESSION_BAR_SUPPORT_AND_PRIOR_DAY_SUPPLY'},None
