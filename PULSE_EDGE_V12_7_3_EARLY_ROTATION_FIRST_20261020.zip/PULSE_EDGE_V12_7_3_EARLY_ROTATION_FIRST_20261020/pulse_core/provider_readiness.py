import csv,json,os
from pathlib import Path
from master_guard_v127_ls import _load_audit
from taxonomy_v123 import LEAVES

def reviewed_count(path):
    try:
        with open(path,encoding='utf-8-sig',newline='') as f:
            return sum(1 for r in csv.DictReader(f) if str(r.get('reviewed','')).lower() in ('yes','true','1') and r.get('primary_leaf') in LEAVES)
    except Exception:return 0

def main():
    audit=_load_audit();cal_path=Path(os.getenv('V127_TRADING_CALENDAR_JSON',Path(__file__).with_name('trading_calendar.json')))
    try:cal=json.loads(cal_path.read_text(encoding='utf-8'))
    except Exception:cal={}
    out={
      'provider':'LS_OPENAPI','orders_enabled':False,
      'master_audit':audit.get('status','MISSING'),
      'reviewed_mapping_count':reviewed_count(os.getenv('V127_REVIEWED_CSV',str(Path(__file__).with_name('membership_reviewed.csv')))),
      'calendar_krx_days':len(cal.get('KRX',[])) if isinstance(cal.get('KRX'),list) else 0,
      'calendar_nxt_days':len(cal.get('NXT',[])) if isinstance(cal.get('NXT'),list) else 0,
      'krx_frame_url_set':bool(os.getenv('LS_V127_FULL_FRAME_URL_KRX')),
      'nxt_frame_url_set':bool(os.getenv('LS_V127_FULL_FRAME_URL_NXT')),
      'bridge_token_set':bool(os.getenv('PULSE_BRIDGE_TOKEN')),
    }
    out['ready_for_shadow']=all([out['master_audit']=='VERIFIED',out['reviewed_mapping_count']>0,out['calendar_krx_days']>0,out['calendar_nxt_days']>0,out['krx_frame_url_set'],out['nxt_frame_url_set'],out['bridge_token_set']])
    out['ready_for_entry']=False  # must be proven by live REST/WS + 20 trading-day baseline before operator enables production entry.
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
