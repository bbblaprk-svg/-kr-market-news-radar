"""V12.6.2 local same-minute traded-value reference (NOT net-buy data).

Safety changes vs V12.6:
- stores exact 1-minute interval keys rather than overwriting observations inside a 5-minute bucket;
- requires a locally loaded exchange trading-day calendar for archive and reference use;
- refuses weekend/unconfirmed dates and incomplete/mixed-universe pairs;
- never trusts a remote baseline_verified/relative-strength flag.
"""
from __future__ import annotations
import argparse, json, sqlite3
from datetime import datetime
from collections import defaultdict
from statistics import median
from pathlib import Path
from engine_ls_core import KST, is_common_stock, number, session, source_ok, timeparse
from taxonomy_v123 import VERSION, LEAVES, attach_taxonomy, safe_code, load_reviewed

INTERVAL_SCHEMA='''CREATE TABLE IF NOT EXISTS interval_minutes_v1262 (
    venue TEXT NOT NULL, sess TEXT NOT NULL, trading_date TEXT NOT NULL,
    minute_key INTEGER NOT NULL, leaf TEXT NOT NULL,
    leaf_value REAL NOT NULL, nonmega_market_value REAL NOT NULL,
    taxonomy_version TEXT NOT NULL,
    PRIMARY KEY (venue,sess,trading_date,minute_key,leaf)
)'''
CALENDAR_SCHEMA='''CREATE TABLE IF NOT EXISTS trading_calendar_v1262 (
    venue TEXT NOT NULL, trading_date TEXT NOT NULL, source TEXT NOT NULL,
    PRIMARY KEY (venue,trading_date)
)'''


def open_store(path):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(str(p));con.execute(INTERVAL_SCHEMA);con.execute(CALENDAR_SCHEMA);con.commit();return con


def _timestamp(f):return timeparse(f.get('generated_at')) if isinstance(f,dict) else None


def add_trading_day(con, venue, trading_date, source='LOCAL_EXCHANGE_CALENDAR'):
    if venue not in ('KRX','NXT'):return False
    try:day=datetime.strptime(trading_date,'%Y-%m-%d').date()
    except (TypeError,ValueError):return False
    if day.weekday()>=5:return False
    with con:
        con.execute('INSERT OR REPLACE INTO trading_calendar_v1262 VALUES (?,?,?)',(venue,day.isoformat(),str(source)[:80]))
    return True


def load_calendar_file(con,path):
    """Load a local calendar JSON. Accepted forms:
       {"KRX":["YYYY-MM-DD",...],"NXT":[...]}
       {"days":[{"venue":"KRX","date":"YYYY-MM-DD"},...]}
    Returns inserted/validated day count. Missing file is fail-closed and returns 0.
    """
    if not path:return 0
    p=Path(path)
    if not p.is_file():return 0
    try:obj=json.loads(p.read_text(encoding='utf-8'))
    except Exception:return 0
    rows=[]
    if isinstance(obj,dict) and isinstance(obj.get('days'),list):
        rows=[(x.get('venue'),x.get('date')) for x in obj['days'] if isinstance(x,dict)]
    elif isinstance(obj,dict):
        for venue in ('KRX','NXT'):
            if isinstance(obj.get(venue),list):rows.extend((venue,d) for d in obj[venue])
    accepted=0
    for venue,day in rows:
        accepted+=bool(add_trading_day(con,venue,day,'LOCAL_EXCHANGE_CALENDAR_JSON'))
    return accepted


def _calendar_contains(con,venue,day):
    return con.execute('SELECT 1 FROM trading_calendar_v1262 WHERE venue=? AND trading_date=?',(venue,day)).fetchone() is not None


def interval_values(previous,current,reviewed):
    """Return one fully validated ~1-minute interval or None.

    The minute key is the KST START minute of the interval, so 08:20:00->08:21:00
    compares only with the same start minute on prior verified trading days.
    """
    a=_timestamp(previous);b=_timestamp(current)
    if not a or not b or not all(isinstance(x,dict) and source_ok(x) for x in (previous,current)):return None
    venue=current.get('venue');sess=current.get('session')
    local_a=a.astimezone(KST);local_b=b.astimezone(KST)
    if (venue not in ('NXT','KRX') or sess!=previous.get('session') or venue!=previous.get('venue')
        or session(venue,a)!=sess or session(venue,b)!=sess or local_a.date()!=local_b.date()
        or local_a.date().weekday()>=5
        or previous.get('trading_day_confirmed') is not True or current.get('trading_day_confirmed') is not True
        or not 45 <=(b-a).total_seconds() <= 75):return None
    arrays=[]
    for f in (previous,current):
        stocks=f.get('stocks');total=f.get('eligible_universe_total')
        if not isinstance(stocks,list) or type(total) is not int or len(stocks)!=total or total==0:return None
        if f.get('taxonomy_universe_confirmed') is not True:return None
        mapping={}
        for item in stocks:
            if not isinstance(item,dict) or not is_common_stock(item):return None
            code=safe_code(item.get('code'))
            if not code or code in mapping:return None
            mapping[code]=item
        arrays.append(mapping)
    aa,bb=arrays
    if aa.keys()!=bb.keys():return None
    mapped=attach_taxonomy(current,reviewed)['stocks'];code_meta={x['code']:x for x in mapped}
    if any(not (code_meta[k].get('primary_leaf') in LEAVES or code_meta[k].get('is_mega_anchor')) for k in bb):return None
    sector_values=defaultdict(float);market=0.0
    for k,r in bb.items():
        old=number(aa[k].get('turnover_cum'));new=number(r.get('turnover_cum'))
        if old is None or new is None or not 0<=old<=new:return None
        delta=new-old;meta=code_meta[k]
        if not meta['is_mega_anchor']:
            sector_values[meta['primary_leaf']]+=delta;market+=delta
    if market<=0:return None
    return {'venue':venue,'session':sess,'day':local_b.date().isoformat(),
        'minute_key':local_a.hour*60+local_a.minute,'sectors':dict(sector_values),'market':market}


def record_pair(con,previous,current,reviewed):
    interval=interval_values(previous,current,reviewed)
    if interval is None or not _calendar_contains(con,interval['venue'],interval['day']):return False
    with con:
        for leaf,amount in interval['sectors'].items():
            # First accepted complete observation for an exact minute wins. Re-imports cannot overwrite history.
            con.execute('''INSERT OR IGNORE INTO interval_minutes_v1262 VALUES (?,?,?,?,?,?,?,?)''',
              (interval['venue'],interval['session'],interval['day'],interval['minute_key'],leaf,
               amount,interval['market'],VERSION))
    return True


def _history(con,venue,sess,day,minute_key,leaf):
    return con.execute('''SELECT i.trading_date,i.leaf_value,i.nonmega_market_value
       FROM interval_minutes_v1262 i JOIN trading_calendar_v1262 c
         ON c.venue=i.venue AND c.trading_date=i.trading_date
       WHERE i.venue=? AND i.sess=? AND i.trading_date<? AND i.minute_key=? AND i.leaf=? AND i.taxonomy_version=?
       ORDER BY i.trading_date DESC LIMIT 20''',(venue,sess,day,minute_key,leaf,VERSION)).fetchall()


def compute_reference(con,older,previous,current,reviewed):
    """Produce locally derived evidence for two adjacent current 1-minute intervals."""
    first=interval_values(older,previous,reviewed);last=interval_values(previous,current,reviewed)
    if not first or not last:return None
    if first['venue']!=last['venue'] or first['session']!=last['session'] or first['day']!=last['day']:return None
    if not _calendar_contains(con,last['venue'],last['day']):return None
    days={};prior_strength={};current_strength={}
    for leaf in sorted(set(first['sectors'])|set(last['sectors'])):
        hs=_history(con,last['venue'],last['session'],last['day'],last['minute_key'],leaf)
        ps=_history(con,first['venue'],first['session'],first['day'],first['minute_key'],leaf)
        if len(hs)<20 or len(ps)<20 or len(set(x[0] for x in hs))<20 or len(set(x[0] for x in ps))<20:continue
        expected=median(x[1] for x in hs);market=median(x[2] for x in hs)
        pexpected=median(x[1] for x in ps);pmarket=median(x[2] for x in ps)
        if min(expected,market,pexpected,pmarket)<=0:continue
        curr_share=(last['sectors'].get(leaf,0)/expected)/(last['market']/market)
        prev_share=(first['sectors'].get(leaf,0)/pexpected)/(first['market']/pmarket)
        if not (curr_share>0 and prev_share>0):continue
        current_strength[leaf]=curr_share;prior_strength[leaf]=prev_share;days[leaf]=20
    return {'provenance':'LOCAL_COMPUTED_FROM_LS_ARCHIVE','verified':bool(current_strength),
            'venue':last['venue'],'session':last['session'],'taxonomy_version':VERSION,
            'days':days,'current_strength':current_strength,'previous_strength':prior_strength,
            'history_type':'20_VERIFIED_TRADING_DAYS_EXACT_KST_1MIN_INTERVAL',
            'current_minute_key':last['minute_key'],'previous_minute_key':first['minute_key']}


def main():
    ap=argparse.ArgumentParser(description='Import full LS OpenAPI frame pairs into V12.6.2 exact-minute baseline archive.')
    ap.add_argument('--pairs-jsonl',required=True);ap.add_argument('--reviewed-csv',required=True)
    ap.add_argument('--calendar-json',required=True);ap.add_argument('--db',required=True)
    args=ap.parse_args();reviewed=load_reviewed(args.reviewed_csv);accepted=0;rejected=0
    with open(args.pairs_jsonl,encoding='utf-8') as f,open_store(args.db) as db:
        calendar_days=load_calendar_file(db,args.calendar_json)
        for line in f:
            if not line.strip():continue
            obj=json.loads(line)
            if record_pair(db,obj['previous'],obj['current'],reviewed):accepted+=1
            else:rejected+=1
    print(json.dumps({'accepted':accepted,'rejected':rejected,'calendar_days':calendar_days,
        'source':'LOCAL_ARCHIVED_LS_PAIRS_EXACT_MINUTE'},ensure_ascii=False))
if __name__=='__main__':main()
