"""Read-only LS data bridge client for PULSE EDGE V12.7."""
import os,json,urllib.parse,urllib.request,urllib.error
DENIED={'order','orders','account','login','token','auth','revoke','trade','buy','sell'}
SENSITIVE={'key','api_key','appkey','app_key','secret','access_token','token','password','account'}
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*a,**kw):return None

def validate_url(value,allowed_hosts=None):
    if not isinstance(value,str) or not value:return 'UNCONFIGURED'
    p=urllib.parse.urlsplit(value)
    if p.username or p.password or p.fragment or p.scheme not in ('https','http'):return 'UNSAFE_URL'
    hosts=allowed_hosts if allowed_hosts is not None else {x.strip().lower() for x in os.getenv('LS_V127_ALLOWED_HOSTS','').split(',') if x.strip()}
    internal_http=os.getenv('LS_V127_ALLOW_HTTP_INTERNAL','').lower() in ('1','true','yes','on')
    if p.scheme=='http' and p.hostname not in ('localhost','127.0.0.1') and not (internal_http and p.hostname and p.hostname.lower() in hosts):return 'HTTPS_REQUIRED'
    if not hosts or not p.hostname or p.hostname.lower() not in hosts:return 'HOST_NOT_EXPLICITLY_ALLOWED'
    if any(s.lower() in DENIED for s in p.path.strip('/').split('/')):return 'TRADING_ROUTE_BLOCKED'
    if any(s.lower() in SENSITIVE for s in urllib.parse.parse_qs(p.query)):return 'SECRET_QUERY_REJECTED'
    if not p.path.strip('/'):return 'NON_DATA_URL'
    return None

def _headers():
    h={'Accept':'application/json','Cache-Control':'no-store'}
    token=os.getenv('PULSE_BRIDGE_TOKEN','').strip()
    if token:h['X-Pulse-Bridge-Token']=token
    return h

def fetch(venue):
    if venue not in ('KRX','NXT'):return {'status':'LS UNAVAILABLE','reason':'INVALID_VENUE','venue':venue}
    url=os.getenv(f'LS_V127_FULL_FRAME_URL_{venue}','')
    error=validate_url(url)
    if error:return {'status':'LS UNAVAILABLE','reason':error,'venue':venue}
    try:
        req=urllib.request.Request(url,headers=_headers(),method='GET')
        with urllib.request.build_opener(NoRedirect()).open(req,timeout=95) as response:
            blob=response.read(20_000_001)
            if len(blob)>20_000_000:raise ValueError('JSON_TOO_LARGE')
            d=json.loads(blob)
            if not isinstance(d,dict):raise ValueError('NOT_JSON_OBJECT')
            if d.get('venue')!=venue:raise ValueError('VENUE_MISMATCH')
            if not str(d.get('source','')).upper().startswith('LS_OPENAPI'):raise ValueError('SOURCE_MISMATCH')
            return d
    except urllib.error.HTTPError as e:reason=f'HTTP_{e.code}'
    except Exception as e:reason=type(e).__name__
    return {'status':'LS UNAVAILABLE','reason':reason,'venue':venue}
