"""V12.3 versioned sector taxonomy; mapping is evidence-based, never name-guessed.
A ticker has exactly one PRIMARY leaf or ANCHOR classification. Theme tags are overlays.
"""
from __future__ import annotations
from collections import defaultdict
from pathlib import Path
import csv,json

VERSION='2026-10-19-v12.4'
# Parent, primary leaf IDs + Korean names. Extend through REVIEWED membership, not string guessing.
SECTORS={
 'DIVERSIFIED': ('종합전자·복합 메가캡 기준점', {}),
 'SEMICON': ('반도체·전자부품', {
  'SEMI_MEMORY': 'DRAM·HBM·NAND 메모리 제조(비앵커)',
  'SEMI_FOUNDRY':'파운드리·시스템반도체',
  'SEMI_FABLESS':'팹리스·IP·설계',
  'SEMI_EUV':'노광·EUV·포토마스크',
  'SEMI_ETCH':'식각장비',
  'SEMI_DEPOSITION':'증착장비(CVD·PVD·ALD)',
  'SEMI_CLEAN':'세정장비',
  'SEMI_CMP':'CMP 장비',
  'SEMI_DIFFUSION':'열처리·확산·이온주입',
  'SEMI_METROLOGY':'계측·검사·검출',
  'SEMI_AUTOMATION':'공정 자동화·진공·이송',
  'SEMI_TESTER':'반도체 테스트 장비',
  'SEMI_PROBE':'프로브카드·테스트 소켓',
  'SEMI_PACKAGING':'패키징·본딩·TSV·HBM 후공정',
  'SEMI_ABF':'FC-BGA·ABF·인터포저',
  'SEMI_GLASS':'유리기판·유리 인터포저',
  'SEMI_WAFER':'실리콘 웨이퍼·SOI',
  'SEMI_PHOTO':'포토레지스트·고순도 약품',
  'SEMI_GAS':'특수가스·전구체',
  'SEMI_CMP_MATERIAL':'CMP 슬러리·패드',
  'SEMI_QUARTZ':'쿼츠·세라믹·챔버 소모품',
  'SEMI_POWER':'SiC·GaN 전력반도체',
  'SEMI_EQUIP_PARTS':'장비 부품·리퍼비시',
 }),
 'AI_DATACENTER': ('AI·데이터센터·냉각', {
  'AI_GPU_SERVER':'AI 서버·GPU 서버 시스템',
  'AI_MEMORY_NETWORK':'서버 DRAM·고속 인터커넥트',
  'AI_OPTICAL':'광트랜시버·CPO·광부품',
  'AI_NETWORK':'데이터센터 스위치·네트워크',
  'AI_COOL_LIQ':'액체냉각·수랭·CDU',
  'AI_COOL_IMMERSION':'액침냉각·냉각유',
  'AI_COOL_HVAC':'칠러·공조·열교환기',
  'AI_COOL_PARTS':'냉각펌프·밸브·매니폴드',
  'AI_POWER_UPS':'UPS·PDU·전력품질',
  'AI_CLOUD_INFRA':'클라우드 인프라·IDC',
 }),
 'SECURITY': ('보안·안전', {
  'SEC_NETWORK':'네트워크·제로트러스트 보안',
  'SEC_ENDPOINT':'엔드포인트·EDR·XDR',
  'SEC_IDENTITY':'인증·접근관리·생체인식',
  'SEC_CLOUD':'클라우드·데이터 보안',
  'SEC_PQC':'양자내성암호·암호모듈',
  'SEC_PHYSICAL':'영상·CCTV·물리 보안',
  'SEC_OT':'산업제어·OT 보안',
 }),
 'SPACE': ('우주·위성', {
  'SPACE_LAUNCH':'발사체·추진기관',
  'SPACE_SATELLITE':'위성체·탑재체·센서',
  'SPACE_GROUND':'지상국·위성관제',
  'SPACE_COMM':'위성통신·안테나·RF',
  'SPACE_DATA':'위성영상·지리정보·우주서비스',
 }),
 'AEROSPACE': ('항공·미래항공', {
  'AIR_AIRCRAFT':'항공기 구조물·기체',
  'AIR_ENGINE':'항공엔진·부품',
  'AIR_AVIONICS':'항공전자·항법·제어',
  'AIR_UAM':'UAM·eVTOL·미래항공',
  'AIR_MAINTENANCE':'항공 MRO·정비',
 }),
 'QUANTUM': ('양자', {
  'QUANTUM_COMPUTE':'양자컴퓨팅·제어',
  'QUANTUM_COMM':'양자통신·QKD',
  'QUANTUM_SENSOR':'양자센서·원자시계',
  'QUANTUM_CRYO':'극저온·냉동기',
  'QUANTUM_PHOTON':'양자광학·광원·검출기',
 }),
 'DEFENSE': ('방산·드론', {
  'DEF_RADAR':'레이더·전자전·센서',
  'DEF_MISSILE':'유도무기·추진',
  'DEF_DRONE':'방산 드론·무인체계',
  'DEF_NAVAL':'함정·해양방산',
  'DEF_LAND':'지상무기·탄약',
 }),
 'ROBOTICS': ('로봇·자동화', {
  'ROBOT_INDUSTRIAL':'산업로봇·협동로봇',
  'ROBOT_ACTUATOR':'감속기·액추에이터',
  'ROBOT_VISION':'로봇 비전·센서',
  'ROBOT_HUMANOID':'휴머노이드·서비스로봇',
  'ROBOT_LOGISTICS':'물류로봇·AMR',
 }),
 'POWER': ('전력·에너지 인프라', {
  'POWER_TRANSFORMER':'변압기·차단기·배전',
  'POWER_GRID':'송전·케이블·HVDC',
  'POWER_NUCLEAR':'원전·SMR·기자재',
  'POWER_FUSION':'핵융합 소재·장비',
  'POWER_FUELCELL':'수소연료전지·전해조',
  'POWER_STORAGE':'ESS·전력관리',
 }),
 'BATTERY': ('2차전지·소재', {
  'BAT_CATHODE':'양극재·전구체',
  'BAT_ANODE':'음극재·실리콘음극',
  'BAT_ELECTROLYTE':'전해액·첨가제',
  'BAT_SEPARATOR':'분리막·바인더',
  'BAT_ALL_SOLID':'전고체전지',
  'BAT_RECYCLING':'배터리 리사이클링',
  'BAT_EQUIPMENT':'2차전지 장비',
 }),
 'BIOTECH': ('바이오·의료', {
  'BIO_ONCOLOGY':'항암·면역치료',
  'BIO_GENE':'유전자·세포치료',
  'BIO_OBESITY':'비만·대사질환',
  'BIO_CDMO':'바이오 CDMO·CMO',
  'BIO_DIAGNOSTIC':'체외진단·의료AI',
  'BIO_MEDDEVICE':'의료기기·로봇수술',
 }),
 'MOBILITY': ('모빌리티·운송', {
  'MOB_EV':'전기차 부품·전장',
  'MOB_AUTONOMOUS':'자율주행·ADAS',
  'MOB_SHIP':'조선·LNG·엔진',
  'MOB_PORT':'항만·물류 자동화',
 }),
 'DISPLAY': ('디스플레이·광학', {
  'DIS_OLED':'OLED·증착장비',
  'DIS_MICROLED':'마이크로LED·광학',
  'DIS_MATERIAL':'디스플레이 소재·부품',
 }),
 'DIGITAL_ASSET': ('디지털자산·핀테크', {
  'FIN_PAYMENT':'결제·전자금융',
  'FIN_BLOCKCHAIN':'블록체인 인프라',
  'FIN_FINTECH':'증권·핀테크 플랫폼',
 })
}
# V12.4 fine-grained expansion (classification IDs only; NO ticker guesses)
SECTORS['SEMICON'][1].update({
 'SEMI_RETICLE':'EUV·DUV 포토마스크·레티클',
 'SEMI_TRACK':'포토 도포·현상 트랙',
 'SEMI_DRY_STRIP':'애싱·드라이 스트립·디스컴',
 'SEMI_ION_IMPLANT':'이온주입·도핑 장비',
 'SEMI_EPI':'에피택시·결정성장',
 'SEMI_HYBRID_BOND':'하이브리드 본딩·정렬',
 'SEMI_HBM_TEST':'HBM·메모리 패키지 테스트',
 'SEMI_TGV':'유리기판 TGV 드릴링·비아',
 'SEMI_GLASS_METAL':'유리기판 도금·금속배선',
 'SEMI_GLASS_BOND':'유리기판 접합·라미네이션',
 'SEMI_GLASS_INSPECT':'유리기판 검사·계측',
 'SEMI_FOUP':'웨이퍼 캐리어·FOUP',
})
SECTORS['AI_DATACENTER'][1].update({
 'AI_COOL_COLDPLATE':'콜드플레이트·D2C 부품',
 'AI_COOL_REFRIGERANT':'냉매·절연냉각유',
 'AI_COOL_MONITOR':'열관리 센서·제어',
})
SECTORS['SECURITY'][1].update({
 'SEC_AI_SOC':'AI 보안·관제·SIEM·SOC',
 'SEC_HARDWARE':'보안칩·HSM·보안반도체',
})
SECTORS['QUANTUM'][1].update({
 'QUANTUM_CONTROL':'양자 제어전자장비·측정',
 'QUANTUM_SOFTWARE':'양자 소프트웨어·알고리즘',
})
SECTORS['SPACE'][1].update({
 'SPACE_RF':'우주용 RF·우주급 부품',
})
SECTORS['AEROSPACE'][1].update({
 'AIR_COMPOSITE':'항공 복합소재·경량화',
})
SECTORS['DEFENSE'][1].update({
 'DEF_COUNTER_UAS':'안티드론·드론 탐지·요격',
})
SECTORS['ROBOTICS'][1].update({
 'ROBOT_HAND':'로봇손·정밀 그리퍼',
})

LEAVES={leaf:{'parent':parent,'label':label} for parent,(_,items) in SECTORS.items() for leaf,label in items.items()}
PARENTS={key:label for key,(label,_) in SECTORS.items()}
ANCHOR_CODES={'005930':{'parent':'DIVERSIFIED','label':'삼성전자','tags':['SEMI_MEMORY','SEMI_FOUNDRY','AI_MEMORY_NETWORK']},
              '000660':{'parent':'SEMICON','label':'SK하이닉스','tags':['SEMI_MEMORY','AI_MEMORY_NETWORK','SEMI_PACKAGING']}}
MAX_META_CAP=30_000_000_000_000

def safe_code(value):
    s=str(value or '').strip()
    return s.zfill(6) if s.isdigit() and len(s)<=6 else s

def load_reviewed(path=None):
    """Manually reviewed mapping file only; entries declare venue-independent primary leaf.
    The classification is not a live quote. CSV format: code,primary_leaf,reviewed,theme_tags.
    """
    data={}
    if not path:return data
    with open(path,encoding='utf-8-sig',newline='') as f:
        for row in csv.DictReader(f):
            code=safe_code(row.get('code'))
            leaf=(row.get('primary_leaf') or '').strip()
            if code in data or not code or leaf not in LEAVES or str(row.get('reviewed')).strip().lower() not in ('yes','true','1'):
                raise ValueError(f'Unreviewed/invalid/duplicate taxonomy membership: {code}/{leaf}')
            tags=[t.strip() for t in str(row.get('theme_tags') or '').split('|') if t.strip()]
            if any(t not in LEAVES for t in tags):raise ValueError(f'Unknown overlay tags for {code}')
            data[code]={'primary_leaf':leaf,'parent':LEAVES[leaf]['parent'],'tags':tags,'provenance':'REVIEWED_CSV'}
    return data

def attach_taxonomy(frame,reviewed):
    """Copy frame, never mutate upstream snapshot; leave unrelated symbols unclassified.
    Anchor symbols are excluded from leaf grouping but counted exactly once in parent gross.
    """
    x=dict(frame)
    stocks=[]
    for s in frame.get('stocks',[]):
        if not isinstance(s,dict):continue
        r=dict(s);code=safe_code(r.get('code'));r['code']=code
        if code in ANCHOR_CODES:
            a=ANCHOR_CODES[code];r['parent_sector']=a['parent'];r['sector']='ANCHOR_'+a['parent']
            r['primary_leaf']=None;r['overlay_tags']=a['tags'];r['is_mega_anchor']=True;r['taxonomy_provenance']='EXPLICIT_ANCHOR'
        elif code in reviewed:
            m=reviewed[code];r['parent_sector']=m['parent']
            r['primary_leaf']=m['primary_leaf'];r['overlay_tags']=m['tags'];r['taxonomy_provenance']=m['provenance']
            cap=r.get('market_cap_krw')
            try:r['is_mega_anchor']=float(cap)>=MAX_META_CAP
            except (ValueError,TypeError):r['is_mega_anchor']=False
            # Dynamic mega-caps are removed from leaf eligibility/breadth, not hidden from gross.
            r['sector']=('ANCHOR_'+m['parent']) if r['is_mega_anchor'] else m['primary_leaf']
        else:
            # Unclassified data cannot invent an industry from company name.
            r['parent_sector']=None;r['sector']='UNCLASSIFIED';r['primary_leaf']=None
            r['overlay_tags']=[];r['taxonomy_provenance']='UNVERIFIED';r['is_mega_anchor']=False
        stocks.append(r)
    x['stocks']=stocks;x['taxonomy_version']=VERSION
    return x


def describe():
    return [{'parent_id':p,'parent':PARENTS[p], 'leaves':[{'id':leaf,'label':label} for leaf,label in group.items()]}
            for p,(_,group) in SECTORS.items()]
