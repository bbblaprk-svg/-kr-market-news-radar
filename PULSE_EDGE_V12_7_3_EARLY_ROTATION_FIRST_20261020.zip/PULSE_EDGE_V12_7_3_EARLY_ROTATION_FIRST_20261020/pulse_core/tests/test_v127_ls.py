import copy, tempfile, unittest, os, json
from pathlib import Path
from datetime import datetime,timedelta,timezone,time
from zoneinfo import ZoneInfo
from engine_ls_core import source_ok,frame_gate
from reader_v127_ls import validate_url
from engine_v127_ls import scan_fine_first,_rotation_display,_rotation_sort_key
from baseline_v127_ls import open_store,add_trading_day,record_pair,compute_reference
from taxonomy_v123 import VERSION
KST=ZoneInfo('Asia/Seoul');NOW=datetime(2026,10,19,8,21,tzinfo=KST)
M={f'{i:06d}':{'primary_leaf':'SEMI_TGV','parent':'SEMICON','tags':[],'provenance':'REVIEWED_CSV'} for i in range(1,4)}

def frames():
    base=datetime(2026,10,19,8,19,tzinfo=KST);out=[];tot=[10_000_000]*3
    for ix in range(3):
        ts=base+timedelta(minutes=ix)
        if ix:tot=[x+(50_000_000 if ix==1 else 200_000_000) for x in tot]
        rows=[]
        for j in range(3):
            rows.append({'code':f'{j+1:06d}','name':f'T{j+1}','instrument_type':'COMMON','market_cap_krw':400_000_000_000,'price':99+ix,'prev_close':100,'turnover_cum':tot[j],'vwap':99,'price_hold':True,'buy_dominance_verified':True,'absorption_verified':True,'compression_verified':True,'gem_type':'A','event_time':ts.isoformat(),'received_at':ts.isoformat(),'micro_event_time':ts.isoformat(),'hold_event_time':ts.isoformat(),'absorption_event_time':ts.isoformat(),'compression_event_time':ts.isoformat()})
        out.append({'source':'LS_OPENAPI_V127','provider':'LS_OPENAPI','frame_complete':True,'venue':'NXT','session':'PRE','generated_at':ts.isoformat(),'stocks':rows,'eligible_universe_total':3,'trading_day_confirmed':True,'taxonomy_universe_confirmed':True,'benchmark_scope':'NXT:PRE','market_return':0})
    return out

def baseline():return {'provenance':'LOCAL_COMPUTED_FROM_LS_ARCHIVE','verified':True,'venue':'NXT','session':'PRE','taxonomy_version':VERSION,'days':{'SEMI_TGV':20},'current_strength':{'SEMI_TGV':1.6},'previous_strength':{'SEMI_TGV':1.3}}
class TestLSProvider(unittest.TestCase):
    def test_ls_source_only(self):
        f=frames()[-1];self.assertTrue(source_ok(f));bad=copy.deepcopy(f);bad['source']='KIWOOM_V83';self.assertFalse(source_ok(bad))
    def test_partial_frame_rejected(self):
        f=frames()[-1];f['frame_complete']=False;self.assertEqual(frame_gate(f,NOW),'LS PARTIAL_FRAME')
    def test_ls_baseline_provenance_is_required(self):
        a,b,c=frames()
        r=scan_fine_first(c,b,a,NOW,M,baseline(),{'SEMI_TGV':'S2'})
        self.assertEqual(r['fine_sector_gate']['baseline_source'],'LOCAL_ARCHIVE')
        s=next(x for x in r['sectors'] if x['sector']=='SEMI_TGV')
        self.assertEqual(s['relative_turnover'],1.6)
        x=baseline();x['provenance']='LOCAL_COMPUTED_FROM_KIWOOM_ARCHIVE'
        r=scan_fine_first(c,b,a,NOW,M,x,{'SEMI_TGV':'S2'})
        self.assertEqual(r['fine_sector_gate']['baseline_source'],'NOT_VERIFIED')
        s=next(x for x in r['sectors'] if x['sector']=='SEMI_TGV')
        self.assertIsNone(s['relative_turnover'])
        self.assertNotIn(s['state'],('S2','S3'))
    def test_baseline_archive_accepts_ls_pairs(self):
        a,b,c=frames()
        with tempfile.TemporaryDirectory() as td:
            con=open_store(Path(td)/'x.sqlite3');add_trading_day(con,'NXT','2026-10-19');self.assertTrue(record_pair(con,b,c,M));con.close()
    def test_public_http_bridge_is_rejected(self):
        old=os.environ.pop('LS_V127_ALLOW_HTTP_INTERNAL',None)
        try:self.assertEqual(validate_url('http://bridge.example/pulse/frame/KRX',{'bridge.example'}),'HTTPS_REQUIRED')
        finally:
            if old is not None:os.environ['LS_V127_ALLOW_HTTP_INTERNAL']=old
    def test_allowlisted_private_http_requires_explicit_switch(self):
        old=os.environ.get('LS_V127_ALLOW_HTTP_INTERNAL');os.environ['LS_V127_ALLOW_HTTP_INTERNAL']='true'
        try:self.assertIsNone(validate_url('http://ls-bridge:10000/pulse/frame/KRX',{'ls-bridge'}))
        finally:
            if old is None:os.environ.pop('LS_V127_ALLOW_HTTP_INTERNAL',None)
            else:os.environ['LS_V127_ALLOW_HTTP_INTERNAL']=old
    def test_early_rotation_is_display_only(self):
        stage,s2,s3=_rotation_display('S1',complete=True,relative=1.15,share_growth=1.10,shift_pp=.25,breadth=.48,adv_count=3,leader_share=.60,rs=.003,rs_velocity=.001,diffusion_growth=.05,previous_relative=1.05,rs_acceleration=0,buy_count=1,hold_count=1)
        self.assertEqual(stage,'EARLY_ROTATION')
        self.assertGreaterEqual(s2,66.7)
        self.assertLess(s3,100)
    def test_s2_and_s3_display_stages_do_not_change_state(self):
        a=_rotation_display('S2',complete=True,relative=1.3,share_growth=1.2,shift_pp=.2,breadth=.55,adv_count=3,leader_share=.6,rs=.01,rs_velocity=.003,diffusion_growth=.03)[0]
        b=_rotation_display('S3',complete=True,relative=1.6,share_growth=1.3,shift_pp=.4,breadth=.7,adv_count=4,leader_share=.5,rs=.02,rs_velocity=.004,diffusion_growth=.04,previous_relative=1.3,rs_acceleration=0,buy_count=3,hold_count=3)[0]
        self.assertEqual(a,'S2_MONEY_MOVE');self.assertEqual(b,'S3_CONFIRMED')
    def test_exit_and_weakening_display(self):
        x=_rotation_display('S5',complete=True,relative=.8,share_growth=.6,shift_pp=-.3,breadth=.2,adv_count=0,leader_share=.8,rs=-.02,rs_velocity=-.01,diffusion_growth=-.2)[0]
        y=_rotation_display('S1',complete=True,relative=1.0,share_growth=.9,shift_pp=-.1,breadth=.3,adv_count=1,leader_share=.9,rs=-.001,rs_velocity=-.002,diffusion_growth=-.1)[0]
        self.assertEqual(x,'S5_EXIT');self.assertEqual(y,'WEAKENING')
    def test_rotation_sort_prefers_stage_over_absolute_turnover(self):
        early={'rotation_stage':'EARLY_ROTATION','s2_gate_progress_pct':77.8,'s3_gate_progress_pct':50,'nonmega_share_growth':1.1,'relative_turnover':1.1,'gross_interval_turnover_krw':10,'sector':'E'}
        huge={'rotation_stage':'OTHER','s2_gate_progress_pct':33.3,'s3_gate_progress_pct':20,'nonmega_share_growth':.9,'relative_turnover':.8,'gross_interval_turnover_krw':999999999,'sector':'H'}
        self.assertEqual(sorted([huge,early],key=_rotation_sort_key)[0]['sector'],'E')
if __name__=='__main__':unittest.main()
