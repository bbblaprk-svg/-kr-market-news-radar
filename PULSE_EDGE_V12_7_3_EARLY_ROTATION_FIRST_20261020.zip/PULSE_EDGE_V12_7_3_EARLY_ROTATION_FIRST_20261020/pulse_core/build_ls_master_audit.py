import os,json,csv,hashlib,argparse
from pathlib import Path
from datetime import datetime,timezone
from taxonomy_v123 import ANCHOR_CODES,LEAVES,safe_code

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--universe',required=True);ap.add_argument('--reviewed',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
    u=json.loads(Path(a.universe).read_text(encoding='utf-8'));rows=u.get('rows',[]);reviewed={}
    with open(a.reviewed,encoding='utf-8-sig',newline='') as f:
        for r in csv.DictReader(f):
            if str(r.get('reviewed','')).lower() in ('yes','true','1') and r.get('primary_leaf') in LEAVES:reviewed[safe_code(r.get('code'))]=r.get('primary_leaf')
    eligible=[x for x in rows if x.get('common_stock') is True and float(x.get('market_cap_krw') or 0)>=200_000_000_000]
    classified=[x for x in eligible if safe_code(x.get('code')) in reviewed or safe_code(x.get('code')) in ANCHOR_CODES]
    nxt=[x for x in eligible if x.get('nxt_eligible') is True]
    status='VERIFIED' if u.get('meta',{}).get('complete') is True and u.get('meta',{}).get('cap_complete') is True and u.get('meta',{}).get('nxt_complete') is True and len(classified)==len(eligible) else 'BLOCKED'
    payload={'status':status,'verified_at':datetime.now(timezone.utc).isoformat(),'krx_eligible_rows':len(eligible),'nxt_eligible_rows':len(nxt),'classified_eligible_rows':len(classified),'taxonomy_complete':len(classified)==len(eligible),'universe_sha256':hashlib.sha256(Path(a.universe).read_bytes()).hexdigest(),'reviewed_sha256':hashlib.sha256(Path(a.reviewed).read_bytes()).hexdigest(),'source':'LOCAL_LS_UNIVERSE_AND_REVIEWED_MAP'}
    Path(a.out).write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(payload,ensure_ascii=False))
if __name__=='__main__':main()
