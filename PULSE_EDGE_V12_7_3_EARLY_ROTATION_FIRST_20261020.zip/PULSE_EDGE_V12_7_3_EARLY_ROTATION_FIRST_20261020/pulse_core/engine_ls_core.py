"""Provider-specific safety core for PULSE EDGE V12.7 using LS OpenAPI only.
No orders, no account access, no mixed KIS/Kiwoom market data.
"""
from __future__ import annotations
import math
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
KST=ZoneInfo('Asia/Seoul')
MIN_CAP=200_000_000_000
COVERAGE_MIN=.80
FRESH_SEC=90
DEEP_FRESH_SEC=12

def timeparse(x):
    if not isinstance(x,str):return None
    try:
        d=datetime.fromisoformat(x.replace('Z','+00:00'))
        return d.astimezone(timezone.utc) if d.tzinfo else None
    except (TypeError,ValueError):return None

def session(venue,t):
    if venue not in ('KRX','NXT') or not t:return 'CLOSED'
    dt=t.astimezone(KST);sec=dt.hour*3600+dt.minute*60+dt.second
    if venue=='KRX':return 'REGULAR' if 32400<=sec<55800 else 'CLOSED'
    if 28800<=sec<31800:return 'PRE'
    if 32430<=sec<55200:return 'MAIN'
    if 56400<=sec<72000:return 'AFTER'
    return 'CLOSED'

def number(x):
    if isinstance(x,bool) or x is None:return None
    try:
        v=float(str(x).replace(',',''))
        return v if math.isfinite(v) else None
    except (ValueError,TypeError):return None

def truth(v):return v is True

def source_ok(f):
    if not isinstance(f,dict) or f.get('archive') is True:return False
    src=str(f.get('source','')).upper()
    return src.startswith('LS_OPENAPI') and str(f.get('provider','LS_OPENAPI')).upper().startswith('LS')

def fresh(ts,now,limit=FRESH_SEC):
    d=timeparse(ts)
    if not d:return False
    age=(now-d).total_seconds()
    return -3<=age<=limit

def is_common_stock(s):
    return s.get('instrument_type')=='COMMON' and (number(s.get('market_cap_krw')) or 0)>=MIN_CAP

def clean_row(s,f,now):
    if not isinstance(s,dict):return None
    code=str(s.get('code','')).strip();venue=f.get('venue');sess=f.get('session')
    if not code:return None
    event=timeparse(s.get('event_time'));rec=timeparse(s.get('received_at'))
    valid=(bool(event and rec) and event<=rec and fresh(s.get('event_time'),now,FRESH_SEC)
           and fresh(s.get('received_at'),now,FRESH_SEC) and session(venue,event)==sess
           and session(venue,rec)==sess and event.astimezone(KST).date()==now.astimezone(KST).date())
    return dict(s,code=code,_valid=bool(valid),_current_price=number(s.get('price')),
                _turnover=number(s.get('turnover_cum')),_prev_close=number(s.get('prev_close')),
                _vwap=number(s.get('vwap')),_cap=number(s.get('market_cap_krw')))

def frame_gate(frame,now):
    if not isinstance(frame,dict) or not source_ok(frame):return 'LS UNAVAILABLE'
    venue=frame.get('venue');sess=frame.get('session');ts=timeparse(frame.get('generated_at'))
    if venue not in ('KRX','NXT') or sess!=session(venue,now):return 'SESSION_CLOSED_OR_CONFLICT'
    if not ts or not fresh(frame.get('generated_at'),now,FRESH_SEC):return 'LS STALE'
    if frame.get('frame_complete') is not True:return 'LS PARTIAL_FRAME'
    if not isinstance(frame.get('stocks'),list):return 'LS UNAVAILABLE'
    return 'LIVE_FRAME'
