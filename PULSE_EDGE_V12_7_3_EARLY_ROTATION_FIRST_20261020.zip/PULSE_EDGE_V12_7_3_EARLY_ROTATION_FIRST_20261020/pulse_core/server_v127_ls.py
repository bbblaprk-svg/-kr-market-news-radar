"""PULSE EDGE V12.7 LS-provider evaluator.
LS supplies data. PULSE decides. No account/order routes are used.
"""
import json,os,threading,time,logging,sqlite3,urllib.request
from pathlib import Path
from datetime import datetime,timezone
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import parse_qs,urlsplit
from engine_ls_core import fresh,timeparse
from master_guard_v127_ls import guarded_scan_fine,_load_audit
from reader_v127_ls import fetch
from baseline_v127_ls import open_store,compute_reference,record_pair,load_calendar_file
from taxonomy_v123 import load_reviewed,describe,VERSION,ANCHOR_CODES

class FeedUnavailable(RuntimeError):pass
class StaleFrame(RuntimeError):pass
RELEASE='PULSE_EDGE_V12_7_3_EARLY_ROTATION_FIRST'
PORT=int(os.getenv('V127_PORT','18127'))
POLL_SECONDS=max(30,int(os.getenv('V127_POLL_SECONDS','60')))
TTL_SECONDS=max(15,int(os.getenv('V127_UI_TTL_SECONDS','90')))
REVIEW_PATH=os.getenv('V127_REVIEWED_CSV',str(Path(__file__).with_name('membership_reviewed.csv')))
DB_PATH=os.getenv('V127_ARCHIVE_DB','/tmp/v127_ls_sector_history.sqlite3')
CALENDAR_PATH=os.getenv('V127_TRADING_CALENDAR_JSON',str(Path(__file__).with_name('trading_calendar.json')))
DEEP_URL=os.getenv('LS_V127_DEEP_TARGET_URL','')
BRIDGE_TOKEN=os.getenv('PULSE_BRIDGE_TOKEN','')
BRIDGE_STATUS_URL=os.getenv('LS_V127_BRIDGE_STATUS_URL','')
BRIDGE_REST_VERIFY_URL=os.getenv('LS_V127_BRIDGE_REST_VERIFY_URL','')
DEEP_MAX=max(1,min(30,int(os.getenv('V127_DEEP_TARGET_MAX','30'))))
REVIEWED=load_reviewed(REVIEW_PATH)
DATA={};LAST={};PREV={};OLDER={};PREV_SECTORS={};DEEP_BY_VENUE={'KRX':[],'NXT':[]};LOCK=threading.RLock()
LOG=logging.getLogger('pulse_v127_ls');logging.basicConfig(level=logging.INFO)

def _blocked(venue,status,reason,now=None):
    now=now or datetime.now(timezone.utc)
    return {'release':RELEASE,'venue':venue,'data_status':status,'reason':reason,'as_of':now.isoformat(),'qualified_count':0,'sectors':[],'leaf_money':[],'rotation_board':{'EARLY_ROTATION':[],'S2_MONEY_MOVE':[],'S3_CONFIRMED':[],'WEAKENING_OR_EXIT':[]},'parent_money':[],'candidates':[],'alerts':[],'ready_for_entry':False,'warnings':[reason]}

def _mask(data,now=None):
    now=now or datetime.now(timezone.utc)
    if not isinstance(data,dict):return _blocked('UNKNOWN','LS UNAVAILABLE','NO_SNAPSHOT',now)
    if data.get('data_status')!='LIVE_FRAME':
        out=dict(data);out['qualified_count']=0;out['ready_for_entry']=False;out['entry_signal_live']=False;return out
    if not fresh(data.get('as_of'),now,TTL_SECONDS):return _blocked(data.get('venue'),'LS STALE','OUTPUT_TTL_EXPIRED',now)
    out=dict(data);masked=[]
    for c in data.get('candidates',[]):
        item=dict(c)
        if item.get('state') in ('ENTRY','PRE-ENTRY'):
            expiry=timeparse(item.get('evidence_valid_until'))
            if expiry is None or now>expiry:item['state']='WATCH_STALE_EVIDENCE';item.setdefault('reasons_missing',[]).append('ENTRY_EVIDENCE_EXPIRED');item['entry_valid_for_sec']=0
            else:item['entry_valid_for_sec']=round(max(0,(expiry-now).total_seconds()),3)
        masked.append(item)
    out['candidates']=masked;out['qualified_count']=sum(c.get('state')=='ENTRY' for c in masked)
    infra=bool(out.get('mapping_status',{}).get('ready') and out.get('fine_sector_gate',{}).get('baseline_source')=='LOCAL_ARCHIVE')
    out['ready_for_entry']=infra;out['entry_signal_live']=bool(infra and out['qualified_count']);return out

def _events(prev,new):
    if new.get('data_status')!='LIVE_FRAME' or not new.get('mapping_status',{}).get('ready'):return []
    osx={x['sector']:x['state'] for x in (prev or {}).get('sectors',[]) if isinstance(x,dict)};oc={x['code']:x['state'] for x in (prev or {}).get('candidates',[]) if isinstance(x,dict)};ev=[]
    for s in new.get('sectors',[]):
        old=osx.get(s['sector'],'NONE');state=s.get('state')
        if old!=state and state in ('S2','S3','S5'):ev.append({'kind':'SECTOR_TRANSITION','id':s['sector'],'from':old,'to':state})
    for c in new.get('candidates',[]):
        old=oc.get(c['code'],'NONE');state=c.get('state')
        if old!=state and state=='ENTRY':ev.append({'kind':'STOCK_ENTRY','id':c['code'],'from':old,'to':state})
    return ev

def _persist(con,venue,session,events,when):
    con.execute('CREATE TABLE IF NOT EXISTS alerts(event_id INTEGER PRIMARY KEY AUTOINCREMENT,utc_time TEXT,venue TEXT,session TEXT,kind TEXT,target TEXT,old_state TEXT,new_state TEXT)')
    with con:
        for e in events:con.execute('INSERT INTO alerts(utc_time,venue,session,kind,target,old_state,new_state) VALUES (?,?,?,?,?,?,?)',(when,venue,session,e['kind'],e['id'],e['from'],e['to']))

def _deep_targets(frame,out,previous):
    leaves={s['sector'] for s in out.get('sectors',[]) if s.get('state') in ('S2','S3')};old={str(x.get('code')):x for x in (previous or {}).get('stocks',[]) if isinstance(x,dict)};rows=[]
    for r in frame.get('stocks',[]):
        code=str(r.get('code','')).zfill(6)
        if code in ANCHOR_CODES:continue
        m=REVIEWED.get(code)
        if not m or m.get('primary_leaf') not in leaves:continue
        nowv=float(r.get('turnover_cum') or 0);prevv=float(old.get(code,{}).get('turnover_cum') or 0);delta=max(0,nowv-prevv)
        rows.append({'code':code,'name':r.get('name'),'market':r.get('market'),'delta':delta})
    rows.sort(key=lambda x:-x['delta']);return [{k:v for k,v in x.items() if k!='delta'} for x in rows[:20]]

def _bridge_json(url,timeout=6):
    if not url:return {'status':'UNCONFIGURED'}
    headers={'Accept':'application/json','Cache-Control':'no-store'}
    if BRIDGE_TOKEN:headers['X-Pulse-Bridge-Token']=BRIDGE_TOKEN
    try:
        req=urllib.request.Request(url,headers=headers,method='GET')
        with urllib.request.urlopen(req,timeout=timeout) as r:
            d=json.loads(r.read(2_000_000))
            return d if isinstance(d,dict) else {'status':'INVALID_RESPONSE'}
    except Exception as e:return {'status':'ERROR','reason':f'{type(e).__name__}:{str(e)[:160]}'}

def _provider_status(run_rest_probe=False):
    st=_bridge_json(BRIDGE_STATUS_URL)
    feed=st.get('feed',{}) if isinstance(st,dict) else {}
    out={'provider':'LS_OPENAPI','orders_enabled':False,'bridge_configured':bool(st.get('configured')) if isinstance(st,dict) else False,
         'bridge_source':st.get('source') if isinstance(st,dict) else None,'krx_universe':st.get('krx_universe',0) if isinstance(st,dict) else 0,
         'nxt_universe':st.get('nxt_universe',0) if isinstance(st,dict) else 0,'feed_connected':bool(feed.get('connected')),
         'feed_running':bool(feed.get('running')),'feed_stream_mode':feed.get('streamMode'),'deep_target_count':st.get('deep_target_count',0) if isinstance(st,dict) else 0,
         'ws_acked_targets':feed.get('ackedTargets',0),'ws_first_packet_targets':feed.get('firstPacketTargets',0),'ws_fresh_targets':feed.get('freshTargets',0),
         'ws_verified_targets':feed.get('verifiedTargets',0),'last_packet_age_ms':feed.get('lastPacketAgeMs'),'last_error':str(feed.get('lastError') or '')[:180] or None}
    if run_rest_probe:
        probe=_bridge_json(BRIDGE_REST_VERIFY_URL,20)
        out['rest_probe']={k:probe.get(k) for k in ('configured','status','reason','token_ready','quote_ok','quote_count','codes','observed_at','error') if isinstance(probe,dict) and k in probe}
    return out

def _push_deep_targets():
    if not DEEP_URL:return
    with LOCK:
        combined=[];seen=set()
        for v in ('NXT','KRX'):
            for x in DEEP_BY_VENUE[v]:
                if x['code'] not in seen:combined.append(x);seen.add(x['code'])
        combined=combined[:DEEP_MAX]
    try:
        body=json.dumps({'targets':combined}).encode();headers={'Content-Type':'application/json'}
        if BRIDGE_TOKEN:headers['X-Pulse-Bridge-Token']=BRIDGE_TOKEN
        req=urllib.request.Request(DEEP_URL,data=body,headers=headers,method='POST')
        with urllib.request.urlopen(req,timeout=8) as r:r.read(1024)
    except Exception as e:LOG.warning('deep target update failed: %s',e)

def poll_venue(venue,fetcher=fetch):
    started=time.monotonic();now=datetime.now(timezone.utc)
    try:
        frame=fetcher(venue)
        if not isinstance(frame,dict) or frame.get('status') or frame.get('venue')!=venue:
            if isinstance(frame,dict) and frame.get('status')=='LS UNAVAILABLE':raise FeedUnavailable(str(frame.get('reason','LS_SOURCE_DOWN')))
            raise ValueError(str((frame or {}).get('reason','INVALID_LS_FRAME')))
        if not fresh(frame.get('generated_at'),now,90):raise StaleFrame('FRAME_STALE_OR_UNDATED')
        older,previous=OLDER.get(venue),PREV.get(venue);prior=PREV_SECTORS.get(venue,{})
        con=open_store(DB_PATH)
        try:
            cal=load_calendar_file(con,CALENDAR_PATH);baseline=compute_reference(con,older,previous,frame,REVIEWED) if older and previous else None
            out=guarded_scan_fine(frame,previous,now,REVIEWED,older,baseline,prior);out['release']=RELEASE;out['calendar_status']={'local_calendar_rows_loaded':cal}
            if out.get('data_status')!='LIVE_FRAME':raise ValueError(out.get('data_status','FRAME_REJECTED'))
            if previous:record_pair(con,previous,frame,REVIEWED)
            ev=_events(LAST.get(venue),out);out['alerts']=ev;_persist(con,venue,frame.get('session'),ev,now.isoformat())
            with LOCK:
                LAST[venue]=out;DATA[venue]=out;OLDER[venue],PREV[venue]=previous,frame;PREV_SECTORS[venue]={x['sector']:x['state'] for x in out.get('sectors',[]) if x.get('state') in ('S2','S3')};DEEP_BY_VENUE[venue]=_deep_targets(frame,out,previous)
        finally:con.close()
        _push_deep_targets()
    except Exception as e:
        reason=f'{type(e).__name__}:{str(e)[:140]}';LOG.warning('LS fail-closed %s: %s',venue,reason)
        with LOCK:
            DATA[venue]=_blocked(venue,'LS UNAVAILABLE' if isinstance(e,FeedUnavailable) else 'LS STALE' if isinstance(e,StaleFrame) else 'FEED_ERROR',reason,now);OLDER.pop(venue,None);PREV.pop(venue,None);PREV_SECTORS.pop(venue,None);DEEP_BY_VENUE[venue]=[]
    return time.monotonic()-started

def loop(venue):
    while True:
        elapsed=poll_venue(venue);time.sleep(max(1,POLL_SECONDS-elapsed))

PAGE='''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PULSE V12.7.3 LS</title><style>body{font-family:system-ui;background:#0d1726;color:#e4ebf4;max-width:1120px;margin:24px auto;padding:0 15px}section{border:1px solid #38506a;padding:15px;border-radius:12px;margin:12px 0}button{padding:8px 15px;margin-right:8px}table{border-collapse:collapse;width:100%}td,th{padding:8px;border-bottom:1px solid #334;text-align:left;font-size:13px}small{color:#aab8c9}.tag{display:inline-block;padding:3px 7px;border-radius:7px;background:#20364d;margin-right:6px}.early{border-color:#7f6f2e}.s2{border-color:#316983}.s3{border-color:#556bd8}.weak{border-color:#7b4b4b}h3{margin:0 0 10px}</style><h2>PULSE EDGE V12.7.3 · LS / EARLY ROTATION FIRST</h2><button onclick="sel('NXT')">NXT</button><button onclick="sel('KRX')">KRX</button><section><b id="s">loading</b><div id="t"></div><small>표시 우선순위만 EARLY→S2→S3→약화/S5. 숨은진주 심층 게이트는 S2/S3만 허용.</small></section><section class="early"><h3>① 떠오르는 섹터 · EARLY ROTATION</h3><div id="early"></div></section><section class="s2"><h3>② 자금이동 확인 · S2</h3><div id="s2"></div></section><section class="s3"><h3>③ 확정 · S3</h3><div id="s3"></div></section><section class="weak"><h3>④ 약화 / S5 자금이탈</h3><div id="weak"></div></section><section><h3>상방진주 · S2/S3 내부만</h3><div id="c"></div></section><small>LS는 데이터 공급자, PULSE는 판단자. EARLY ROTATION은 관찰 신호이며 ENTRY 권한 없음. 주문 기능 없음.</small><script>let v='NXT';const e=x=>String(x??'—').replace(/[&<>"']/g,z=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[z]));function tb(a){if(!a?.length)return'없음';let cs=[['label','세분'],['state','상태'],['s2_gate_progress_pct','S2진척%'],['s3_gate_progress_pct','S3진척%'],['relative_turnover','20D강도'],['nonmega_share_growth','점유배수'],['nonmega_share_delta_pp','점유Δpp'],['rs_velocity','RS속도'],['breadth','Breadth']];return'<table><tr>'+cs.map(x=>'<th>'+e(x[1])+'</th>').join('')+'</tr>'+a.map(r=>'<tr>'+cs.map(x=>'<td>'+e(r[x[0]])+'</td>').join('')+'</tr>').join('')+'</table>'}function cand(a){if(!a?.length)return'없음';let cs=[['name','종목'],['fine_sector_state','섹터'],['state','단계'],['price','현재가'],['entry_valid_for_sec','잔여초']];return'<table><tr>'+cs.map(x=>'<th>'+e(x[1])+'</th>').join('')+'</tr>'+a.map(r=>'<tr>'+cs.map(x=>'<td>'+e(r[x[0]])+'</td>').join('')+'</tr>').join('')+'</table>'}function sel(x){v=x;load()}async function load(){let d=await(await fetch('/api/scan?venue='+v,{cache:'no-store'})).json();s.textContent=v+' '+d.data_status+' ENTRY '+(d.qualified_count||0);t.textContent=d.as_of||'';let b=d.rotation_board||{};early.innerHTML=tb(b.EARLY_ROTATION);s2.innerHTML=tb(b.S2_MONEY_MOVE);s3.innerHTML=tb(b.S3_CONFIRMED);weak.innerHTML=tb(b.WEAKENING_OR_EXIT);c.innerHTML=cand(d.candidates)}load();setInterval(load,2000)</script></html>'''

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*a):pass
    def do_GET(self):
        u=urlsplit(self.path)
        if u.path in ('/','/dashboard'):data=PAGE.encode();ctype='text/html; charset=utf-8'
        elif u.path in ('/api/scan','/health','/ready','/api/taxonomy','/api/mapping/status','/api/events','/api/provider/status','/api/provider/verify'):
            venue=parse_qs(u.query).get('venue',['NXT'])[0].upper()
            if venue not in ('KRX','NXT'):self.send_error(400);return
            with LOCK:d=_mask(DATA.get(venue),datetime.now(timezone.utc))
            if u.path=='/health':d={'service':RELEASE,'alive':True,'orders_enabled':False,'provider':'LS_OPENAPI'}
            elif u.path=='/ready':d={'service':RELEASE,'ready_for_entry':d.get('ready_for_entry',False),'entry_signal_live':d.get('entry_signal_live',False),'data_status':d.get('data_status')}
            elif u.path=='/api/provider/status':d=_provider_status(False)
            elif u.path=='/api/provider/verify':d=_provider_status(True)
            elif u.path=='/api/taxonomy':d={'version':VERSION,'taxonomy':describe(),'mapping_count':len(REVIEWED)}
            elif u.path=='/api/mapping/status':d=_load_audit()
            elif u.path=='/api/events':
                con=open_store(DB_PATH)
                try:rs=con.execute('SELECT event_id,utc_time,venue,session,kind,target,old_state,new_state FROM alerts ORDER BY event_id DESC LIMIT 50').fetchall() if con.execute("SELECT COUNT(*) FROM sqlite_master WHERE name='alerts'").fetchone()[0] else []
                finally:con.close()
                d={'events':[dict(zip(('event_id','utc_time','venue','session','kind','target','old_state','new_state'),r)) for r in rs],'delivery':'LOCAL_QUEUE_ONLY'}
            data=json.dumps(d,ensure_ascii=False).encode();ctype='application/json; charset=utf-8'
        else:self.send_error(404);return
        self.send_response(200);self.send_header('Content-Type',ctype);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)

def main():
    for v in ('NXT','KRX'):threading.Thread(target=loop,args=(v,),daemon=True).start()
    ThreadingHTTPServer(('0.0.0.0',PORT),Handler).serve_forever()
if __name__=='__main__':main()
