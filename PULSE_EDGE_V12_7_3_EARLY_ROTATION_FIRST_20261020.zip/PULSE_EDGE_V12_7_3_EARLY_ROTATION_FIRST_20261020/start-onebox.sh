#!/usr/bin/env bash
set -euo pipefail
: "${PULSE_BRIDGE_TOKEN:?Set PULSE_BRIDGE_TOKEN in Render secret store}"
mkdir -p /data
for f in membership_reviewed.csv trading_calendar.json; do [ -f "/data/$f" ] || cp "/app/runtime/$f" "/data/$f"; done
export LS_OPENAPI_ENABLED="${LS_OPENAPI_ENABLED:-true}"
export LS_BASE_URL="${LS_BASE_URL:-https://openapi.ls-sec.co.kr:8080}"
export LS_REALTIME_WS_URL="${LS_REALTIME_WS_URL:-wss://openapi.ls-sec.co.kr:9443/websocket}"
export PULSE_LS_UNIVERSE_FILE="${PULSE_LS_UNIVERSE_FILE:-/data/ls_universe.json}"
export PULSE_REVIEWED_JSON="${PULSE_REVIEWED_JSON:-/data/reviewed_membership.json}"
export PULSE_TRADING_CALENDAR="${PULSE_TRADING_CALENDAR:-/data/trading_calendar.json}"
export V127_REVIEWED_CSV="${V127_REVIEWED_CSV:-/data/membership_reviewed.csv}"
export V127_TRADING_CALENDAR_JSON="${V127_TRADING_CALENDAR_JSON:-/data/trading_calendar.json}"
export LS_V127_MASTER_AUDIT_FILE="${LS_V127_MASTER_AUDIT_FILE:-/data/ls_master_audit.json}"
export V127_ARCHIVE_DB="${V127_ARCHIVE_DB:-/data/v1273_ls_sector_history.sqlite3}"
export LS_V127_ALLOWED_HOSTS=127.0.0.1
export LS_V127_FULL_FRAME_URL_KRX=http://127.0.0.1:18080/pulse/frame/KRX
export LS_V127_FULL_FRAME_URL_NXT=http://127.0.0.1:18080/pulse/frame/NXT
export LS_V127_DEEP_TARGET_URL=http://127.0.0.1:18080/pulse/deep-targets
export LS_V127_BRIDGE_STATUS_URL=http://127.0.0.1:18080/pulse/status
export LS_V127_BRIDGE_REST_VERIFY_URL=http://127.0.0.1:18080/pulse/verify/rest
export LS_V127_ALLOW_HTTP_INTERNAL=false
export V127_PORT="${PORT:-10000}"
cleanup(){ kill "${PROVIDER_PID:-}" 2>/dev/null || true; }
trap cleanup EXIT INT TERM
(cd /app/pulse_bridge && PROVIDER_PORT=18080 exec node server.js) & PROVIDER_PID=$!
for i in $(seq 1 30); do curl -fsS http://127.0.0.1:18080/provider/health >/dev/null && break; kill -0 "$PROVIDER_PID" 2>/dev/null || { echo 'LS provider exited'; exit 1; }; sleep 1; done
if [ "${AUTO_BUILD_LS_UNIVERSE:-false}" = "true" ] && [ ! -s "$PULSE_LS_UNIVERSE_FILE" ]; then (cd /app/pulse_bridge && node universe_builder.js) > /data/universe_builder.log 2>&1 & fi
cd /app/pulse_core
exec python3 server_v127_ls.py
