import csv,json,sys
src=sys.argv[1];dst=sys.argv[2];out={}
with open(src,encoding='utf-8-sig',newline='') as f:
    for r in csv.DictReader(f):
        if str(r.get('reviewed','')).lower() not in ('yes','true','1'):continue
        c=str(r.get('code','')).zfill(6);out[c]={'primary_leaf':r.get('primary_leaf'),'theme_tags':r.get('theme_tags','')}
with open(dst,'w',encoding='utf-8') as f:json.dump(out,f,ensure_ascii=False,indent=2)
print(json.dumps({'rows':len(out),'out':dst},ensure_ascii=False))
