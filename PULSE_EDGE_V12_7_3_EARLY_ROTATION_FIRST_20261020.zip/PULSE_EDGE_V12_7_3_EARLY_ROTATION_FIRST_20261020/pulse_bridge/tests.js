const assert=require('assert');const fs=require('fs');const crypto=require('crypto');
process.env.NODE_ENV='test';process.env.PULSE_DEEP_TARGET_MAX='30';
const b=require('./lib/pulseFrameBridge');
const feed=require('../ls_provider_original/lib/realtimeFeed');
const providerDir='../ls_provider_original/lib/';
const expected={
 'lsOpenApi.js':'ac44a47196bf00bc8dc878bc39f514265614db6c76b6c0761f03940a7b7c43f8',
 'realtimeFeed.js':'17ad7201ed3ad1273d32d8dbab619d473a90c45a634e8d7d13257ac620105013',
 'marketSession.js':'c9e626ac20db888bbdd6fbcda21a1f399518ee359877d647be08cbb134c69144',
 'logger.js':'95dc1a7ddf8942c9a1af65c167543e04d74b739c48f6d809cac8f96b4363198c'};
let passed=0;function test(name,fn){return Promise.resolve().then(fn).then(()=>{passed++;console.log('ok - '+name)})}
(async()=>{
 await test('original LS1943 provider modules are byte-identical',()=>{for(const [f,h] of Object.entries(expected)){const got=crypto.createHash('sha256').update(fs.readFileSync(providerDir+f)).digest('hex');assert.equal(got,h,f)}});
 await test('original OAuth/REST/WS route is preserved',()=>{const s=fs.readFileSync(providerDir+'lsOpenApi.js','utf8'),w=fs.readFileSync(providerDir+'realtimeFeed.js','utf8');assert.ok(s.includes("/oauth2/token"));assert.ok(s.includes("callTr('t8407'"));assert.ok(s.includes("callTr('t1102'"));assert.ok(w.includes("wss://openapi.ls-sec.co.kr:9443/websocket"));assert.ok(w.includes("UNIFIED_FULL=['US3','UH1','UPH']"))});
 await test('PULSE adapter is separate from provider modules',()=>{const s=fs.readFileSync('lib/pulseFrameBridge.js','utf8');assert.ok(s.includes("../../ls_provider_original/lib/lsOpenApi"));assert.ok(!fs.readFileSync(providerDir+'lsOpenApi.js','utf8').includes('PULSE_DEEP_TARGET_MAX'))});
 await test('KRX quote normalization marks original provider lane',()=>{const q=b._quoteToRow({code:'005930',name:'삼성전자',market:'KOSPI',market_cap_krw:500000000000000},{price:100,prevClose:98,volume:1000,cumulativeAmount:100000,dailyVwap:99,executionStrength:110},'KRX','2026-10-19T00:10:00Z');assert.equal(q.quote_lane,'LS_T8407_KRX_ORIGINAL');assert.equal(q.source,'LS_OPENAPI_1943_ORIGINAL')});
 await test('NXT PRE and KRX regular remain separated',()=>{assert.equal(b.sessionName('NXT',Date.parse('2026-10-19T23:10:00Z')),'PRE');assert.equal(b.sessionName('KRX',Date.parse('2026-10-19T00:10:00Z')),'REGULAR')});
 await test('PULSE deep cap is 30 even though original feed supports 40',async()=>{feed._testReset();const targets=Array.from({length:40},(_,i)=>({code:String(i+1).padStart(6,'0'),name:`T${i+1}`}));const deep=await b.setDeepTargets(targets);assert.equal(deep.count,30);assert.equal(deep.max,30);assert.equal(feed.status().targetCount,30)});
 await test('native fallback subscription budget is bounded by adapter',()=>{const streams=feed._nativeStreamsFor({market:'KOSPI',fullRealtime:true},{phase:'KRX_REGULAR',nxtActive:true});assert.equal(streams.length,6);assert.ok(streams.length*b._deepMax()<=200)});
 await test('bridge has no order route or order TR',()=>{const s=fs.readFileSync('server.js','utf8');for(const x of ["'/order'",'CSPAT00601','CSPAT00801'])assert.equal(s.includes(x),false)});
 await test('provider diagnostics and PULSE endpoints are separate',()=>{const s=fs.readFileSync('server.js','utf8');assert.ok(s.includes("'/provider/quotes'"));assert.ok(s.includes("'/pulse/frame/KRX'"));assert.ok(s.includes("'/pulse/deep-targets'"))});
 console.log(`V12.7.3 separated bridge tests passed: ${passed}`)
})().catch(e=>{console.error(e);process.exit(1)});
