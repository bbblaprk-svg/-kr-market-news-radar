const http=require('http');
const {URL}=require('url');
const ls=require('../ls_provider_original/lib/lsOpenApi');
const feed=require('../ls_provider_original/lib/realtimeFeed');
const bridge=require('./lib/pulseFrameBridge');
const PORT=Number(process.env.PROVIDER_PORT||18080);
const TOKEN=String(process.env.PULSE_BRIDGE_TOKEN||'').trim();
function authorized(req){if(!TOKEN)return process.env.NODE_ENV!=='production';return req.headers['x-pulse-bridge-token']===TOKEN}
function send(res,status,obj){const b=Buffer.from(JSON.stringify(obj));res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','content-length':b.length});res.end(b)}
function body(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>1024*1024)reject(new Error('too large'))});req.on('end',()=>{try{resolve(s?JSON.parse(s):{})}catch(e){reject(e)}})})}
function codesFrom(u){return String(u.searchParams.get('codes')||'005930,000660').split(',').map(x=>x.trim().replace(/^A/,'')).filter(x=>/^\d{6}$/.test(x)).slice(0,50)}
const server=http.createServer(async(req,res)=>{try{
  const u=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  if(u.pathname==='/provider/health'||u.pathname==='/pulse/health'){
    const s=bridge.status();return send(res,200,{ok:true,source:s.source,configured:s.configured,orders_enabled:false,provider_logic:s.provider_logic,decision_logic:s.decision_logic,feed_connected:!!s.feed?.connected,feed_stream_mode:s.feed?.streamMode||null});
  }
  if(!authorized(req))return send(res,401,{error:'bridge authentication required'});
  if(req.method==='GET'&&u.pathname==='/provider/status')return send(res,200,bridge.status());
  if(req.method==='GET'&&u.pathname==='/provider/verify/rest'){
    if(!ls.configured())return send(res,503,{provider:'LS_OPENAPI_1943_ORIGINAL',configured:false,orders_tested:false,status:'BLOCKED',reason:'LS_APP_KEY_OR_SECRET_MISSING'});
    try{await ls.getAccessToken(false);const q=await ls.multiQuotes(['005930','000660']);const rows=Array.isArray(q.rows)?q.rows:[];return send(res,200,{provider:'LS_OPENAPI_1943_ORIGINAL',configured:true,orders_tested:false,token_ready:!!ls.status().tokenReady,quote_ok:rows.length>0,quote_count:rows.length,codes:rows.map(x=>String(x.code||'').replace(/^A/,'')).filter(Boolean),quote_source:[...new Set(rows.map(x=>x.quoteSource).filter(Boolean))],observed_at:new Date().toISOString(),error:q.error||null});}catch(e){return send(res,503,{provider:'LS_OPENAPI_1943_ORIGINAL',configured:true,orders_tested:false,status:'FAIL',reason:(e&&e.name?e.name:'Error')+':'+String(e&&e.message||e).slice(0,180)});}
  }
  // Raw provider diagnostics are read-only and never feed GMIR ranking logic into PULSE.
  if(req.method==='GET'&&u.pathname==='/provider/master/sample'){
    const rows=await ls.loadMaster();const limit=Math.max(1,Math.min(100,Number(u.searchParams.get('limit')||20)));return send(res,200,{provider:'LS_OPENAPI_1943_ORIGINAL',count:rows.length,sample:rows.slice(0,limit),orders_enabled:false});
  }
  if(req.method==='GET'&&u.pathname==='/provider/quotes'){
    const q=await ls.multiQuotes(codesFrom(u));return send(res,200,{provider:'LS_OPENAPI_1943_ORIGINAL',rows:q.rows||[],error:q.error||null,orders_enabled:false});
  }
  if(req.method==='GET'&&u.pathname==='/provider/nxt'){
    const c=String(u.searchParams.get('code')||'005930').replace(/^A/,'');if(!/^\d{6}$/.test(c))return send(res,400,{error:'invalid code'});return send(res,200,{provider:'LS_OPENAPI_1943_ORIGINAL',data:await ls.nxtQuote(c),orders_enabled:false});
  }
  if(req.method==='GET'&&u.pathname==='/provider/feed/status')return send(res,200,{provider:'LS_OPENAPI_1943_ORIGINAL',feed:feed.status(),orders_enabled:false});
  if(req.method==='GET'&&u.pathname==='/pulse/status')return send(res,200,bridge.status());
  if(req.method==='GET'&&u.pathname==='/pulse/verify/rest'){
    req.url='/provider/verify/rest'+u.search; // compatibility path handled inline by second call is not possible; duplicate minimal logic
    if(!ls.configured())return send(res,503,{provider:'LS_OPENAPI_1943_ORIGINAL',configured:false,orders_tested:false,status:'BLOCKED',reason:'LS_APP_KEY_OR_SECRET_MISSING'});
    try{await ls.getAccessToken(false);const q=await ls.multiQuotes(['005930','000660']);const rows=q.rows||[];return send(res,200,{provider:'LS_OPENAPI_1943_ORIGINAL',configured:true,token_ready:!!ls.status().tokenReady,quote_ok:rows.length>0,quote_count:rows.length,codes:rows.map(x=>x.code),observed_at:new Date().toISOString(),error:q.error||null,orders_tested:false});}catch(e){return send(res,503,{status:'FAIL',reason:e.message,orders_tested:false});}
  }
  if(req.method==='GET'&&u.pathname==='/pulse/frame/KRX')return send(res,200,await bridge.buildFrame('KRX'));
  if(req.method==='GET'&&u.pathname==='/pulse/frame/NXT')return send(res,200,await bridge.buildFrame('NXT'));
  if(req.method==='POST'&&u.pathname==='/pulse/deep-targets'){const d=await body(req);return send(res,200,await bridge.setDeepTargets(d.targets||[]))}
  return send(res,404,{error:'Not Found'});
}catch(e){return send(res,500,{error:e.message})}});
server.listen(PORT,'127.0.0.1',async()=>{console.log(JSON.stringify({event:'ls1943_provider_bridge_listening',port:PORT,orders_enabled:false,provider_logic:'ORIGINAL_1943_UNMODIFIED',decision_logic:'PULSE_SEPARATE'}));try{await feed.start()}catch(e){console.error(JSON.stringify({event:'feed_start_failed',error:e.message}))}});
async function stop(){await feed.stop().catch(()=>{});server.close(()=>process.exit(0))}process.on('SIGTERM',stop);process.on('SIGINT',stop);
