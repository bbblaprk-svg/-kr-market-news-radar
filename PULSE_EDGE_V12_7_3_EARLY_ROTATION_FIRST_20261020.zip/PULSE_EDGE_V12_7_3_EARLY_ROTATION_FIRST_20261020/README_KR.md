# PULSE EDGE V12.7.3 — EARLY ROTATION FIRST / LS 데이터·판단 분리

## 목적
LS 1943의 원본 데이터 수집 경로는 그대로 보존하고, PULSE는 **세분 섹터 에너지 이동을 먼저 발견한 뒤 S2/S3 섹터 안에서만 숨은진주를 판단**한다.

이번 V12.7.3의 핵심 변경은 **화면과 섹터 랭킹을 절대 거래대금 순서에서 신규 유입 가속도 우선으로 변경**한 것이다. S2/S3 진입조건과 ENTRY 게이트는 낮추지 않았다.

## 화면 우선순위
1. `EARLY_ROTATION` — 아직 S1이지만 S2 조건에 빠르게 접근 중인 세분 섹터. 관찰 전용, ENTRY 금지.
2. `S2_MONEY_MOVE` — 초기 자금이동 확인. 종목 심층분석 허용, 조건 충족 시 PRE-ENTRY.
3. `S3_CONFIRMED` — 자금이동 확정. 종목 조건 충족 시 ENTRY 가능.
4. `WEAKENING / S5_EXIT` — RS·breadth·점유율이 약해지거나 기존 S2/S3에서 자금이탈 확인.

## EARLY_ROTATION 조건
기존 S2 문턱을 낮추는 것이 아니다. 아래의 **표시 전용 사전징후**를 사용한다.
- 상태 S1
- 데이터/20D baseline/동일 세션 비교가 complete
- S2 게이트 진척률 66.7% 이상
- 점유율 배수 >= 1.05, 점유율 변화 > 0
- Breadth >= 40%
- RS >= 0, RS velocity >= 0

EARLY_ROTATION은 `eligible_for_deep=False`로 유지된다. 종목 스캔은 여전히 S2/S3만 통과한다.

## 섹터 정렬
`leaf_money`는 더 이상 거래대금 절대값만으로 정렬하지 않는다.
`rotation_stage → S2 진척률 → S3 진척률 → 점유율 증가 → 20D 상대거래대금` 순으로 표시한다.

## 데이터/로직 분리
- `ls_provider_original/`: 사용자 제공 GMIR 1943의 LS provider 원본. 수정 금지.
- `pulse_bridge/`: LS 데이터를 KRX/NXT별 정규화 frame으로 변환. GMIR TOP20/BUY 로직 사용 안 함.
- `pulse_core/`: 117개 세분섹터 → S0~S5 → 상방진주만 판단.
- 주문 API 없음.
- KRX/NXT 혼합 금지.

## GitHub에 직접 교체할 파일
- `Dockerfile.pulse-ls`
- `render.yaml`
기존 GMIR용 `Dockerfile`은 그대로 두어도 된다.

## 검증
- PULSE core 테스트: 10개 통과
- LS bridge 테스트: 9개 통과
- EARLY_ROTATION은 표시 전용이며 ENTRY 권한을 얻지 않는 회귀테스트 포함
