import asyncio
import hashlib
import hmac
import json
import logging
import math
import statistics
import os
import re
import time
import uuid
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime
from collections import deque
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional, Tuple

import httpx
import websockets
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, text

KST = timezone(timedelta(hours=9))
log = logging.getLogger("nova")
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)

APP_VERSION = "1.3.9-STABLE-TRACK30"
BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
DATA_DIR = BASE_DIR / "data"

def env_first(*names: str, default: str = "") -> str:
    for name in names:
        v = os.getenv(name, "").strip()
        if v:
            return v
    return default

LS_REST_BASE = env_first("LS_REST_BASE", default="https://openapi.ls-sec.co.kr:8080").rstrip("/")
LS_WS_URL = env_first("LS_WS_URL", default="wss://openapi.ls-sec.co.kr:9443/websocket")
LS_APP_KEY = env_first("LS_APP_KEY", "LS_APPKEY", "LS_CLIENT_ID")
LS_APP_SECRET = env_first("LS_APP_SECRET", "LS_APPSECRET", "LS_CLIENT_SECRET")
APP_ACCESS_TOKEN = env_first("APP_ACCESS_TOKEN")
APP_SESSION_SECRET = env_first("APP_SESSION_SECRET", default=APP_ACCESS_TOKEN or "nova-local-session")
LS_OPENAPI_ENABLED = env_first("LS_OPENAPI_ENABLED", default="true").lower() not in {"0","false","no","off"}

POLL_SECONDS = max(10, int(env_first("POLL_SECONDS", default="20")))
CLOSED_POLL_SECONDS = max(120, int(env_first("CLOSED_POLL_SECONDS", default="300")))
NEWS_REFRESH_SECONDS = max(60, int(env_first("NEWS_REFRESH_SECONDS", default="300")))
DISCOVERY_REFRESH_SECONDS = max(60, int(env_first("DISCOVERY_REFRESH_SECONDS", default="180")))
CONDITION_LIST_REFRESH_SECONDS = max(300, int(env_first("CONDITION_LIST_REFRESH_SECONDS", default="900")))
MAX_PRECISION = max(20, min(35, int(env_first("MAX_PRECISION", default="30"))))
MASTER_READY_MIN = max(300, int(env_first("MASTER_READY_MIN", default="1000")))
MASTER_REFRESH_SECONDS = max(1800, int(env_first("MASTER_REFRESH_SECONDS", default="21600")))
ACTIVE_UNIVERSE_MAX = 1000
DELTA_LOOKBACK_SECONDS = 300
BACKGROUND_PROMOTE_HINT = 26.0
BACKGROUND_BATCH_PER_PASS = 60
TRACKING_MIN_HOLD_SECONDS = 600
TRACKING_REPLACE_MARGIN = 3.0
TRACKING_DISCOVERY_BUDGET = 12
TRACKING_READY_SECONDS = 300
MAX_CANDIDATES = max(60, min(150, int(env_first("MAX_CANDIDATES", default="120"))))
MAX_CONDITIONS = max(1, min(8, int(env_first("MAX_CONDITIONS", default="6"))))
PREBUY_THRESHOLD = float(env_first("PREBUY_THRESHOLD", default="78"))
BUILDING_THRESHOLD = float(env_first("BUILDING_THRESHOLD", default="65"))
WATCH_THRESHOLD = float(env_first("WATCH_THRESHOLD", default="55"))

# Weak-market relative-leader path. This does NOT lower the normal BUILDING=65 gate.
REL_BUILDING_MIN_SCORE = float(env_first("REL_BUILDING_MIN_SCORE", default="58"))
REL_BUILDING_REL_MIN = float(env_first("REL_BUILDING_REL_MIN", default="5"))
REL_BUILDING_FLOW_MIN = float(env_first("REL_BUILDING_FLOW_MIN", default="7"))
REL_BUILDING_SQUEEZE_MIN = float(env_first("REL_BUILDING_SQUEEZE_MIN", default="5"))
REL_BUILDING_EDGE_MIN = float(env_first("REL_BUILDING_EDGE_MIN", default="0.7"))
REL_BUILDING_MIN_MINUTES = float(env_first("REL_BUILDING_MIN_MINUTES", default="5"))
IGNITING_DELTA_MIN = float(env_first("IGNITING_DELTA_MIN", default="6"))
EARLY_IGNITING_MINUTES = float(env_first("EARLY_IGNITING_MINUTES", default="5"))
EARLY_IGNITING_PRE_MIN = float(env_first("EARLY_IGNITING_PRE_MIN", default="60"))
EARLY_IGNITING_DELTA_MIN = float(env_first("EARLY_IGNITING_DELTA_MIN", default="7"))
CONFIRMED_IGNITING_MINUTES = float(env_first("CONFIRMED_IGNITING_MINUTES", default="10"))
CONFIRMED_IGNITING_PRE_MIN = float(env_first("CONFIRMED_IGNITING_PRE_MIN", default="55"))
CONFIRMED_IGNITING_DELTA_MIN = float(env_first("CONFIRMED_IGNITING_DELTA_MIN", default="6"))
OVERHEAT_DAILY_PCT = float(env_first("OVERHEAT_DAILY_PCT", default="8.0"))
# Section ① PRE-BUY reliability gate stays unchanged.
MIN_READY_MINUTES = 5.0
WARMUP_START_HM = int(env_first("WARMUP_START_HM", default="750"))
WARMUP_MARKET_HM = int(env_first("WARMUP_MARKET_HM", default="800"))
WARMUP_END_HM = int(env_first("WARMUP_END_HM", default="810"))
WARMUP_RETRY_SECONDS = max(30, int(env_first("WARMUP_RETRY_SECONDS", default="60")))
SIGNAL_RETAIN_MIN_SCORE = float(env_first("SIGNAL_RETAIN_MIN_SCORE", default="52"))
SIGNAL_GRACE_MIN_SCORE = float(env_first("SIGNAL_GRACE_MIN_SCORE", default="47"))
SIGNAL_GRACE_SECONDS = max(600, int(env_first("SIGNAL_GRACE_SECONDS", default="1800")))
SIGNAL_MEMORY_MAX_AGE_HOURS = 24.0
SIGNAL_MEMORY_MAX = max(5, min(10, int(env_first("SIGNAL_MEMORY_MAX", default="10"))))
SCOUT_ENABLED = env_first("SCOUT_ENABLED", default="true").lower() not in {"0","false","no","off"}
SCOUT_BATCH = max(6, min(16, int(env_first("SCOUT_BATCH", default="12"))))
SCOUT_INTERVAL_SECONDS = max(15, int(env_first("SCOUT_INTERVAL_SECONDS", default="20")))
SCOUT_FRESH_SLOTS = max(3, min(8, int(env_first("SCOUT_FRESH_SLOTS", default="6"))))
SCOUT_MIN_PRICE = max(500.0, float(env_first("SCOUT_MIN_PRICE", default="1000")))
# Whole-market high-speed discovery. Ranking TRs are primary; t1101 rotation is fallback only.
RANK_SCOUT_ENABLED = env_first("RANK_SCOUT_ENABLED", default="true").lower() not in {"0","false","no","off"}
RANK_REFRESH_SECONDS = max(45, int(env_first("RANK_REFRESH_SECONDS", default="60")))
RANK_STALE_SECONDS = max(120, int(env_first("RANK_STALE_SECONDS", default="180")))
RANK_CANDIDATE_TTL_SECONDS = max(600, int(env_first("RANK_CANDIDATE_TTL_SECONDS", default="900")))
RANK_TRS = ("t1466","t1463","t1452","t1441")

# NXT truth guard
NXT_VERIFY_ENABLED = env_first("NXT_VERIFY_ENABLED", default="true").lower() not in {"0","false","no","off"}
NXT_VERIFY_MIN_CODES = max(1, min(5, int(env_first("NXT_VERIFY_MIN_CODES", default="2"))))
NXT_VERIFY_TIMEOUT_SECONDS = max(60, int(env_first("NXT_VERIFY_TIMEOUT_SECONDS", default="120")))
NXT_VERIFY_EVIDENCE_SECONDS = max(90, int(env_first("NXT_VERIFY_EVIDENCE_SECONDS", default="240")))
NXT_VERIFY_STALE_SECONDS = max(300, int(env_first("NXT_VERIFY_STALE_SECONDS", default="600")))
NXT_CONDITION_REFRESH_SECONDS = max(30, int(env_first("NXT_CONDITION_REFRESH_SECONDS", default="45")))
NXT_CONDITION_FRESH_SECONDS = max(60, int(env_first("NXT_CONDITION_FRESH_SECONDS", default="120")))
NXT_FALLBACK_PRECISION = max(10, min(MAX_PRECISION, int(env_first("NXT_FALLBACK_PRECISION", default="24"))))

DEMO_MODE = env_first("DEMO_MODE", default="false").lower() in {"1","true","yes","on"}
if not LS_OPENAPI_ENABLED or not LS_APP_KEY or not LS_APP_SECRET:
    DEMO_MODE = True

CONDITION_INDEX_ENV = env_first("LS_CONDITION_INDEXES", "LS_CONDITION_INDEX")
CONDITION_INDEXES = [x.strip() for x in re.split(r"[,; ]+", CONDITION_INDEX_ENV) if x.strip()]

DEFAULT_NEWS_FEEDS = [
    "https://news.google.com/rss/search?q=(NVIDIA+OR+TSMC+OR+ASML+OR+Micron)+AI+server+capex+order+guidance+when:1d&hl=en-US&gl=US&ceid=US:en",
    "https://news.google.com/rss/search?q=(HBM+OR+advanced+packaging+OR+AI+PCB)+order+capacity+Korea+when:1d&hl=en-US&gl=US&ceid=US:en",
    "https://news.google.com/rss/search?q=(power+grid+OR+transformer+OR+HVDC)+order+investment+shortage+demand+when:1d&hl=en-US&gl=US&ceid=US:en",
    "https://news.google.com/rss/search?q=(data+center+OR+AI+power)+electricity+transformer+order+Korea+when:1d&hl=en-US&gl=US&ceid=US:en",
    "https://news.google.com/rss/search?q=(robotics+OR+humanoid)+factory+order+investment+partnership+when:1d&hl=en-US&gl=US&ceid=US:en",
    "https://news.google.com/rss/search?q=(NVIDIA+robotics+OR+physical+AI)+Korea+partnership+factory+when:1d&hl=en-US&gl=US&ceid=US:en",
    "https://news.google.com/rss/search?q=(battery+OR+ESS)+order+tariff+subsidy+capacity+Korea+when:1d&hl=en-US&gl=US&ceid=US:en",
    "https://news.google.com/rss/search?q=(defense+OR+aerospace)+Korea+export+order+contract+when:1d&hl=en-US&gl=US&ceid=US:en",
    "https://news.google.com/rss/search?q=(Korea+OR+South+Korea)+export+tariff+semiconductor+battery+shipbuilding+defense+when:1d&hl=en-US&gl=US&ceid=US:en",
    "https://news.google.com/rss/search?q=한국+반도체+전력기기+로봇+방산+수출+수주+증설+정책+when:1d&hl=ko&gl=KR&ceid=KR:ko",
    "https://news.google.com/rss/search?q=삼성전자+SK하이닉스+삼성전기+LG에너지솔루션+현대차+수주+투자+증설+when:1d&hl=ko&gl=KR&ceid=KR:ko",
    "https://news.google.com/rss/search?q=한화에어로스페이스+LS+ELECTRIC+HD현대일렉트릭+두산로보틱스+수주+계약+when:1d&hl=ko&gl=KR&ceid=KR:ko",
]
# Deliberately use a new variable name so a legacy NEWS_FEEDS value from the old Radar
# cannot silently restore the old broad queries.
NEWS_FEEDS = [x.strip() for x in env_first("NOVA_NEWS_FEEDS", default=",".join(DEFAULT_NEWS_FEEDS)).split(",") if x.strip()]

DATABASE_URL = env_first("DATABASE_URL")
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = "postgresql+psycopg://" + DATABASE_URL[len("postgres://"):]
elif DATABASE_URL.startswith("postgresql://") and not DATABASE_URL.startswith("postgresql+psycopg://"):
    DATABASE_URL = "postgresql+psycopg://" + DATABASE_URL[len("postgresql://"):]
if not DATABASE_URL:
    DATABASE_URL = f"sqlite:///{env_first('DB_PATH', default='/tmp/nova_preignition.db')}"

SECTOR_KEYWORDS = {
    "AI반도체": ["ai", "semiconductor", "chip", "gpu", "hbm", "server", "nvidia", "memory"],
    "PCB/MLCC": ["pcb", "substrate", "mlcc", "capacitor", "package", "packaging"],
    "전력기기": ["grid", "transformer", "power equipment", "electricity", "substation", "hvdc"],
    "로봇": ["robot", "robotics", "humanoid", "automation"],
    "2차전지": ["battery", "ev", "energy storage", "ess", "cathode", "anode"],
    "자동차": ["auto", "automotive", "vehicle", "mobility", "adas"],
    "방산": ["defense", "missile", "aerospace", "weapon"],
}

EXCLUDE_NAME_PARTS = ("ETF", "ETN", "스팩", "SPAC", "리츠", "REIT")

@dataclass
class StockMeta:
    code: str
    name: str
    sector: str = "기타"

@dataclass
class Quote:
    ts: float
    price: float
    diff_pct: float
    volume: float
    bid: float = 0.0
    offer: float = 0.0
    bid_qty: float = 0.0
    offer_qty: float = 0.0
    high: float = 0.0
    low: float = 0.0
    market_time: str = ""
    verified_source: str = ""

@dataclass
class CandidateHint:
    meta: StockMeta
    price: float = 0.0
    diff_pct: float = 0.0
    volume: float = 0.0
    hint_score: float = 0.0
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    source: str = "LS_CONDITION"

@dataclass
class StockState:
    meta: StockMeta
    history: Deque[Quote] = field(default_factory=lambda: deque(maxlen=180))
    score_history: Deque[Tuple[float, float]] = field(default_factory=lambda: deque(maxlen=180))
    money: float = 0.0
    acceleration: float = 0.0
    catalyst: float = 0.0
    position: float = 0.0
    squeeze_release: float = 0.0
    flow_persistence: float = 0.0
    relative_acceleration: float = 0.0
    relative_edge_pct: float = 0.0
    pre_score: float = 0.0
    delta_score: float = 0.0
    ready_minutes: float = 0.0
    status: str = "EARLY"
    why: List[str] = field(default_factory=list)
    last_update: float = 0.0
    source: str = "BASE"

class HoldingIn(BaseModel):
    code: str = Field(min_length=6, max_length=12)
    name: str = Field(min_length=1, max_length=60)
    buy_price: float = Field(gt=0)
    qty: float = Field(gt=0)

class DecisionNameIn(BaseModel):
    name: str = Field(min_length=1, max_length=60)

class LoginIn(BaseModel):
    token: str = Field(min_length=1, max_length=500)

def session_value() -> str:
    return hmac.new(APP_SESSION_SECRET.encode(), APP_ACCESS_TOKEN.encode(), hashlib.sha256).hexdigest()

def is_authorized(request: Request) -> bool:
    if not APP_ACCESS_TOKEN:
        return True
    c = request.cookies.get("nova_session", "")
    return bool(c) and hmac.compare_digest(c, session_value())

def require_auth(request: Request):
    if not is_authorized(request):
        raise HTTPException(status_code=401, detail="login required")

def now_kst() -> datetime:
    return datetime.now(KST)

def hhmm_value(dt: Optional[datetime] = None) -> int:
    dt = dt or now_kst()
    return dt.hour * 100 + dt.minute

def in_warmup_window(dt: Optional[datetime] = None) -> bool:
    dt = dt or now_kst()
    return dt.weekday() < 5 and WARMUP_START_HM <= hhmm_value(dt) < WARMUP_MARKET_HM

def market_phase(dt: Optional[datetime] = None) -> Dict[str, Any]:
    dt = dt or now_kst()
    hm = dt.hour * 60 + dt.minute
    weekday = dt.weekday() < 5
    if not weekday:
        return {"code":"CLOSED","label":"MARKET CLOSED","active":False,"intraday":False,"nxt":False,"nxt_verify":False}
    if in_warmup_window(dt):
        return {"code":"WARMUP","label":"WARM-UP","active":False,"intraday":False,"nxt":False,"nxt_verify":False}
    if 8*60 <= hm < 8*60+50:
        return {"code":"PRE","label":"NXT / PRE","active":True,"intraday":True,"nxt":True,"nxt_verify":True}
    if 8*60+50 <= hm < 9*60:
        return {"code":"NXT_PAUSE","label":"NXT PAUSE","active":False,"intraday":False,"nxt":True,"nxt_verify":False}
    if 9*60 <= hm <= 15*60+30:
        return {"code":"REGULAR","label":"KRX REGULAR","active":True,"intraday":True,"nxt":False,"nxt_verify":False}
    if 15*60+30 < hm < 15*60+40:
        return {"code":"AFTER_AUCTION","label":"NXT / AFTER AUCTION","active":True,"intraday":True,"nxt":True,"nxt_verify":False}
    if 15*60+40 <= hm < 20*60:
        return {"code":"AFTER","label":"NXT / AFTER","active":True,"intraday":True,"nxt":True,"nxt_verify":True}
    return {"code":"CLOSED","label":"MARKET CLOSED","active":False,"intraday":False,"nxt":False,"nxt_verify":False}

def parse_ls_hotime(v: Any) -> Optional[int]:
    digits=re.sub(r"\D","",str(v or ""))
    if len(digits)<6:
        return None
    try:
        hh=int(digits[:2]); mm=int(digits[2:4]); ss=int(digits[4:6])
        if 0<=hh<=23 and 0<=mm<=59 and 0<=ss<=59:
            return hh*10000+mm*100+ss
    except Exception:
        pass
    return None

def hotime_in_nxt_session(hotime: Any, phase_code: str) -> bool:
    t=parse_ls_hotime(hotime)
    if t is None:
        return False
    if phase_code=="PRE":
        return 80000 <= t < 85000
    if phase_code=="AFTER":
        return 154000 <= t < 200000
    return False

def clean_code(v: Any) -> str:
    s = re.sub(r"\D", "", str(v or ""))
    return s[-6:] if len(s) >= 6 else s

def fnum(v: Any, default: float = 0.0) -> float:
    try:
        return float(str(v).replace(",","").strip() or default)
    except Exception:
        return default

def valid_equity_name(name: str) -> bool:
    up = (name or "").upper()
    if not name:
        return True
    if any(x.upper() in up for x in EXCLUDE_NAME_PARTS):
        return False
    # Common Korean preferred-share endings. Do not over-filter ordinary names containing "우".
    if re.search(r"(우|우B|우C)$", name):
        return False
    return True

class Store:
    def __init__(self, url: str):
        kwargs = {"pool_pre_ping": True}
        if url.startswith("sqlite"):
            kwargs["connect_args"] = {"check_same_thread": False}
        self.engine = create_engine(url, future=True, **kwargs)
        self.init_schema()

    def init_schema(self):
        ddl = [
            """CREATE TABLE IF NOT EXISTS signals(
                id TEXT PRIMARY KEY, code TEXT NOT NULL, name TEXT NOT NULL,
                signal_ts DOUBLE PRECISION NOT NULL, signal_price DOUBLE PRECISION NOT NULL,
                pre_score DOUBLE PRECISION NOT NULL, status TEXT NOT NULL, reason TEXT NOT NULL
            )""",
            """CREATE TABLE IF NOT EXISTS outcomes(
                signal_id TEXT NOT NULL, label TEXT NOT NULL, eval_ts DOUBLE PRECISION NOT NULL,
                eval_price DOUBLE PRECISION NOT NULL, return_pct DOUBLE PRECISION NOT NULL,
                PRIMARY KEY(signal_id,label)
            )""",
            """CREATE TABLE IF NOT EXISTS holdings(
                code TEXT PRIMARY KEY, name TEXT NOT NULL, buy_price DOUBLE PRECISION NOT NULL,
                qty DOUBLE PRECISION NOT NULL, peak_price DOUBLE PRECISION NOT NULL,
                updated_ts DOUBLE PRECISION NOT NULL
            )""",
            """CREATE TABLE IF NOT EXISTS rank_snapshots(
                trading_day TEXT NOT NULL, lane TEXT NOT NULL, captured_ts DOUBLE PRECISION NOT NULL,
                payload_json TEXT NOT NULL, PRIMARY KEY(trading_day,lane)
            )""",
            """CREATE TABLE IF NOT EXISTS manual_watch(
                code TEXT PRIMARY KEY, name TEXT NOT NULL, added_ts DOUBLE PRECISION NOT NULL
            )""",
            """CREATE TABLE IF NOT EXISTS occurrence_log(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                day TEXT NOT NULL, ts DOUBLE PRECISION NOT NULL, market TEXT NOT NULL,
                code TEXT NOT NULL, name TEXT NOT NULL, kind TEXT NOT NULL,
                price DOUBLE PRECISION, pre_score DOUBLE PRECISION, delta_score DOUBLE PRECISION, reason TEXT
            )""",
            """CREATE INDEX IF NOT EXISTS idx_occurrence_day_ts ON occurrence_log(day,ts DESC)""",
            """CREATE TABLE IF NOT EXISTS signal_memory(
                code TEXT PRIMARY KEY, name TEXT NOT NULL, signal_day TEXT NOT NULL,
                signal_ts DOUBLE PRECISION NOT NULL, signal_price DOUBLE PRECISION NOT NULL,
                signal_score DOUBLE PRECISION NOT NULL, max_score DOUBLE PRECISION NOT NULL,
                last_valid_ts DOUBLE PRECISION NOT NULL, updated_ts DOUBLE PRECISION NOT NULL,
                last_price DOUBLE PRECISION NOT NULL, last_diff DOUBLE PRECISION NOT NULL,
                last_score DOUBLE PRECISION NOT NULL, display_status TEXT NOT NULL,
                reason_json TEXT NOT NULL
            )"""
        ]
        with self.engine.begin() as c:
            for x in ddl:
                c.execute(text(x))

    def add_signal(self, code, name, price, score, status, reason):
        sid = uuid.uuid4().hex
        with self.engine.begin() as c:
            c.execute(text("""INSERT INTO signals
                (id,code,name,signal_ts,signal_price,pre_score,status,reason)
                VALUES(:id,:code,:name,:ts,:p,:s,:st,:r)"""),
                {"id":sid,"code":code,"name":name,"ts":time.time(),"p":price,"s":score,"st":status,"r":reason})
        return sid

    def recent_signals(self, limit=100):
        with self.engine.begin() as c:
            rows = c.execute(text("""SELECT id,code,name,signal_ts,signal_price,pre_score,status,reason
                FROM signals ORDER BY signal_ts DESC LIMIT :n"""), {"n":limit}).mappings().all()
        return [dict(r) for r in rows]

    def has_outcome(self, sid, label):
        with self.engine.begin() as c:
            return c.execute(text("SELECT 1 FROM outcomes WHERE signal_id=:s AND label=:l"),
                             {"s":sid,"l":label}).first() is not None

    def add_outcome(self, sid, label, price, ret):
        with self.engine.begin() as c:
            c.execute(text("""INSERT INTO outcomes(signal_id,label,eval_ts,eval_price,return_pct)
                VALUES(:s,:l,:ts,:p,:r) ON CONFLICT(signal_id,label) DO NOTHING"""),
                {"s":sid,"l":label,"ts":time.time(),"p":price,"r":ret})

    def performance(self):
        with self.engine.begin() as c:
            rows = c.execute(text("""SELECT label,COUNT(*) n,
                AVG(CASE WHEN return_pct>0 THEN 1.0 ELSE 0.0 END) win_rate,
                AVG(return_pct) avg_return FROM outcomes GROUP BY label""")).mappings().all()
            total = c.execute(text("SELECT COUNT(*) FROM signals")).scalar_one()
        return {"signals":int(total),"by_label":{
            r["label"]:{"n":int(r["n"]),"win_rate":round(float(r["win_rate"] or 0)*100,1),
                        "avg_return":round(float(r["avg_return"] or 0),2)} for r in rows
        }}

    def upsert_holding(self, h: HoldingIn):
        with self.engine.begin() as c:
            old = c.execute(text("SELECT peak_price FROM holdings WHERE code=:c"),{"c":h.code}).first()
            peak = max(float(old[0]),h.buy_price) if old else h.buy_price
            c.execute(text("""INSERT INTO holdings(code,name,buy_price,qty,peak_price,updated_ts)
                VALUES(:c,:n,:b,:q,:p,:ts)
                ON CONFLICT(code) DO UPDATE SET name=excluded.name,buy_price=excluded.buy_price,
                qty=excluded.qty,updated_ts=excluded.updated_ts"""),
                {"c":h.code,"n":h.name,"b":h.buy_price,"q":h.qty,"p":peak,"ts":time.time()})

    def holdings(self):
        with self.engine.begin() as c:
            return [dict(r) for r in c.execute(text(
                "SELECT code,name,buy_price,qty,peak_price,updated_ts FROM holdings ORDER BY name"
            )).mappings().all()]

    def delete_holding(self, code):
        with self.engine.begin() as c:
            c.execute(text("DELETE FROM holdings WHERE code=:c"),{"c":code})

    def update_peak(self, code, price):
        with self.engine.begin() as c:
            c.execute(text("""UPDATE holdings SET peak_price=CASE WHEN peak_price<:p THEN :p ELSE peak_price END,
                updated_ts=:ts WHERE code=:c"""),{"p":price,"ts":time.time(),"c":code})

    def upsert_manual_watch(self, code: str, name: str):
        with self.engine.begin() as c:
            c.execute(text("""INSERT INTO manual_watch(code,name,added_ts)
                VALUES(:c,:n,:ts)
                ON CONFLICT(code) DO UPDATE SET name=excluded.name,added_ts=excluded.added_ts"""),
                {"c":code,"n":name,"ts":time.time()})

    def manual_watch(self):
        with self.engine.begin() as c:
            return [dict(r) for r in c.execute(text(
                "SELECT code,name,added_ts FROM manual_watch ORDER BY added_ts DESC"
            )).mappings().all()]

    def delete_manual_watch(self, code: str):
        with self.engine.begin() as c:
            c.execute(text("DELETE FROM manual_watch WHERE code=:c"),{"c":code})

    def add_occurrence(self,row:Dict[str,Any]):
        with self.engine.begin() as c:
            c.execute(text("""INSERT INTO occurrence_log(day,ts,market,code,name,kind,price,pre_score,delta_score,reason)
                              VALUES(:day,:ts,:market,:code,:name,:kind,:price,:pre_score,:delta_score,:reason)"""),row)

    def occurrence_recent(self,limit:int=100):
        with self.engine.begin() as c:
            rows=c.execute(text("""SELECT day,ts,market,code,name,kind,price,pre_score,delta_score,reason
                                   FROM occurrence_log ORDER BY ts DESC LIMIT :n"""),{"n":limit}).mappings().all()
        return [dict(x) for x in rows]
    def occurrence_market(self,market:str,limit:int=50,day:str=""):
        day=day or now_kst().date().isoformat()
        with self.engine.begin() as c:
            rows=c.execute(text("""SELECT day,ts,market,code,name,kind,price,pre_score,delta_score,reason
                                   FROM occurrence_log
                                   WHERE day=:d AND market=:m
                                   ORDER BY ts DESC,id DESC LIMIT :n"""),
                           {"d":day,"m":market,"n":limit}).mappings().all()
        return [dict(x) for x in rows]

    def upsert_signal_memory(self, row: Dict[str,Any]):
        with self.engine.begin() as c:
            c.execute(text("""INSERT INTO signal_memory(
                code,name,signal_day,signal_ts,signal_price,signal_score,max_score,
                last_valid_ts,updated_ts,last_price,last_diff,last_score,display_status,reason_json
            ) VALUES(
                :code,:name,:signal_day,:signal_ts,:signal_price,:signal_score,:max_score,
                :last_valid_ts,:updated_ts,:last_price,:last_diff,:last_score,:display_status,:reason_json
            )
            ON CONFLICT(code) DO UPDATE SET
                name=excluded.name,signal_day=excluded.signal_day,
                max_score=excluded.max_score,last_valid_ts=excluded.last_valid_ts,
                updated_ts=excluded.updated_ts,last_price=excluded.last_price,
                last_diff=excluded.last_diff,last_score=excluded.last_score,
                display_status=excluded.display_status,reason_json=excluded.reason_json
            """), row)

    def signal_memory(self):
        with self.engine.begin() as c:
            rows=c.execute(text("""SELECT code,name,signal_day,signal_ts,signal_price,signal_score,max_score,
                last_valid_ts,updated_ts,last_price,last_diff,last_score,display_status,reason_json
                FROM signal_memory ORDER BY max_score DESC,last_valid_ts DESC""")).mappings().all()
        out=[]
        for r in rows:
            x=dict(r)
            try:
                x["why"]=json.loads(x.pop("reason_json"))
            except Exception:
                x["why"]=[]
                x.pop("reason_json",None)
            out.append(x)
        return out

    def delete_signal_memory(self, code: str):
        with self.engine.begin() as c:
            c.execute(text("DELETE FROM signal_memory WHERE code=:c"),{"c":code})

    def save_rank(self, day: str, lane: str, payload: List[Dict[str,Any]]):
        with self.engine.begin() as c:
            c.execute(text("""INSERT INTO rank_snapshots(trading_day,lane,captured_ts,payload_json)
                VALUES(:d,:l,:ts,:p)
                ON CONFLICT(trading_day,lane) DO UPDATE SET captured_ts=excluded.captured_ts,payload_json=excluded.payload_json"""),
                {"d":day,"l":lane,"ts":time.time(),"p":json.dumps(payload,ensure_ascii=False)})

    def latest_rank(self, lane: str) -> Dict[str,Any]:
        with self.engine.begin() as c:
            r = c.execute(text("""SELECT trading_day,captured_ts,payload_json FROM rank_snapshots
                WHERE lane=:l ORDER BY trading_day DESC,captured_ts DESC LIMIT 1"""),{"l":lane}).mappings().first()
        if not r:
            return {"day":None,"captured_ts":None,"items":[]}
        try:
            items = json.loads(r["payload_json"])
        except Exception:
            items = []
        return {"day":r["trading_day"],"captured_ts":r["captured_ts"],"items":items}

class TokenManager:
    def __init__(self):
        self.token = None
        self.expires_at = 0.0
        self.last_error = ""
        self.lock = asyncio.Lock()

    async def get(self, force=False):
        if DEMO_MODE:
            return "DEMO"
        if self.token and time.time() < self.expires_at-300 and not force:
            return self.token
        async with self.lock:
            if self.token and time.time() < self.expires_at-300 and not force:
                return self.token
            try:
                async with httpx.AsyncClient(timeout=15) as cl:
                    r = await cl.post(
                        f"{LS_REST_BASE}/oauth2/token",
                        headers={"content-type":"application/x-www-form-urlencoded"},
                        params={"grant_type":"client_credentials","appkey":LS_APP_KEY,
                                "appsecretkey":LS_APP_SECRET,"scope":"oob"}
                    )
                r.raise_for_status()
                d=r.json()
                self.token=d.get("access_token")
                self.expires_at=time.time()+max(600,int(d.get("expires_in",21600)))
                self.last_error=""
            except Exception as e:
                self.token=None
                self.last_error=f"{type(e).__name__}: {e}"
                raise
        return self.token

class LSRest:
    def __init__(self, tm: TokenManager):
        self.tm=tm
        self.last_ok=0.0
        self.last_error=""
        self.fast_lock=asyncio.Lock()
        self.slow_lock=asyncio.Lock()
        self.integrated_volume_state:Dict[str,Tuple[str,float]]={}
        self.integrated_volume_field_counts:Dict[str,int]={}
        self.integrated_volume_changes=0
        self.integrated_price_ok=0
        self.integrated_volume_ok=0
        self.integrated_last_sample:Dict[str,Any]={}
        self.master_raw_rows=0
        self.master_valid_rows=0
        self.master_attempts=[]
        self.master_last_error=""
        self.master_last_ok=0.0

    async def post_tr(self,tr_cd,path,body,slow=False):
        if DEMO_MODE:
            raise RuntimeError("DEMO")
        lock=self.slow_lock if slow else self.fast_lock
        async with lock:
            token=await self.tm.get()
            headers={"content-type":"application/json; charset=utf-8","authorization":f"Bearer {token}",
                     "tr_cd":tr_cd,"tr_cont":"N","tr_cont_key":""}
            try:
                async with httpx.AsyncClient(timeout=15) as cl:
                    r=await cl.post(f"{LS_REST_BASE}{path}",headers=headers,json=body)
                if r.status_code==401:
                    token=await self.tm.get(force=True)
                    headers["authorization"]=f"Bearer {token}"
                    async with httpx.AsyncClient(timeout=15) as cl:
                        r=await cl.post(f"{LS_REST_BASE}{path}",headers=headers,json=body)
                r.raise_for_status()
                d=r.json()
                # LS can return HTTP 200 with rsp_cd/rsp_msg for TR errors.
                rsp=str(d.get("rsp_cd",""))
                if rsp and rsp not in {"00000","0000","0"}:
                    raise RuntimeError(f"{rsp} {d.get('rsp_msg','')}".strip())
                self.last_ok=time.time()
                self.last_error=""
                return d
            except Exception as e:
                self.last_error=f"{type(e).__name__}: {e}"
                raise
            finally:
                await asyncio.sleep(1.05 if slow else 0.12)

    async def quote(self,code):
        d=await self.post_tr("t1101","/stock/market-data",{"t1101InBlock":{"shcode":code}})
        return d.get("t1101OutBlock") or {}

    def _integrated_leafs(self,obj,path=""):
        rows=[]
        if isinstance(obj,dict):
            for k,v in obj.items():
                p=f"{path}.{k}" if path else str(k)
                if isinstance(v,(dict,list)):
                    rows.extend(self._integrated_leafs(v,p))
                else:
                    rows.append((p,str(k),v))
        elif isinstance(obj,list):
            for i,v in enumerate(obj):
                rows.extend(self._integrated_leafs(v,f"{path}[{i}]"))
        return rows

    def _integrated_num(self,v):
        try:
            return fnum(v)
        except Exception:
            return 0.0

    def _integrated_pick(self,leafs,aliases):
        amap={str(a).lower().replace("_",""):i for i,a in enumerate(aliases)}
        best=None
        for path,key,val in leafs:
            nk=str(key).lower().replace("_","")
            if nk in amap:
                score=100-amap[nk]
                num=self._integrated_num(val)
                if best is None or score>best[0]:
                    best=(score,num,path,key)
        return best

    def _integrated_volume_candidates(self,leafs):
        """Return plausible cumulative-volume fields.
        Explicit cumulative aliases get priority. Generic *vol* fields are accepted
        only after excluding rates, ratios, quote remainders and monetary amounts.
        """
        priority=[
            "volume","totalvolume","totvolume","cumvolume","accvolume",
            "accvol","tvolume","totalvol","cumvol"
        ]
        pmap={x:i for i,x in enumerate(priority)}
        rows=[]
        exclude=("rate","ratio","diff","rem","bid","offer","ask","value","amount",
                 "turnover","power","unit","avg","price","time")
        for path,key,val in leafs:
            nk=str(key).lower().replace("_","")
            if not ("vol" in nk or "volume" in nk):
                continue
            if any(x in nk for x in exclude):
                continue
            num=self._integrated_num(val)
            if num<=0:
                continue
            if nk in pmap:
                pri=100-pmap[nk]
            elif nk in {"cvolume","jvolume","chevolume","execvolume"}:
                # Possible execution volume rather than cumulative; use only as fallback.
                pri=35
            else:
                pri=50
            rows.append((pri,float(num),path,key))
        rows.sort(key=lambda x:(x[0],x[1]),reverse=True)
        return rows

    def _canonical_integrated(self,code,d):
        leafs=self._integrated_leafs(d)
        price_hit=self._integrated_pick(
            leafs,["price","nowprice","close","curpr","current_price","currentprice"]
        )
        diff_hit=self._integrated_pick(
            leafs,["diff","diff_pct","change_rate","changerate","rate","chg_rate","chgrate"]
        )
        bid_hit=self._integrated_pick(leafs,["bidho1","bid1","bid","bid_price1","bidprice1"])
        offer_hit=self._integrated_pick(leafs,["offerho1","offer1","offer","ask1","ask_price1","askprice1"])
        bidrem_hit=self._integrated_pick(leafs,["bidrem1","bidrem","bid_qty","bidqty1","bid_volume1"])
        offerrem_hit=self._integrated_pick(leafs,["offerrem1","offerrem","offer_qty","offerqty1","ask_volume1"])
        high_hit=self._integrated_pick(leafs,["high","highprc","high_price","highprice"])
        low_hit=self._integrated_pick(leafs,["low","lowprc","low_price","lowprice"])
        time_hit=self._integrated_pick(leafs,["hotime","chetime","time","trade_time","tradetime"])

        vol_candidates=self._integrated_volume_candidates(leafs)
        last=self.integrated_volume_state.get(code)
        chosen=None

        # Prefer same field if it remains non-decreasing.
        if last:
            last_field,last_val=last
            for row in vol_candidates:
                _,val,path,key=row
                if str(key)==last_field and val>=last_val:
                    chosen=row
                    break

        # Otherwise choose the highest-priority candidate. Prefer one not below
        # previous cumulative volume if a previous sample exists.
        if chosen is None and last:
            viable=[r for r in vol_candidates if r[1]>=last[1]]
            if viable:
                chosen=viable[0]
        if chosen is None and vol_candidates:
            chosen=vol_candidates[0]

        volume=0.0; volume_field=""
        if chosen:
            _,volume,_,volume_field=chosen
            prev=self.integrated_volume_state.get(code)
            if prev and str(prev[0])==str(volume_field) and volume>prev[1]:
                self.integrated_volume_changes+=1
            self.integrated_volume_state[code]=(str(volume_field),float(volume))
            self.integrated_volume_field_counts[str(volume_field)]=self.integrated_volume_field_counts.get(str(volume_field),0)+1
            self.integrated_volume_ok+=1

        price=abs(price_hit[1]) if price_hit else 0.0
        if price>0:
            self.integrated_price_ok+=1

        def n(hit,absolute=False):
            v=(hit[1] if hit else 0.0)
            return abs(v) if absolute else v

        out={
            "price":price,
            "diff":n(diff_hit),
            "volume":volume,
            "bidho1":n(bid_hit,True),
            "offerho1":n(offer_hit,True),
            "bidrem1":n(bidrem_hit),
            "offerrem1":n(offerrem_hit),
            "high":n(high_hit,True) or price,
            "low":n(low_hit,True) or price,
            "hotime":str(time_hit[2] if time_hit else ""),
            "_volume_field":str(volume_field),
            "_volume_candidates":[{"field":str(x[3]),"value":x[1],"path":x[2]} for x in vol_candidates[:6]],
            "_leaf_keys":sorted({str(k) for _,k,_ in leafs})[:80],
        }
        self.integrated_last_sample={
            "code":code,"price":price,"volume":volume,"volumeField":str(volume_field),
            "volumeCandidates":out["_volume_candidates"],"keys":out["_leaf_keys"],
            "ts":time.time()
        }
        return out

    def reset_integrated_volume_session(self):
        self.integrated_volume_state.clear()

    async def integrated_quote(self,code):
        """LS (통합)주식현재가호가조회2 t8450.
        Parse the entire response recursively and normalize a real cumulative-volume
        field before the frozen morning scoring logic sees the quote.
        """
        d=await self.post_tr("t8450","/stock/market-data",{"t8450InBlock":{"shcode":code}})
        if not isinstance(d,(dict,list)):
            return {}
        return self._canonical_integrated(code,d)

    async def trades(self, code: str):
        d=await self.post_tr("t1301","/stock/market-data",{
            "t1301InBlock":{
                "shcode":code,"cvolume":0,
                "starttime":"","endtime":"","cts_time":""
            }
        })
        return d.get("t1301OutBlock1") or []

    async def stock_master(self):
        merged={}
        self.master_raw_rows=0
        self.master_valid_rows=0
        self.master_attempts=[]
        self.master_last_error=""

        def rows_from(obj):
            rows=[]
            if isinstance(obj,list):
                for v in obj:
                    if isinstance(v,dict):
                        keys={str(k).lower() for k in v}
                        if keys & {"shcode","expcode","code"} and keys & {"hname","name"}:
                            rows.append(v)
                        else:
                            rows.extend(rows_from(v))
            elif isinstance(obj,dict):
                keys={str(k).lower() for k in obj}
                if keys & {"shcode","expcode","code"} and keys & {"hname","name"}:
                    rows.append(obj)
                else:
                    for v in obj.values():
                        if isinstance(v,(dict,list)):
                            rows.extend(rows_from(v))
            return rows

        # Existing app request variants are aggregated. No early-success break.
        for gubun in ("0","1","2"):
            try:
                d=await self.post_tr("t9945","/stock/market-data",
                                     {"t9945InBlock":{"gubun":gubun}},slow=True)
                rows=rows_from(d)
                self.master_raw_rows+=len(rows)
                accepted=0
                for r in rows:
                    code=clean_code(r.get("shcode") or r.get("expcode") or r.get("code"))
                    name=str(r.get("hname") or r.get("name") or "").strip()
                    if len(code)==6 and name and valid_equity_name(name):
                        merged[code]=StockMeta(code,name,"기타")
                        accepted+=1
                self.master_attempts.append({"gubun":gubun,"rows":len(rows),"accepted":accepted})
            except Exception as e:
                msg=f"{type(e).__name__}: {e}"
                self.master_attempts.append({"gubun":gubun,"rows":0,"accepted":0,"error":msg})
                self.master_last_error=msg

        self.master_valid_rows=len(merged)
        if merged:
            self.master_last_ok=time.time()
            return list(merged.values())
        if self.master_last_error:
            raise RuntimeError(self.master_last_error)
        return []

    def _rank_request_variants(self, tr_cd: str):
        """Conservative request variants for LS [주식] 상위종목.
        A successful variant is cached so normal operation uses one request per TR.
        """
        p=str(int(SCOUT_MIN_PRICE))
        if tr_cd=="t1441":  # 등락율 상위
            return [
                {"t1441InBlock":{"gubun1":"0","gubun2":"1","gubun3":"0","jc_num":"0","sprice":p,"eprice":"0","volume":"0","idx":"0","jc_num2":"0"}},
                {"t1441InBlock":{"gubun1":"0","gubun2":"1","gubun3":"1","jc_num":"0","sprice":p,"eprice":"0","volume":"0","idx":"0","jc_num2":"0"}},
                {"t1441InBlock":{"gubun1":"0","gubun2":"0","gubun3":"0","jc_num":"0","sprice":p,"eprice":"0","volume":"0","idx":"0","jc_num2":"0"}},
            ]
        if tr_cd=="t1452":  # 거래량 상위
            return [
                {"t1452InBlock":{"gubun":"0","jnilgubun":"1","sdiff":"0","ediff":"8","jc_num":"0","sprice":p,"eprice":"0","volume":"0","idx":"0"}},
                {"t1452InBlock":{"gubun":"0","jnilgubun":"0","sdiff":"0","ediff":"8","jc_num":"0","sprice":p,"eprice":"0","volume":"0","idx":"0"}},
            ]
        if tr_cd=="t1463":  # 거래대금 상위
            return [
                {"t1463InBlock":{"gubun":"0","jnilgubun":"1","jc_num":"0","sprice":p,"eprice":"0","volume":"0","idx":"0","jc_num2":"0"}},
                {"t1463InBlock":{"gubun":"0","jnilgubun":"0","jc_num":"0","sprice":p,"eprice":"0","volume":"0","idx":"0","jc_num2":"0"}},
            ]
        if tr_cd=="t1466":  # 전일동시간대비 거래급증
            return [
                {"t1466InBlock":{"gubun":"0","type1":"1","type2":"0","jc_num":"0","sprice":p,"eprice":"0","volume":"0","idx":"0","jc_num2":"0"}},
                {"t1466InBlock":{"gubun":"0","type1":"0","type2":"0","jc_num":"0","sprice":p,"eprice":"0","volume":"0","idx":"0","jc_num2":"0"}},
            ]
        raise ValueError(f"unsupported ranking TR: {tr_cd}")

    async def top_rank(self, tr_cd: str):
        if not hasattr(self,"rank_variant_cache"):
            self.rank_variant_cache={}
        variants=self._rank_request_variants(tr_cd)
        cached=self.rank_variant_cache.get(tr_cd)
        order=[]
        if isinstance(cached,int) and 0<=cached<len(variants):
            order.append(cached)
        order += [i for i in range(len(variants)) if i not in order]

        last=None
        for i in order:
            try:
                d=await self.post_tr(tr_cd,"/stock/high-item",variants[i],slow=True)
                rows=[]
                for k,v in d.items():
                    if k.startswith(f"{tr_cd}OutBlock") and isinstance(v,list):
                        rows.extend(v)
                # Cache only a variant that returned a structurally valid result.
                if rows:
                    self.rank_variant_cache[tr_cd]=i
                    return d
                last=RuntimeError(f"{tr_cd} empty")
            except asyncio.CancelledError:
                raise
            except Exception as e:
                last=e
        raise last or RuntimeError(f"{tr_cd} ranking failed")

    async def condition_list(self):
        variants=[
            {"t1866InBlock":{"user_id":"","gb":"0","group_name":"","cont":"0","cont_key":""}},
            {"t1866InBlock":{"user_id":"","gb":"0","group_name":""}},
            {"t1866InBlock":{"gb":"0","group_name":"","cont":"0","cont_key":""}},
        ]
        last=None
        for body in variants:
            try:
                return await self.post_tr("t1866","/stock/item-search",body,slow=True)
            except Exception as e:
                last=e
        raise last or RuntimeError("t1866 failed")

    async def condition_search(self,index):
        variants=[
            {"t1859InBlock":{"query_index":index}},
            {"t1859InBlock":{"query_index":index,"sRealFlag":"0"}},
        ]
        last=None
        for body in variants:
            try:
                return await self.post_tr("t1859","/stock/item-search",body,slow=True)
            except Exception as e:
                last=e
        raise last or RuntimeError("t1859 failed")


NEWS_DISPLAY_MAX = 10
NEWS_QUALITY_MIN = float(env_first("NEWS_QUALITY_MIN", default="64"))
NEWS_SECONDARY_MIN = float(env_first("NEWS_SECONDARY_MIN", default="45"))
NEWS_MAX_AGE_HOURS = float(env_first("NEWS_MAX_AGE_HOURS", default="30"))
NEWS_DISPLAY_AGE_HOURS = 24.0
NEWS_LIVE_WINDOW_SECONDS = 15*60
NEWS_SIMILARITY_THRESHOLD = 0.58

NEWS_NOISE = [
    "what size", "how to", "guide to", "best battery for", "home battery",
    "photo]", "[photo", "[포토]", "행사", "기념식", "세미나 개최", "컨퍼런스 참가",
    "우선주 발행", "보통주 발행", "신주 발행", "유상증자", "무상증자",
    "전환사채 발행", "신주인수권", "warrant exercise", "preferred shares",
    "private placement", "rights offering", "stock issuance",
    "인사", "임원 선임", "사외이사", "사회공헌", "봉사활동",
]
NEWS_CATALYST = [
    "수주", "계약", "공급", "증설", "투자", "capex", "order", "contract",
    "supply", "capacity", "guidance", "earnings", "export", "수출",
    "tariff", "관세", "subsidy", "보조금", "sanction", "제재",
    "export control", "수출통제", "shortage", "부족", "demand", "수요",
    "price hike", "가격 인상", "partnership", "협력", "acquisition", "인수",
    "approval", "승인", "regulation", "규제",
    "ban", "금지", "policy", "정책", "budget", "예산",
]
NEWS_KOREA_LINK = [
    "korea", "korean", "south korea", "한국", "국내",
    "samsung", "삼성", "sk hynix", "sk하이닉스", "lg energy", "lg에너지",
    "hyundai", "현대", "hanwha", "한화", "doosan", "두산", "posco", "포스코",
]
NEWS_GLOBAL_LEADERS = [
    "nvidia", "tsmc", "asml", "micron", "amd", "intel", "apple",
    "microsoft", "amazon", "google", "meta", "tesla", "openai",
    "catl", "byd", "toyota", "volkswagen",
]
NEWS_STRONG_MACRO = [
    "fed", "federal reserve", "cpi", "ppi", "jobs report", "interest rate",
    "금리", "환율", "원달러", "관세", "tariff", "export control", "수출통제",
    "sanction", "제재", "oil price", "유가", "china stimulus", "중국 부양",
]
NEWS_SOURCE_BONUS = {
    "reuters": 12, "bloomberg": 12, "financial times": 10,
    "cnbc": 8, "nikkei": 9, "yonhap": 8, "연합뉴스": 8,
    "한국경제": 7, "매일경제": 7, "서울경제": 6, "머니투데이": 6,
    "전자신문": 7, "조선비즈": 6, "businesskorea": 5,
}

def title_source_hint(title: str, feed_source: str) -> str:
    parts = title.rsplit(" - ", 1)
    if len(parts) == 2 and 1 <= len(parts[1]) <= 60:
        return parts[1].strip()
    return feed_source or "NEWS"

def keyword_hit(low: str, keyword: str) -> bool:
    """Phrase-aware matching. Short English tokens such as AI/EV must be whole tokens."""
    kw = keyword.lower().strip()
    if not kw:
        return False
    if re.fullmatch(r"[a-z0-9]+", kw) and len(kw) <= 3:
        return re.search(rf"(?<![a-z0-9]){re.escape(kw)}(?![a-z0-9])", low) is not None
    return kw in low

def contains_any(low: str, words) -> bool:
    return any(keyword_hit(low, w) for w in words)

NEWS_STOCK_ALIASES = {
    "삼성전기": ["삼성전기", "samsung electro-mechanics", "samsung electro mechanics"],
    "삼성전자": ["삼성전자", "samsung electronics"],
    "SK하이닉스": ["sk하이닉스", "sk hynix"],
    "LG에너지솔루션": ["lg에너지솔루션", "lg energy solution"],
    "현대모비스": ["현대모비스", "hyundai mobis"],
    "한화에어로스페이스": ["한화에어로스페이스", "hanwha aerospace"],
    "LS ELECTRIC": ["ls electric"],
    "HD현대일렉트릭": ["hd현대일렉트릭", "hd hyundai electric"],
    "두산로보틱스": ["두산로보틱스", "doosan robotics"],
    "레인보우로보틱스": ["레인보우로보틱스", "rainbow robotics"],
    "코리아써키트": ["코리아써키트", "korea circuit"],
    "이오테크닉스": ["이오테크닉스", "eo technics"],
    "한미반도체": ["한미반도체", "hanmi semiconductor"],
    "포스코퓨처엠": ["포스코퓨처엠", "posco future m"],
}

def parse_news_time(node) -> float:
    """Use publisher time when available instead of treating ingestion time as publication time."""
    try:
        if node is None or not node.text:
            return time.time()
        dt = parsedate_to_datetime(node.text.strip())
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.timestamp()
    except Exception:
        return time.time()

def normalize_news_title(title: str) -> str:
    base = title.rsplit(" - ", 1)[0].lower()
    base = re.sub(r"[^0-9a-z가-힣]+", " ", base)
    return re.sub(r"\s+", " ", base).strip()


class NewsEngine:
    def __init__(self,tm:TokenManager, base_map:Dict[str,StockMeta]):
        self.tm=tm
        self.base_map=base_map
        self.items:Deque[Dict[str,Any]]=deque(maxlen=250)
        self.secondary:Deque[Dict[str,Any]]=deque(maxlen=250)
        self.seen=set()
        self.last_ok=0.0
        self.ws_ok=0.0
        self.last_error=""
        self.discarded=0
        self.feed_success=0
        self.last_new_at=0.0
        self.last_new_count=0
        self.total_new=0
        self.latest_item_ts=0.0

    def classify(self,title):
        low=title.lower()
        return [sec for sec,kws in SECTOR_KEYWORDS.items() if contains_any(low,kws)][:3]

    def direct_stock_names(self,title):
        low=title.lower()
        found=[]
        for name,aliases in NEWS_STOCK_ALIASES.items():
            if any(keyword_hit(low,a) for a in aliases):
                found.append(name)
        # Also accept exact names from the base universe.
        for m in self.base_map.values():
            if m.name and m.name.lower() in low and m.name not in found:
                found.append(m.name)
        return found[:5]

    def quality(self,title,feed_source,sectors,direct):
        low=title.lower()
        if contains_any(low,[x.lower() for x in NEWS_NOISE]):
            return 0,["노이즈"]

        publisher=title_source_hint(title,feed_source)
        src_low=publisher.lower()
        score=16
        reasons=[]

        src_bonus=0
        for k,v in NEWS_SOURCE_BONUS.items():
            if k in src_low:
                src_bonus=max(src_bonus,v)
        if src_bonus:
            score+=src_bonus; reasons.append("신뢰출처")

        catalyst=contains_any(low,NEWS_CATALYST)
        korea=contains_any(low,NEWS_KOREA_LINK)
        leader=contains_any(low,NEWS_GLOBAL_LEADERS)
        macro=contains_any(low,NEWS_STRONG_MACRO)

        if catalyst:
            score+=23; reasons.append("신규촉매")
        if direct:
            score+=26; reasons.append("국내종목 직접")
        elif korea:
            score+=18; reasons.append("한국증시 연결")
        if sectors:
            score+=8+min(8,4*len(sectors)); reasons.append("산업 연결")
        if leader and catalyst:
            score+=10; reasons.append("글로벌 선도기업")
        if macro:
            score+=13; reasons.append("거시/정책")

        # A foreign/local lifestyle story should not survive on a generic sector keyword alone.
        if not direct and not korea and not macro and not (leader and catalyst):
            score-=30
        if not catalyst and not macro and not direct:
            score-=20

        return max(0,min(100,score)),reasons[:4]

    def secondary_ok(self,title,sectors,direct,quality):
        if quality < NEWS_SECONDARY_MIN:
            return False
        low=(title or "").lower()
        if contains_any(low,[x.lower() for x in NEWS_NOISE]):
            return False
        catalyst=contains_any(low,NEWS_CATALYST)
        korea=contains_any(low,NEWS_KOREA_LINK)
        leader=contains_any(low,NEWS_GLOBAL_LEADERS)
        macro=contains_any(low,NEWS_STRONG_MACRO)
        # Secondary news still needs an investable connection.
        return bool(direct or macro or (sectors and (catalyst or korea or leader)))

    def _news_tokens(self,title):
        words=re.findall(r"[0-9a-zA-Z가-힣]+",normalize_news_title(title).lower())
        stop={"the","a","an","to","of","and","for","in","on","at","from","with","as","속보","단독","종합"}
        return {w for w in words if len(w)>=2 and w not in stop}

    def _is_similar_news(self,title,ts):
        a=self._news_tokens(title)
        if not a:return False
        for row in (list(self.items)+list(self.secondary))[:120]:
            if abs(float(ts)-float(row.get("ts",0)))>12*3600:continue
            b=self._news_tokens(row.get("title",""))
            if not b:continue
            if len(a&b)/max(1,len(a|b))>=NEWS_SIMILARITY_THRESHOLD:return True
        return False

    def prune(self):
        cutoff=time.time()-NEWS_DISPLAY_AGE_HOURS*3600
        self.items=deque(sorted((r for r in self.items if float(r.get("ts",0))>=cutoff),
                                key=lambda r:(float(r.get("ts",0)),float(r.get("quality",0))),reverse=True),maxlen=250)
        self.secondary=deque(sorted((r for r in self.secondary if float(r.get("ts",0))>=cutoff),
                                    key=lambda r:(float(r.get("ts",0)),float(r.get("quality",0))),reverse=True),maxlen=250)
        pool=list(self.items)+list(self.secondary)
        self.latest_item_ts=max([float(r.get("ts",0)) for r in pool],default=0.0)

    def freshness(self):
        now=time.time()
        newest=(now-self.latest_item_ts) if self.latest_item_ts else None
        lastnew=(now-self.last_new_at) if self.last_new_at else None
        fetch=(now-self.last_ok) if self.last_ok else None
        state="LIVE" if self.last_new_at and lastnew<=NEWS_LIVE_WINDOW_SECONDS else ("STALE" if self.latest_item_ts else "EMPTY")
        return {"state":state,"newestAgeSec":round(newest,1) if newest is not None else None,
                "lastNewSec":round(lastnew,1) if lastnew is not None else None,
                "lastFetchSec":round(fetch,1) if fetch is not None else None,
                "lastNewCount":self.last_new_count,"totalNew":self.total_new,
                "core":len(self.items),"supplement":len(self.secondary)}
    def add(self,title,source,ts=None):
        title=(title or "").strip()
        if len(title)<8:return False
        ts=float(ts or time.time())
        age_h=(time.time()-ts)/3600
        if age_h>NEWS_DISPLAY_AGE_HOURS or age_h<-1:
            self.discarded+=1;return False
        fp=hashlib.sha1(normalize_news_title(title).encode()).hexdigest()
        if fp in self.seen:return False
        if self._is_similar_news(title,ts):
            self.seen.add(fp);return False
        self.seen.add(fp)
        sectors=self.classify(title);direct=self.direct_stock_names(title)
        quality,reasons=self.quality(title,source,sectors,direct)
        row={"id":fp[:12],"title":title,"source":title_source_hint(title,source),"ts":ts,
             "sectors":sectors,"impact":round(quality),"quality":round(quality),
             "quality_reasons":reasons,"direct_stocks":direct}
        if quality>=NEWS_QUALITY_MIN:
            row["tier"]="CORE";self.items.append(row)
        elif self.secondary_ok(title,sectors,direct,quality):
            row["tier"]="SUPPLEMENT";self.secondary.append(row)
        else:
            self.discarded+=1;return False
        self.last_new_at=time.time();self.total_new+=1;self.latest_item_ts=max(self.latest_item_ts,ts)
        self.prune();return True

    async def refresh_once(self):
        successes=0;new_items=0
        self.prune()
        try:
            async with httpx.AsyncClient(timeout=15,follow_redirects=True) as cl:
                for url in NEWS_FEEDS:
                    try:
                        r=await cl.get(url,headers={"user-agent":"NOVA-PREIGNITION/1.3.8"})
                        if r.status_code>=400:continue
                        rt=ET.fromstring(r.text);successes+=1
                        ch=rt.find("channel")
                        if ch is not None:
                            sn=ch.find("title");source=(sn.text or "RSS").strip() if sn is not None else "RSS"
                            for item in ch.findall("item")[:30]:
                                tn=item.find("title")
                                if tn is not None and tn.text and self.add(tn.text,source,parse_news_time(item.find("pubDate"))):new_items+=1
                        else:
                            ns={"a":"http://www.w3.org/2005/Atom"}
                            sn=rt.find("a:title",ns);source=(sn.text or "RSS").strip() if sn is not None else "RSS"
                            for item in rt.findall("a:entry",ns)[:30]:
                                tn=item.find("a:title",ns)
                                if tn is None or not tn.text:continue
                                ts=time.time();un=item.find("a:updated",ns)
                                try:
                                    if un is not None and un.text:ts=datetime.fromisoformat(un.text.replace("Z","+00:00")).timestamp()
                                except Exception:pass
                                if self.add(tn.text,source,ts):new_items+=1
                    except Exception:continue
            self.feed_success=successes;self.last_new_count=new_items;self.prune()
            if successes>0:self.last_ok=time.time();self.last_error=""
            else:self.last_error="RSS: no successful feeds"
        except Exception as e:
            self.last_error=f"RSS {type(e).__name__}: {e}";self.last_new_count=0
        return successes

    async def rss_loop(self):
        while True:
            await self.refresh_once()
            await asyncio.sleep(NEWS_REFRESH_SECONDS)

    async def ls_ws_loop(self):
        if DEMO_MODE:
            return
        backoff=2
        while True:
            try:
                token=await self.tm.get()
                async with websockets.connect(
                    LS_WS_URL,open_timeout=15,ping_interval=20,ping_timeout=20,close_timeout=5
                ) as ws:
                    await ws.send(json.dumps({
                        "header":{"token":token,"tr_type":"3"},
                        "body":{"tr_cd":"NWS","tr_key":"NWS001"}},ensure_ascii=False))
                    backoff=2
                    async for raw in ws:
                        try:
                            d=json.loads(raw); h=d.get("header") or {}; b=d.get("body") or {}
                            if h.get("tr_cd")=="NWS" and b.get("title"):
                                self.add(b["title"],"LS NWS",time.time())
                                self.ws_ok=time.time()
                        except Exception:
                            pass
            except asyncio.CancelledError:
                raise
            except Exception as e:
                self.last_error=f"LS NWS {type(e).__name__}: {e}"
                await asyncio.sleep(backoff)
                backoff=min(60,backoff*2)

class DiscoveryEngine:
    def __init__(self,ls:LSRest,base:List[StockMeta],store:Store):
        self.ls=ls
        self.base={m.code:m for m in base}
        self.store=store
        self.candidates:Dict[str,CandidateHint]={}
        self.condition_indexes=list(CONDITION_INDEXES)
        self.condition_names={}
        self.last_condition_list=0.0
        self.last_ok=0.0
        self.last_error=""
        self.status="DEMO" if DEMO_MODE else "STARTING"
        self.raw_count=0
        self.condition_error=""
        self.scout_master:List[StockMeta]=[]
        self.scout_cursor=0
        self.scout_seen=0
        self.scout_passes=0
        self.scout_last=0.0
        self.scout_error=""
        self.scout_day=None
        self.rank_last=0.0
        self.rank_last_attempt=0.0
        self.rank_error=""
        self.rank_counts:Dict[str,int]={}
        self.rank_union_count=0
        self.rank_refreshes=0
        self.rank_partial=False
        self.condition_snapshots:Dict[str,CandidateHint]={}
        self.condition_last_hit=0.0
        self.condition_hit_count=0
        self.nxt_rank_state="STANDBY"
        self.nxt_rank_session=""
        self.nxt_rank_started=0.0
        self.nxt_rank_verified_at=0.0
        self.nxt_rank_snapshot:Dict[str,Tuple[float,float]]={}
        self.nxt_rank_evidence:Deque[Tuple[float,str]]=deque(maxlen=200)
        self.manual:Dict[str,StockMeta]={
            clean_code(x["code"]):StockMeta(clean_code(x["code"]),x["name"],"수동관심")
            for x in self.store.manual_watch() if clean_code(x["code"])
        }
        self.precision_codes:List[str]=list(self.base)[:MAX_PRECISION]

    def set_scout_master(self, meta_map):
        if isinstance(meta_map,dict):
            vals=list(meta_map.values())
        else:
            vals=list(meta_map or [])
        vals=[m for m in vals if isinstance(m,StockMeta) and len(m.code)==6 and valid_equity_name(m.name)]
        # Daily deterministic shuffle prevents the same block always being scanned first.
        day=now_kst().date().isoformat()
        vals.sort(key=lambda m:hashlib.sha1(f"{day}:{m.code}".encode()).hexdigest())
        self.scout_master=vals
        self.scout_day=day
        if self.scout_cursor>=len(vals): self.scout_cursor=0

    async def ensure_scout_master(self):
        day=now_kst().date().isoformat()
        if self.scout_master and self.scout_day==day:
            return
        if DEMO_MODE:
            self.set_scout_master(self.base)
            return
        try:
            rows=await self.ls.stock_master()
            self.set_scout_master(rows)
            self.scout_error=""
        except Exception as e:
            self.scout_error=f"{type(e).__name__}: {e}"
            if not self.scout_master:
                self.set_scout_master(self.base)

    def _nxt_session_key(self,phase=None):
        phase=phase or market_phase()
        return f"{now_kst().date().isoformat()}:{phase['code']}" if phase.get("nxt_verify") else ""

    def _reset_nxt_rank_session_if_needed(self,phase=None):
        phase=phase or market_phase()
        key=self._nxt_session_key(phase)
        if key and key!=self.nxt_rank_session:
            self.nxt_rank_session=key
            self.nxt_rank_started=time.time()
            self.nxt_rank_verified_at=0.0
            self.nxt_rank_snapshot={}
            self.nxt_rank_evidence.clear()
            self.nxt_rank_state="VERIFYING"
        elif not key:
            self.nxt_rank_session=""
            self.nxt_rank_started=0.0
            self.nxt_rank_verified_at=0.0
            self.nxt_rank_snapshot={}
            self.nxt_rank_evidence.clear()
            self.nxt_rank_state="STANDBY"

    def _update_nxt_rank_verification(self,merged,phase=None):
        phase=phase or market_phase()
        self._reset_nxt_rank_session_if_needed(phase)
        if not phase.get("nxt_verify") or not NXT_VERIFY_ENABLED:
            return
        now=time.time()
        for code,c in merged.items():
            old=self.nxt_rank_snapshot.get(code)
            cur=(float(c.price or 0),float(c.volume or 0))
            if old and cur[1]>old[1]:
                self.nxt_rank_evidence.append((now,code))
            self.nxt_rank_snapshot[code]=cur
        recent={code for ts,code in self.nxt_rank_evidence if now-ts<=NXT_VERIFY_EVIDENCE_SECONDS}
        if len(recent)>=NXT_VERIFY_MIN_CODES:
            self.nxt_rank_state="LIVE_VERIFIED"
            self.nxt_rank_verified_at=now
        elif self.nxt_rank_started and now-self.nxt_rank_started>=NXT_VERIFY_TIMEOUT_SECONDS:
            self.nxt_rank_state="UNVERIFIED"
        else:
            self.nxt_rank_state="VERIFYING"

    def condition_is_fresh(self):
        return bool(self.condition_last_hit and time.time()-self.condition_last_hit<=NXT_CONDITION_FRESH_SECONDS and self.condition_hit_count>0)

    def nxt_condition_snapshot(self,code):
        c=self.condition_snapshots.get(code)
        if not c or time.time()-c.last_seen>NXT_CONDITION_FRESH_SECONDS or c.price<=0:
            return None
        return c

    def rank_is_healthy(self):
        if DEMO_MODE:
            return True
        fresh=bool(RANK_SCOUT_ENABLED and self.rank_last and time.time()-self.rank_last<=RANK_STALE_SECONDS)
        if not fresh:
            return False
        phase=market_phase()
        if phase.get("nxt_verify") and NXT_VERIFY_ENABLED:
            return self.nxt_rank_state=="LIVE_VERIFIED"
        return True

    def _rank_rows(self,d,tr_cd):
        rows=[]
        for k,v in (d or {}).items():
            if k.startswith(f"{tr_cd}OutBlock") and isinstance(v,list):
                rows.extend(v)
        return rows

    def _rank_candidate(self,tr_cd,row,position,total):
        code=clean_code(row.get("shcode") or row.get("code") or row.get("expcode"))
        if len(code)!=6:
            return None
        name=str(row.get("hname") or row.get("name") or "").strip()
        if not name:
            # Prefer a known master/base name, but never block a valid code only
            # because the ranking row omitted hname.
            known=self.base.get(code)
            if not known and self.scout_master:
                known=next((m for m in self.scout_master if m.code==code),None)
            name=known.name if known else code
        if not valid_equity_name(name):
            return None

        price=abs(fnum(row.get("price") or row.get("close")))
        diff=fnum(row.get("diff") or row.get("diff_pct") or row.get("change_rate"))
        vol=max(0.0,fnum(row.get("volume") or row.get("vol")))
        if price<SCOUT_MIN_PRICE or price<=0 or diff>=OVERHEAT_DAILY_PCT or diff<=-5.0:
            return None

        # Ranking families carry different early-warning value.
        base={"t1466":18.0,"t1463":15.0,"t1452":13.0,"t1441":10.0}.get(tr_cd,8.0)
        rank_bonus=max(0.0,8.0-(position/max(1,total))*8.0)

        # Favor positive but not already extended price location.
        if -0.5 <= diff <= 4.5:
            location=max(0.0,8.0-abs(diff-1.8)*1.7)
        else:
            location=max(0.0,4.0-abs(diff-1.8))

        value=max(
            0.0,
            fnum(row.get("value")),
            price*vol
        )
        liq=max(0.0,min(8.0,(math.log10(max(1.0,value))-8.0)*2.7))

        # Volume acceleration clues differ by TR; use any field actually supplied.
        surge=0.0
        if tr_cd=="t1466":
            std=max(0.0,fnum(row.get("stdvolume")))
            vd=max(0.0,fnum(row.get("voldiff")))
            if std>0:
                surge=min(8.0,(vd/std)*4.0)
            elif vd>0:
                surge=min(6.0,math.log10(1+vd)*0.9)
        else:
            bef=max(0.0,fnum(row.get("bef_diff")))
            if bef>0:
                surge=min(5.0,math.log10(1+bef)*0.8)

        extended_penalty=max(0.0,diff-5.0)*4.0
        hint=max(0.0,base+rank_bonus+location+liq+surge-extended_penalty)

        meta=self.base.get(code) or StockMeta(code,name,"LS상위후보")
        if meta.name==code and name!=code:
            meta=StockMeta(code,name,meta.sector)
        return CandidateHint(
            meta,price,diff,vol,round(hint,2),
            time.time(),time.time(),f"RANK:{tr_cd}"
        )

    def _effective_hint(self,c):
        age=max(0.0,time.time()-c.last_seen)
        # Fresh whole-market ranking hits decay quickly; a signal must keep
        # proving itself or graduate into the precision engine.
        decay=min(22.0,(age/60.0)*1.25) if c.source.startswith("RANK:") else 0.0
        return c.hint_score-decay

    async def rank_refresh_once(self):
        if not RANK_SCOUT_ENABLED:return False
        phase=market_phase()
        if phase["code"] in {"PRE","AFTER"}:
            self.status="NXT_INTEGRATED_SCOUT"
            return False
        if not phase["active"]:
            return False

        self.rank_last_attempt=time.time()

        if DEMO_MODE:
            now=time.time()
            for i,m in enumerate(list(self.base.values())[:MAX_CANDIDATES]):
                self.candidates[m.code]=CandidateHint(
                    m,0,0,0,30-i*0.1,now-60,now,"RANK:DEMO"
                )
            self.rank_counts={"DEMO":len(self.candidates)}
            self.rank_union_count=len(self.candidates)
            self.rank_last=now
            self.rank_refreshes+=1
            self.rank_partial=False
            self.status="DEMO"
            self.rebuild_precision()
            return True

        merged={}
        hits={}
        counts={}
        errors=[]
        success_trs=0

        for tr_cd in RANK_TRS:
            try:
                d=await self.ls.top_rank(tr_cd)
                rows=self._rank_rows(d,tr_cd)
                counts[tr_cd]=len(rows)
                if rows:
                    success_trs+=1
                for pos,row in enumerate(rows):
                    c=self._rank_candidate(tr_cd,row,pos,len(rows))
                    if not c:
                        continue
                    code=c.meta.code
                    if code not in merged or c.hint_score>merged[code].hint_score:
                        merged[code]=c
                    hits.setdefault(code,set()).add(tr_cd)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                counts[tr_cd]=0
                errors.append(f"{tr_cd}:{type(e).__name__}:{e}")

        now=time.time()
        if merged:
            # Cross-ranking overlap is one of the strongest light-filter clues.
            for code,c in merged.items():
                n=len(hits.get(code,set()))
                overlap=min(12.0,max(0,n-1)*4.0)
                c.hint_score=round(c.hint_score+overlap,2)
                c.source="RANK:"+"+".join(sorted(hits.get(code,set())))
                old=self.candidates.get(code)
                if old:
                    c.first_seen=old.first_seen
                c.last_seen=now
                self.candidates[code]=c

            self._update_nxt_rank_verification(merged,phase)
            self.rank_last=now
            self.rank_refreshes+=1
            self.rank_counts=counts
            self.rank_union_count=len(merged)
            self.rank_partial=success_trs<len(RANK_TRS)
            self.rank_error=" | ".join(errors)[:700] if errors else ""
            self.last_ok=now
            self.last_error=""

            if len(self.candidates)>MAX_CANDIDATES:
                keep=sorted(
                    self.candidates.values(),
                    key=self._effective_hint,
                    reverse=True
                )[:MAX_CANDIDATES]
                self.candidates={x.meta.code:x for x in keep}

            self.raw_count=len(self.candidates)
            self.rebuild_precision()
            self.status="RANK+COND" if self.condition_indexes else "LS_RANK"
            return True

        self._update_nxt_rank_verification({},phase)
        self.rank_counts=counts
        self.rank_union_count=0
        self.rank_partial=True
        self.rank_error=(" | ".join(errors) if errors else "상위종목 결과 0건")[:700]
        self.rebuild_precision()
        if self.condition_indexes:
            self.status="HYBRID"
        else:
            self.status="LS_SCOUT_FALLBACK"
        return False

    async def rank_loop(self):
        while True:
            try:
                await self.rank_refresh_once()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                self.rank_error=f"{type(e).__name__}: {e}"
            await asyncio.sleep(RANK_REFRESH_SECONDS)

    def scout_hint(self,meta,o):
        price=abs(fnum(o.get("price")))
        diff=fnum(o.get("diff"))
        vol=fnum(o.get("volume"))
        high=abs(fnum(o.get("high")))
        bid=fnum(o.get("bidrem1")); offer=fnum(o.get("offerrem1"))
        if price<SCOUT_MIN_PRICE or price<=0 or diff>=OVERHEAT_DAILY_PCT or diff<=-5.0:
            return None
        turnover=max(0,price*vol)
        # Sweet spot is positive but not already extended.
        location=max(0.0,11.0-abs(diff-1.8)*2.3)
        liq=max(0.0,min(12.0,(math.log10(max(1.0,turnover))-8.0)*4.0))
        highp=0.0
        if high>0:
            ratio=price/high
            if ratio>=0.985: highp=5.0
            elif ratio>=0.96: highp=3.0
        denom=max(1.0,bid+offer)
        br=bid/denom
        book=4.0 if br>=0.58 else 2.0 if br>=0.52 else 0.0
        positive=2.0 if 0.0<=diff<=4.5 else 0.0
        hint=location+liq+highp+book+positive
        return CandidateHint(meta,price,diff,vol,round(hint,2),time.time(),time.time(),"LS_SCOUT")

    async def scout_once(self,batch=None):
        if not SCOUT_ENABLED:
            return
        phase=market_phase()
        # 07:50-08:00 only prepares the master. Price scouting begins at 08:00.
        await self.ensure_scout_master()
        if not phase["active"]:
            return
        if not self.scout_master:
            return
        n=min(int(batch or SCOUT_BATCH),len(self.scout_master))
        for _ in range(n):
            meta=self.scout_master[self.scout_cursor]
            self.scout_cursor=(self.scout_cursor+1)%len(self.scout_master)
            if self.scout_cursor==0:self.scout_passes+=1
            try:
                if DEMO_MODE:
                    # Demo only proves routing; live ranking uses real t1101.
                    c=CandidateHint(meta,0,0,0,6,time.time(),time.time(),"LS_SCOUT")
                else:
                    phase2=market_phase()
                    o=(await self.ls.integrated_quote(meta.code)) if phase2["code"] in {"PRE","AFTER"} else (await self.ls.quote(meta.code))
                    c=self.scout_hint(meta,o)
                self.scout_seen+=1
                if c:
                    old=self.candidates.get(c.meta.code)
                    if old:c.first_seen=old.first_seen
                    self.candidates[c.meta.code]=c
            except asyncio.CancelledError:
                raise
            except Exception as e:
                self.scout_error=f"{type(e).__name__}: {e}"
                continue
        # Keep only the best light candidates. This is not the precision list.
        if len(self.candidates)>MAX_CANDIDATES:
            keep=sorted(self.candidates.values(),key=lambda x:x.hint_score,reverse=True)[:MAX_CANDIDATES]
            self.candidates={x.meta.code:x for x in keep}
        self.raw_count=len(self.candidates)
        self.scout_last=time.time()
        self.rebuild_precision()
        if DEMO_MODE:
            self.status="DEMO"
        elif self.rank_is_healthy():
            self.status="RANK+COND" if self.condition_indexes else "LS_RANK"
        elif self.condition_indexes:
            self.status="HYBRID"
        else:
            self.status="LS_SCOUT_FALLBACK"
        self.last_ok=time.time()
        self.last_error=""

    async def scout_loop(self):
        while True:
            try:
                # Ranking APIs are the normal whole-market intake.
                # The old one-by-one t1101 rotation runs only when ranking is stale/unavailable.
                phase=market_phase()
                if phase["code"] in {"PRE","AFTER"} or not self.rank_is_healthy():
                    await self.scout_once(); delay=SCOUT_INTERVAL_SECONDS
                else:
                    delay=max(60,SCOUT_INTERVAL_SECONDS)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                self.scout_error=f"{type(e).__name__}: {e}"
                delay=SCOUT_INTERVAL_SECONDS
            await asyncio.sleep(delay)

    def parse_condition_list(self,d):
        rows=[]
        for k,v in d.items():
            if k.startswith("t1866OutBlock") and isinstance(v,list):
                rows.extend(v)
        result=[]
        for r in rows:
            idx=str(r.get("query_index") or r.get("index") or r.get("queryno") or "").strip()
            name=str(r.get("query_name") or r.get("name") or "").strip()
            if idx:
                result.append((idx,name))
        return result

    def parse_condition_rows(self,d,index):
        rows=[]
        for k,v in d.items():
            if k.startswith("t1859OutBlock") and isinstance(v,list):
                rows.extend(v)
        out=[]
        for r in rows:
            code=clean_code(r.get("shcode") or r.get("code") or r.get("expcode"))
            if len(code)!=6:continue
            name=str(r.get("hname") or r.get("name") or self.base.get(code,StockMeta(code,code)).name or code).strip()
            if not valid_equity_name(name):continue
            price=abs(fnum(r.get("price") or r.get("close")))
            diff=fnum(r.get("diff") or r.get("diff_pct") or r.get("change_rate"))
            vol=fnum(r.get("volume") or r.get("vol"))
            # Pre-ignition screen: already strongly overheated names are not precision priority.
            location=max(0,7-abs(diff-1.8))
            liquidity=math.log10(max(1,price*vol))/2 if price and vol else 0
            hint=location+liquidity
            out.append(CandidateHint(StockMeta(code,name,"LS조건후보"),price,diff,vol,hint,time.time(),time.time(),f"COND:{index}"))
        return out

    def rebuild_precision(self):
        now=time.time()
        # Expire condition names not seen for 15 minutes, but keep base/holdings.
        for c in list(self.candidates):
            if now-self.candidates[c].last_seen>900:
                del self.candidates[c]
        vals=list(self.candidates.values())
        vals.sort(key=lambda x:x.hint_score,reverse=True)
        fresh=sorted(vals,key=lambda x:x.first_seen,reverse=True)[:10]
        picked=[]
        for c in self.manual:
            if c and c not in picked:
                picked.append(c)
        for x in fresh+vals:
            if x.meta.code not in picked:
                picked.append(x.meta.code)
            if len(picked)>=MAX_PRECISION:break
        # holdings must always be observable
        for h in self.store.holdings():
            c=clean_code(h["code"])
            if c and c not in picked:
                picked.insert(0,c)
        # base fallback fills unused capacity
        for c in self.base:
            if c not in picked:
                picked.append(c)
            if len(picked)>=MAX_PRECISION:break
        self.precision_codes=picked[:MAX_PRECISION]

    def add_manual(self, meta: StockMeta):
        self.manual[meta.code]=StockMeta(meta.code,meta.name,meta.sector or "수동관심")
        self.store.upsert_manual_watch(meta.code,meta.name)
        self.rebuild_precision()

    def remove_manual(self, code: str):
        self.manual.pop(code,None)
        self.store.delete_manual_watch(code)
        self.rebuild_precision()

    async def refresh(self):
        if DEMO_MODE:
            now=time.time()
            for m in self.base.values():
                self.candidates[m.code]=CandidateHint(m,0,0,0,5,now-600,now,"DEMO")
            self.raw_count=len(self.candidates)
            self.rebuild_precision()
            self.status="DEMO"
            self.last_ok=time.time()
            return
        phase=market_phase()
        if not phase["active"]:
            self.status="CLOSED"
            return
        try:
            if not self.condition_indexes and time.time()-self.last_condition_list>CONDITION_LIST_REFRESH_SECONDS:
                d=await self.ls.condition_list()
                lst=self.parse_condition_list(d)
                self.condition_indexes=[x[0] for x in lst[:MAX_CONDITIONS]]
                self.condition_names={x[0]:x[1] for x in lst}
                self.last_condition_list=time.time()

            if not self.condition_indexes:
                self.status="NO_CONDITION"
                self.last_error="LS 서버저장 조건식 없음"
                self.rebuild_precision()
                return

            merged={}
            for idx in self.condition_indexes[:MAX_CONDITIONS]:
                d=await self.ls.condition_search(idx)
                for c in self.parse_condition_rows(d,idx):
                    old=self.candidates.get(c.meta.code)
                    if old:
                        c.first_seen=old.first_seen
                    c.last_seen=time.time()
                    if c.meta.code not in merged or c.hint_score>merged[c.meta.code].hint_score:
                        merged[c.meta.code]=c
            for code,c in merged.items():
                self.candidates[code]=c
            self.raw_count=len(merged)
            # cap the candidate pool
            if len(self.candidates)>MAX_CANDIDATES:
                keep=sorted(self.candidates.values(),key=lambda x:x.hint_score,reverse=True)[:MAX_CANDIDATES]
                self.candidates={x.meta.code:x for x in keep}
            self.rebuild_precision()
            self.status="LS_CONDITION"
            self.last_ok=time.time()
            self.last_error=""
        except Exception as e:
            self.status="ERROR"
            self.last_error=f"{type(e).__name__}: {e}"
            self.rebuild_precision()

    async def loop(self):
        while True:
            await self.refresh()
            await asyncio.sleep(DISCOVERY_REFRESH_SECONDS)


class MarketDiscovery(DiscoveryEngine):
    """Independent discovery lane for KRX or NXT."""
    def __init__(self,ls:LSRest,base:List[StockMeta],store:Store,market:str):
        super().__init__(ls,base,store)
        self.market=market
        self.manual={}
        self.status=f"{market}_STARTING"
        self.full_master=[]
        self.background_master=[]
        self.background_cursor=0
        self.background_seen=0
        self.background_promoted=0
        self.tracking_since={}
        self.tracking_replacements=0
        self.tracking_last_change=0.0
        self.tracking_generation=0
    def set_scout_master(self,meta_map):
        vals=list(meta_map.values()) if isinstance(meta_map,dict) else list(meta_map or [])
        vals=[m for m in vals if isinstance(m,StockMeta) and len(m.code)==6 and valid_equity_name(m.name)]
        day=now_kst().date().isoformat()
        vals.sort(key=lambda m:hashlib.sha1(f"{day}:{self.market}:{m.code}".encode()).hexdigest())
        pins=set(self.base)
        pinned=[m for m in vals if m.code in pins]
        rest=[m for m in vals if m.code not in pins]
        active=(pinned+rest)[:ACTIVE_UNIVERSE_MAX]
        ac={m.code for m in active}
        self.full_master=vals
        self.scout_master=active
        self.background_master=[m for m in vals if m.code not in ac]
        self.scout_day=day
        self.scout_cursor=0 if self.scout_cursor>=len(active) else self.scout_cursor
        self.background_cursor=0 if self.background_cursor>=len(self.background_master) else self.background_cursor
        self.rebuild_precision()

    def promote_background(self,meta,hint):
        if meta.code in {m.code for m in self.scout_master}:return False
        if hint.hint_score<BACKGROUND_PROMOTE_HINT:return False
        pins=set(self.base); evict=None; evscore=1e9
        for i,m in enumerate(self.scout_master):
            if m.code in pins:continue
            h=self.candidates.get(m.code); score=h.hint_score if h else -1.0
            if score<evscore:evscore=score;evict=i
        if evict is None:return False
        old=self.scout_master[evict]
        self.scout_master[evict]=meta
        self.background_master=[m for m in self.background_master if m.code!=meta.code]
        if old.code not in {m.code for m in self.background_master}:self.background_master.append(old)
        self.background_promoted+=1
        return True

    async def background_scout_once(self,batch=BACKGROUND_BATCH_PER_PASS):
        if DEMO_MODE or not self.background_master:return
        if not market_phase()["active"]:return
        n=min(int(batch),len(self.background_master))
        for _ in range(n):
            meta=self.background_master[self.background_cursor]
            self.background_cursor=(self.background_cursor+1)%len(self.background_master)
            try:
                o=await self.ls.integrated_quote(meta.code) if self.market=="NXT" else await self.ls.quote(meta.code)
                c=self.scout_hint(meta,o);self.background_seen+=1
                if not c:continue
                old=self.candidates.get(c.meta.code)
                if old:c.first_seen=old.first_seen
                self.candidates[c.meta.code]=c
                self.promote_background(meta,c)
            except asyncio.CancelledError:raise
            except Exception as e:self.scout_error=f"BG {type(e).__name__}: {e}"
        if len(self.candidates)>MAX_CANDIDATES:
            keep=sorted(self.candidates.values(),key=lambda x:x.hint_score,reverse=True)[:MAX_CANDIDATES]
            self.candidates={x.meta.code:x for x in keep}
        self.raw_count=len(self.candidates);self.rebuild_precision()

    def rebuild_precision(self):
        now=time.time()
        for c in list(self.candidates):
            if now-self.candidates[c].last_seen>900:
                del self.candidates[c]

        active_codes={m.code for m in self.scout_master}
        current=[c for c in self.precision_codes if c in active_codes]
        changed=(current!=self.precision_codes)

        for c in list(self.tracking_since):
            if c not in active_codes:
                self.tracking_since.pop(c,None)

        # Initial/fill only. Existing members are never cursor-rotated.
        ranked=sorted(self.candidates.values(),key=lambda x:(x.hint_score,x.last_seen),reverse=True)
        if not current:
            for h in ranked:
                if h.meta.code in active_codes and h.meta.code not in current:
                    current.append(h.meta.code);self.tracking_since[h.meta.code]=now
                if len(current)>=MAX_PRECISION:break
            for m in self.scout_master:
                if m.code not in current:
                    current.append(m.code);self.tracking_since[m.code]=now
                if len(current)>=MAX_PRECISION:break
            changed=True
        elif len(current)<MAX_PRECISION:
            for h in ranked:
                if h.meta.code in active_codes and h.meta.code not in current:
                    current.append(h.meta.code);self.tracking_since[h.meta.code]=now;changed=True
                if len(current)>=MAX_PRECISION:break
            if len(current)<MAX_PRECISION:
                for m in self.scout_master:
                    if m.code not in current:
                        current.append(m.code);self.tracking_since[m.code]=now;changed=True
                    if len(current)>=MAX_PRECISION:break

        # At most one replacement after 10-minute minimum hold.
        if len(current)>=MAX_PRECISION and ranked:
            challengers=[h for h in ranked if h.meta.code in active_codes and h.meta.code not in current]
            if challengers:
                replaceable=[]
                for c in current:
                    held=now-self.tracking_since.get(c,now)
                    if held<TRACKING_MIN_HOLD_SECONDS:
                        continue
                    old=self.candidates.get(c)
                    old_score=old.hint_score if old else 0.0
                    replaceable.append((old_score,c))
                if replaceable:
                    replaceable.sort()
                    old_score,old_code=replaceable[0]
                    new=challengers[0]
                    if new.hint_score>=old_score+TRACKING_REPLACE_MARGIN:
                        i=current.index(old_code)
                        current[i]=new.meta.code
                        self.tracking_since.pop(old_code,None)
                        self.tracking_since[new.meta.code]=now
                        self.tracking_replacements+=1
                        changed=True

        for c in current:self.tracking_since.setdefault(c,now)
        self.precision_codes=current[:MAX_PRECISION]
        if changed:
            self.tracking_generation+=1
            self.tracking_last_change=now

class Nova:
    def __init__(self,base,store):
        self.base={m.code:m for m in base}
        self.store=store
        self.tm=TokenManager()
        self.ls=LSRest(self.tm)
        self.news=NewsEngine(self.tm,self.base)

        self.krx_discovery=MarketDiscovery(self.ls,base,store,"KRX")
        self.nxt_discovery=MarketDiscovery(self.ls,base,store,"NXT")
        self.krx_states:Dict[str,StockState]={}
        self.nxt_states:Dict[str,StockState]={}
        self.decision_states:Dict[str,StockState]={}

        self.last_scan={"KRX":0.0,"NXT":0.0}
        self.tracking_busy={"KRX":False,"NXT":False}
        self.tracking_passes={"KRX":0,"NXT":0}
        self.tracking_quote_ok={"KRX":0,"NXT":0}
        self.tracking_price_changes={"KRX":0,"NXT":0}
        self.tracking_prev_price={"KRX":{},"NXT":{}}
        self.tracking_last_pass_end={"KRX":0.0,"NXT":0.0}
        self.last_signal={}
        self.last_occurrence={}
        self.lane_session={"KRX":"","NXT":""}
        self.started=time.time()
        self.tasks=[]

        self.stock_master_cache:Dict[str,StockMeta]={}
        self.stock_master_at=0.0
        self.ls_master_count=0
        self.master_source="NONE"
        self.master_ready=False
        self.master_error=""
        self.decision_cache:Dict[str,Dict[str,Any]]={}
        self.last_manual_signal:Dict[str,float]={}

        # Legacy retained-signal feedback is disabled.
        self.signal_memory={}

        self.nxt_integrated_last_ok=0.0
        self.nxt_integrated_error=""
        self.nxt_integrated_success=0
        self.nxt_integrated_zero=0
        self.nxt_volume_positive=0
        self.nxt_volume_changed=0
        self.nxt_last_volume_by_code:Dict[str,float]={}

        self.nxt_quote_state="STANDBY"
        self.nxt_quote_session=""
        self.nxt_quote_started=0.0
        self.nxt_quote_verified_at=0.0
        self.nxt_quote_last_evidence=0.0
        self.nxt_quote_prev:Dict[str,Tuple[float,float,str]]={}
        self.nxt_quote_evidence:Deque[Tuple[float,str]]=deque(maxlen=300)

        self.warmup={
            "day":None,"state":"IDLE","ready":False,"auth":False,
            "master":False,"news":False,"discovery":False,
            "started_ts":None,"completed_ts":None,"last_error":""
        }

    def meta_for(self,code,market=""):
        if code in self.base:return self.base[code]
        discs=[self.krx_discovery,self.nxt_discovery] if market!="NXT" else [self.nxt_discovery,self.krx_discovery]
        for d in discs:
            h=d.candidates.get(code)
            if h:return h.meta
        for x in self.store.manual_watch():
            if clean_code(x["code"])==code:return StockMeta(code,x["name"],"수동관심")
        for x in self.store.holdings():
            if clean_code(x["code"])==code:return StockMeta(code,x["name"],"보유")
        return StockMeta(code,code,"기타")

    async def start(self):
        self.tasks=[
            asyncio.create_task(self.discovery_lane_loop("KRX")),
            asyncio.create_task(self.discovery_lane_loop("NXT")),
            asyncio.create_task(self.market_lane_loop("KRX")),
            asyncio.create_task(self.market_lane_loop("NXT")),
            asyncio.create_task(self.news.rss_loop()),
            asyncio.create_task(self.news.ls_ws_loop()),
            asyncio.create_task(self.warmup_scheduler_loop()),
            asyncio.create_task(self.decision_monitor_loop()),
            asyncio.create_task(self.outcome_loop()),
        ]

    async def stop(self):
        for t in self.tasks:t.cancel()
        await asyncio.gather(*self.tasks,return_exceptions=True)

    def demo_quote(self,meta):
        now=time.time(); seed=int(hashlib.md5(meta.code.encode()).hexdigest()[:8],16)
        base=18000+(seed%160000); wave=math.sin(now/110+seed%9)*0.7; trend=((seed%13)-5)*0.08
        diff=max(-3.5,min(5.5,wave+trend)); price=base*(1+diff/100)
        t=int(now//POLL_SECONDS); cumulative=100000+((t*((seed%650)+300))%6000000)
        imb=((seed+t)%55-20)/100
        return Quote(now,round(price/10)*10,round(diff,2),float(cumulative),
                     round(price*0.999/10)*10,round(price*1.001/10)*10,
                     1200*(1+imb),1200*(1-imb),price*1.018,price*0.982)

    def quote_from(self,o,source="T1101_KRX"):
        if not isinstance(o,dict):o={}
        def pick(*keys):
            for k in keys:
                v=o.get(k)
                if v not in (None,""):
                    return v
            return 0
        price=abs(fnum(pick("price","nowprice","close","curpr","current_price")))
        diff=fnum(pick("diff","diff_pct","change_rate","rate","chg_rate"))
        volume=fnum(pick("volume","vol","cvolume","cum_volume","total_volume"))
        bid=abs(fnum(pick("bidho1","bid1","bid","bid_price1")))
        offer=abs(fnum(pick("offerho1","offer1","offer","ask1","ask_price1")))
        bidrem=fnum(pick("bidrem1","bidrem","bid_qty","bidqty1","bid_volume1"))
        offerrem=fnum(pick("offerrem1","offerrem","offer_qty","offerqty1","ask_volume1"))
        high=abs(fnum(pick("high","highprc","high_price"))) or price
        low=abs(fnum(pick("low","lowprc","low_price"))) or price
        hotime=str(pick("hotime","chetime","time","trade_time") or "")
        return Quote(time.time(),price,diff,volume,bid,offer,bidrem,offerrem,high,low,hotime,source)

    def quote_from_condition(self,c):
        return Quote(time.time(),float(c.price),float(c.diff_pct),float(c.volume),
                     0.0,0.0,0.0,0.0,float(c.price),float(c.price),"","NXT_CONDITION")

    def _nxt_quote_session_key(self,phase=None):
        phase=phase or market_phase()
        return f"{now_kst().date().isoformat()}:{phase['code']}" if phase.get("nxt_verify") else ""

    def _reset_nxt_quote_session_if_needed(self,phase=None):
        phase=phase or market_phase()
        key=self._nxt_quote_session_key(phase)
        if key and key!=self.nxt_quote_session:
            self.nxt_quote_session=key
            self.nxt_quote_started=time.time()
            self.nxt_quote_verified_at=0.0
            self.nxt_quote_last_evidence=0.0
            self.nxt_quote_prev={}
            self.nxt_quote_evidence.clear()
            self.nxt_quote_state="VERIFYING"
        elif not key:
            self.nxt_quote_session=""
            self.nxt_quote_started=0.0
            self.nxt_quote_verified_at=0.0
            self.nxt_quote_last_evidence=0.0
            self.nxt_quote_prev={}
            self.nxt_quote_evidence.clear()
            self.nxt_quote_state="STANDBY"

    def observe_nxt_quote(self,code,q,phase=None):
        phase=phase or market_phase()
        self._reset_nxt_quote_session_if_needed(phase)
        if not phase.get("nxt_verify") or not NXT_VERIFY_ENABLED or q.verified_source!="T1101":
            return
        now=time.time()
        old=self.nxt_quote_prev.get(code)
        cur=(float(q.price or 0),float(q.volume or 0),str(q.market_time or ""))
        if old and cur[1]>old[1] and hotime_in_nxt_session(cur[2],phase["code"]):
            self.nxt_quote_evidence.append((now,code))
            self.nxt_quote_last_evidence=now
        self.nxt_quote_prev[code]=cur
        recent={c for ts,c in self.nxt_quote_evidence if now-ts<=NXT_VERIFY_EVIDENCE_SECONDS}
        if len(recent)>=NXT_VERIFY_MIN_CODES:
            self.nxt_quote_state="LIVE_VERIFIED"
            self.nxt_quote_verified_at=now
        elif self.nxt_quote_state=="LIVE_VERIFIED" and self.nxt_quote_last_evidence and now-self.nxt_quote_last_evidence>NXT_VERIFY_STALE_SECONDS:
            self.nxt_quote_state="STALE"
        elif self.nxt_quote_state!="LIVE_VERIFIED" and self.nxt_quote_started and now-self.nxt_quote_started>=NXT_VERIFY_TIMEOUT_SECONDS:
            self.nxt_quote_state="UNVERIFIED"
        elif self.nxt_quote_state!="LIVE_VERIFIED":
            self.nxt_quote_state="VERIFYING"

    def nxt_quote_is_verified(self):
        return self.nxt_quote_state=="LIVE_VERIFIED"

    def nxt_health(self):
        phase=market_phase()
        if not phase.get("nxt"):
            return {"state":"STANDBY","quoteState":"STANDBY","rankState":self.nxt_discovery.nxt_rank_state,"conditionFresh":self.nxt_discovery.condition_is_fresh(),"evidenceCodes":0}
        if phase["code"]=="AFTER_AUCTION":
            return {"state":"AUCTION","quoteState":"STANDBY","rankState":self.nxt_discovery.nxt_rank_state,"conditionFresh":self.nxt_discovery.condition_is_fresh(),"evidenceCodes":0}
        if not phase.get("nxt_verify"):
            return {"state":"PAUSE","quoteState":"STANDBY","rankState":self.nxt_discovery.nxt_rank_state,"conditionFresh":self.nxt_discovery.condition_is_fresh(),"evidenceCodes":0}
        now=time.time()
        recent={c for ts,c in self.nxt_quote_evidence if now-ts<=NXT_VERIFY_EVIDENCE_SECONDS}
        if self.nxt_quote_state=="LIVE_VERIFIED":
            state="LIVE_VERIFIED"
        elif self.nxt_discovery.condition_is_fresh():
            state="COND_FALLBACK"
        elif self.nxt_quote_state in {"UNVERIFIED","STALE"}:
            state="UNVERIFIED"
        else:
            state="VERIFYING"
        return {"state":state,"quoteState":self.nxt_quote_state,"rankState":self.nxt_discovery.nxt_rank_state,
                "conditionFresh":self.nxt_discovery.condition_is_fresh(),"conditionHits":self.nxt_discovery.condition_hit_count,
                "evidenceCodes":len(recent),
                "verifiedAgoSec":round(now-self.nxt_quote_verified_at,1) if self.nxt_quote_verified_at else None,
                "lastEvidenceAgoSec":round(now-self.nxt_quote_last_evidence,1) if self.nxt_quote_last_evidence else None}

    def past(self,h,seconds):
        if not h:return None
        cur=h[-1]
        for q in reversed(h):
            if cur.ts-q.ts>=seconds:return q
        return h[0]

    def catalyst(self,meta):
        score=0.0; reasons=[]; now=time.time()
        name_low=meta.name.lower()
        for n in list(self.news.items)[:100]:
            age=(now-n["ts"])/3600
            if age>24:continue
            direct=name_low and name_low in n["title"].lower()
            sector=meta.sector in n["sectors"] if meta.sector else False
            if direct:score+=max(2,8-age/4)
            elif sector:score+=max(1,3-age/8)
        score=min(20,score)
        if score>=12:reasons.append("뉴스 촉매 강함")
        elif score>=6:reasons.append("뉴스 촉매 확인")
        return score,reasons

    def _return_from_history(self, h: List[Quote], seconds: int):
        if not h:
            return None
        cur=h[-1]
        for q in reversed(h):
            if cur.ts-q.ts>=seconds:
                if q.price<=0:
                    return None
                return (cur.price/q.price-1)*100
        return None

    def _window_quotes(self, h: List[Quote], min_age: float, max_age: float):
        if not h:
            return []
        cur_ts=h[-1].ts
        return [q for q in h if min_age <= cur_ts-q.ts <= max_age]

    def _range_pct(self, rows: List[Quote]):
        if len(rows)<2:
            return 0.0
        prices=[q.price for q in rows if q.price>0]
        if len(prices)<2:
            return 0.0
        mid=max(1.0,statistics.median(prices))
        return (max(prices)-min(prices))/mid*100

    def squeeze_release_metrics(self, s: StockState, vol_accel: float):
        """Compression -> expansion transition using already observed quote history."""
        h=list(s.history)
        if not h:
            return 0.0,0.0,0.0

        # Recent 3 minutes versus the preceding 2~7 minutes.
        recent=self._window_quotes(h,0,180)
        prior=self._window_quotes(h,180,600)
        if len(recent)<3 or len(prior)<3:
            return 0.0,0.0,0.0

        prior_range=self._range_pct(prior)
        recent_range=self._range_pct(recent)
        if prior_range<=0 or recent_range<=0:
            return 0.0,prior_range,recent_range

        p3=self._return_from_history(h,180) or 0.0
        release_ratio=recent_range/max(0.08,prior_range)

        # No "release" credit for a downward expansion.
        if p3<=0.03 or release_ratio<1.10:
            return 0.0,prior_range,recent_range

        # Max 12 points.
        compression=max(0.0,min(1.0,(1.35-prior_range)/1.05))
        expansion=max(0.0,min(1.0,(release_ratio-1.10)/1.40))
        volume=max(0.0,min(1.0,(vol_accel-1.0)/1.50))
        direction=max(0.0,min(1.0,p3/0.80))

        score=4.0*compression + 4.0*expansion + 2.0*volume + 2.0*direction
        return round(min(12.0,score),1),round(prior_range,2),round(recent_range,2)

    def flow_persistence_metrics(self, s: StockState):
        """Persistent order-book pressure + signed execution-flow proxy.
        Uses t1101 snapshots already collected by the normal precision loop.
        """
        h=list(s.history)
        if len(h)<4:
            return 0.0,0.0,0.0

        cur_ts=h[-1].ts
        recent=[q for q in h if cur_ts-q.ts<=300]
        if len(recent)<4:
            return 0.0,0.0,0.0

        def imb(q):
            den=max(1.0,float(q.bid_qty)+float(q.offer_qty))
            return (float(q.bid_qty)-float(q.offer_qty))/den

        vals=[imb(q) for q in recent]
        one=[imb(q) for q in recent if cur_ts-q.ts<=60]
        three=[imb(q) for q in recent if cur_ts-q.ts<=180]
        avg5=sum(vals)/len(vals)
        avg3=sum(three)/len(three) if three else avg5
        avg1=sum(one)/len(one) if one else avg3
        positive_ratio=sum(1 for v in vals if v>=0.03)/len(vals)

        # Signed-volume proxy: rising-price intervals with volume expansion count positive.
        signed=0.0
        total=0.0
        for a,b in zip(recent[:-1],recent[1:]):
            dv=max(0.0,float(b.volume)-float(a.volume))
            if dv<=0:
                continue
            total+=dv
            if b.price>a.price:
                signed+=dv
            elif b.price<a.price:
                signed-=dv
        signed_ratio=signed/total if total>0 else 0.0

        # Max 12 points.
        sustain=max(0.0,min(1.0,(positive_ratio-0.45)/0.45))*4.0
        strength=max(0.0,min(1.0,(avg5-0.01)/0.18))*3.0
        strengthening=max(0.0,min(1.0,(avg1-avg5)/0.12))*2.0
        execution=max(0.0,min(1.0,(signed_ratio+0.05)/0.55))*2.0

        # If t1301 micro data is already available for a manually watched/held name,
        # use it only as confirmation; do not add extra calls for the broad scanner.
        micro=(self.decision_cache.get(s.meta.code) or {}).get("micro") or {}
        micro_bonus=0.0
        br=micro.get("buy_ratio")
        ch=micro.get("chdegree")
        if br is not None and float(br)>=0.55:
            micro_bonus=1.0
        elif ch is not None and float(ch)>=115:
            micro_bonus=1.0

        score=min(12.0,sustain+strength+strengthening+execution+micro_bonus)
        return round(score,1),round(avg5,3),round(signed_ratio,3)

    def relative_acceleration_metrics(self, s: StockState):
        """3m/5m stock return minus market/sector median using current monitored states.
        No additional market-index API calls are required.
        """
        h=list(s.history)
        stock3=self._return_from_history(h,180)
        stock5=self._return_from_history(h,300)
        if stock3 is None or stock5 is None:
            return 0.0,0.0,0.0

        market3=[]; market5=[]
        sector3=[]; sector5=[]
        meaningful_sector=s.meta.sector not in {"","기타","수동관심","보유","신호보존"}

        now=time.time()
        for other in (self.nxt_states.values() if str(s.source).startswith("NXT") else self.krx_states.values()):
            if other.meta.code==s.meta.code or len(other.history)<2:
                continue
            if other.last_update and now-other.last_update>180:
                continue
            oh=list(other.history)
            r3=self._return_from_history(oh,180)
            r5=self._return_from_history(oh,300)
            if r3 is None or r5 is None:
                continue
            market3.append(r3); market5.append(r5)
            if meaningful_sector and other.meta.sector==s.meta.sector:
                sector3.append(r3); sector5.append(r5)

        # Require enough peers before awarding relative-strength points.
        if len(market3)<3:
            return 0.0,0.0,0.0

        m3=statistics.median(market3)
        m5=statistics.median(market5)
        if len(sector3)>=2:
            sec3=statistics.median(sector3)
            sec5=statistics.median(sector5)
            bench3=0.4*m3+0.6*sec3
            bench5=0.4*m5+0.6*sec5
        else:
            bench3=m3; bench5=m5

        rel3=stock3-bench3
        rel5=stock5-bench5
        # Positive short-term RS that is becoming stronger than its 5m baseline.
        rel_accel=rel3-rel5*0.60

        base=max(0.0,min(1.0,(rel3-0.05)/1.00))*5.0
        accel=max(0.0,min(1.0,(rel_accel-0.03)/0.55))*3.0
        score=min(8.0,base+accel)

        # Avoid rewarding a stock that is merely "less weak" while still falling sharply.
        if stock3<0:
            score=min(score,2.0)

        return round(score,1),round(rel3,2),round(rel_accel,2)

    def relative_building_ok(self, stable: float, age_sec: float, relative: float,
                             flow: float, squeeze: float, rel_edge: float,
                             p5: float, diff_pct: float) -> bool:
        """Alternate path for a stock becoming a relative leader in a weak tape.
        Normal BUILDING >=65 remains untouched. A stock must show relative strength,
        persistent order flow, and either squeeze-release or positive 5-minute momentum.
        """
        return bool(
            age_sec >= REL_BUILDING_MIN_MINUTES*60
            and stable >= REL_BUILDING_MIN_SCORE
            and stable < BUILDING_THRESHOLD
            and relative >= REL_BUILDING_REL_MIN
            and flow >= REL_BUILDING_FLOW_MIN
            and rel_edge >= REL_BUILDING_EDGE_MIN
            and (squeeze >= REL_BUILDING_SQUEEZE_MIN or p5 > 0)
            and diff_pct < OVERHEAT_DAILY_PCT
            and diff_pct > -5
        )

    def score(self,s:StockState):
        h=list(s.history)
        if not h:return
        cur=h[-1]
        age_sec=max(0,cur.ts-h[0].ts)
        s.ready_minutes=math.floor((age_sec/60)*10)/10
        q60=self.past(h,60); q180=self.past(h,180); q300=self.past(h,300); q600=self.past(h,600)

        def rate(a,b):
            if not a or not b:return 0.0
            dt=max(1,b.ts-a.ts); return max(0,b.volume-a.volume)/dt

        recent_rate=rate(q60,cur)
        prev_rate=rate(q300,q60) if q300 and q60 and q300.ts<q60.ts else 0.0
        long_rate=rate(q600,q300) if q600 and q300 and q600.ts<q300.ts else prev_rate
        baseline=max(1.0,(prev_rate+long_rate)/2 if long_rate else prev_rate)
        vol_accel=recent_rate/baseline if baseline>0 else 1.0

        def pret(q):
            return ((cur.price/q.price)-1)*100 if q and q.price>0 else 0.0
        p3=pret(q180); p10=pret(q600)
        denom=max(1,cur.bid_qty+cur.offer_qty)
        imbalance=(cur.bid_qty-cur.offer_qty)/denom

        pv=vv=0.0
        for a,b in zip(h[:-1],h[1:]):
            dv=max(0,b.volume-a.volume); pv+=b.price*dv; vv+=dv
        vwap=pv/vv if vv else cur.price

        money=0.0
        if age_sec>=180:
            money += max(0,min(13,(vol_accel-1)*8))
            money += max(0,min(8,imbalance*13))
            turnover_min=recent_rate*60*cur.price
            if turnover_min>0:
                money += max(0,min(9,(math.log10(max(1,turnover_min))-7)*5))
            if cur.price>=vwap:money+=6
            if cur.diff_pct>0:money+=4
        money=min(40,money)

        accel=0.0
        if age_sec>=180:
            accel+=max(0,min(10,p3*7))
            accel+=max(0,min(7,p10*3))
            accel+=max(0,min(6,(vol_accel-1)*5))
            if q60 and cur.diff_pct>q60.diff_pct:accel+=2
        accel=min(25,accel)

        cat,catwhy=self.catalyst(s.meta)

        pos=0.0
        if -1<=cur.diff_pct<=4.5:pos+=6
        elif -2<=cur.diff_pct<OVERHEAT_DAILY_PCT:pos+=3
        if cur.price>=vwap:pos+=4
        if cur.high and cur.price>=cur.high*0.97:pos+=2
        if cur.diff_pct<OVERHEAT_DAILY_PCT:pos+=3
        pos=min(15,pos)

        raw=money+accel+cat+pos
        penalty=0.0
        if cur.diff_pct>=OVERHEAT_DAILY_PCT:
            penalty+=min(28,(cur.diff_pct-OVERHEAT_DAILY_PCT+1)*4)
        if cur.diff_pct<=-8:penalty+=15
        final=max(0,min(100,raw-penalty))

        # Reliability gate: no instant PRE-BUY before enough observed history.
        if age_sec<120:final=min(final,54)
        elif age_sec<300:final=min(final,64)
        elif age_sec<MIN_READY_MINUTES*60:final=min(final,77)

        recent_scores=[v for ts,v in s.score_history if cur.ts-ts<=300]
        smooth=sum(recent_scores)/len(recent_scores) if recent_scores else final
        stable=final*0.70+smooth*0.30

        delta_base=None
        for ts,v in s.score_history:
            if cur.ts-ts>=DELTA_LOOKBACK_SECONDS:
                delta_base=v
        delta=stable-delta_base if delta_base is not None else 0.0

        why=[]
        if age_sec<MIN_READY_MINUTES*60:why.append(f"가속 이력 {s.ready_minutes:.1f}분")
        if vol_accel>=1.35:why.append(f"거래속도 {vol_accel:.1f}배")
        if p3>=0.35:why.append(f"3분 +{p3:.1f}%")
        if imbalance>=0.12:why.append("매수호가 우위")
        if cur.price>=vwap:why.append("관측 VWAP 상회")
        why+=catwhy
        if cur.diff_pct>=OVERHEAT_DAILY_PCT:why.append("과열·추격금지")

        if cur.diff_pct>=OVERHEAT_DAILY_PCT:
            status="AVOID"
        elif stable>=PREBUY_THRESHOLD and age_sec>=MIN_READY_MINUTES*60:
            status="PRE-BUY"
        elif stable>=BUILDING_THRESHOLD and age_sec>=MIN_READY_MINUTES*60:
            status="BUILDING"
        elif stable>=WATCH_THRESHOLD:
            status="WATCH"
        else:
            status="EARLY"

        s.money=round(money,1); s.acceleration=round(accel,1); s.catalyst=round(cat,1); s.position=round(pos,1)
        s.pre_score=round(stable,1); s.delta_score=round(delta,1); s.status=status; s.why=why[:4]
        s.last_update=cur.ts; s.score_history.append((cur.ts,stable))

        if market_phase()["active"] and status=="PRE-BUY":
            lane="NXT" if str(s.source).startswith("NXT") else "KRX"
            skey=f"{lane}:{s.meta.code}"
            last=self.last_signal.get(skey,0)
            if cur.ts-last>=3600 and cur.price>0:
                self.store.add_signal(s.meta.code,s.meta.name,cur.price,s.pre_score,status,f"[{lane}] "+" · ".join(s.why))
                self.last_signal[skey]=cur.ts

    def lane_states(self,market:str):
        return self.krx_states if market=="KRX" else self.nxt_states

    def lane_discovery(self,market:str):
        return self.krx_discovery if market=="KRX" else self.nxt_discovery

    def lane_active(self,market:str,phase=None):
        phase=phase or market_phase()
        if market=="KRX":return phase["code"]=="REGULAR"
        return phase["code"] in {"PRE","AFTER"}

    def lane_session_key(self,market:str,phase=None):
        phase=phase or market_phase()
        day=now_kst().date().isoformat()
        if market=="KRX":return f"{day}:KRX"
        if phase["code"]=="PRE":return f"{day}:NXT_PRE"
        if phase["code"]=="AFTER":return f"{day}:NXT_AFTER"
        return self.lane_session.get("NXT") or f"{day}:NXT"

    def reset_lane_history_if_needed(self,market:str,phase=None):
        phase=phase or market_phase()
        if not self.lane_active(market,phase):return
        key=self.lane_session_key(market,phase)
        if self.lane_session.get(market)==key:return
        self.lane_session[market]=key
        for st in self.lane_states(market).values():
            st.history.clear();st.score_history.clear()
            st.ready_minutes=0.0;st.pre_score=0.0;st.delta_score=0.0
            st.status="EARLY";st.why=[]
        if market=="NXT":
            self.ls.reset_integrated_volume_session()
            self.nxt_last_volume_by_code.clear()

    async def discovery_lane_loop(self,market:str):
        disc=self.lane_discovery(market)
        last_condition_refresh=0.0
        while True:
            try:
                phase=market_phase()
                if self.lane_active(market,phase):
                    if self.tracking_busy.get(market):
                        await asyncio.sleep(0.25);continue
                    now=time.time()
                    if now-last_condition_refresh>=DISCOVERY_REFRESH_SECONDS:
                        await disc.refresh();last_condition_refresh=now
                    pass_before=disc.scout_passes
                    await disc.scout_once(batch=TRACKING_DISCOVERY_BUDGET)
                    disc.rebuild_precision()
                    if disc.scout_passes>pass_before and not self.tracking_busy.get(market):
                        await disc.background_scout_once(BACKGROUND_BATCH_PER_PASS)
                    if self.master_ready:disc.status=f"{market}_ACTIVE1000_TRACK30"
                    elif self.master_source=="LS_PARTIAL":disc.status=f"{market}_MASTER_PARTIAL"
                    else:disc.status=f"{market}_FALLBACK"
                else:
                    disc.status=f"{market}_STANDBY_TRACK{len(disc.precision_codes)}"
            except asyncio.CancelledError:raise
            except Exception as e:
                disc.status=f"{market}_ERROR";disc.last_error=f"{type(e).__name__}: {e}"
            await asyncio.sleep(0.6)

    def lane_payload(self,st:StockState,market:str):
        q=st.history[-1] if st.history else None
        return {"market":market,"code":st.meta.code,"name":st.meta.name,"sector":st.meta.sector,
                "price":round(q.price,2) if q else None,"diff_pct":round(q.diff_pct,2) if q else None,
                "pre_score":st.pre_score,"delta_score":st.delta_score,"money":st.money,
                "acceleration":st.acceleration,"catalyst":st.catalyst,"position":st.position,
                "ready_minutes":st.ready_minutes,"status":st.status,"why":st.why,"source":st.source,
                "updated_sec":round(time.time()-st.last_update,1) if st.last_update else None}

    def lane_today_next(self,market:str):
        rows=[self.lane_payload(st,market) for st in self.lane_states(market).values()
              if st.history and st.status in {"PRE-BUY","BUILDING"} and st.pre_score>=BUILDING_THRESHOLD]
        rows.sort(key=lambda x:(x["status"]=="PRE-BUY",x["pre_score"],x["delta_score"]),reverse=True)
        return rows[:10]

    def lane_igniting(self,market:str):
        rows=[self.lane_payload(st,market) for st in self.lane_states(market).values()
              if st.history and (st.history[-1].ts-st.history[0].ts)>=MIN_READY_MINUTES*60
              and st.status!="AVOID" and st.pre_score>=WATCH_THRESHOLD
              and st.delta_score>=IGNITING_DELTA_MIN]
        rows.sort(key=lambda x:(x["delta_score"],x["pre_score"]),reverse=True)
        return rows[:10]

    def record_occurrence_lane(self,st:StockState,kind:str,market:str):
        if not st.history:return
        q=st.history[-1];now=time.time()
        key=f"{now_kst().date()}:{market}:{st.meta.code}:{kind}"
        if now-self.last_occurrence.get(key,0)<900:return
        self.last_occurrence[key]=now
        self.store.add_occurrence({
            "day":now_kst().date().isoformat(),"ts":now,"market":market,
            "code":st.meta.code,"name":st.meta.name,"kind":kind,
            "price":q.price,"pre_score":st.pre_score,"delta_score":st.delta_score,
            "reason":" · ".join(st.why)
        })

    async def market_lane_loop(self,market:str):
        while True:
            phase=market_phase()
            if not self.lane_active(market,phase):
                self.tracking_busy[market]=False
                await asyncio.sleep(1);continue

            self.reset_lane_history_if_needed(market,phase)
            disc=self.lane_discovery(market);states=self.lane_states(market)
            disc.rebuild_precision()
            codes=list(disc.precision_codes)[:MAX_PRECISION] or list(self.base)[:MAX_PRECISION]
            started=time.time()
            self.tracking_busy[market]=True
            try:
                for code in codes:
                    try:
                        meta=self.meta_for(code,market)
                        st=states.get(code)
                        if not st:
                            st=StockState(meta=meta,source=f"{market}_BASE");states[code]=st
                        elif st.meta.name==st.meta.code and meta.name!=meta.code:
                            st.meta=meta

                        if DEMO_MODE:
                            q=self.demo_quote(meta);q.verified_source=f"{market}_DEMO";st.source=f"{market}_DEMO"
                        elif market=="KRX":
                            q=self.quote_from(await self.ls.quote(code),"KRX_T1101");st.source="KRX_T1101"
                        else:
                            q=self.quote_from(await self.ls.integrated_quote(code),"NXT_T8450");st.source="NXT_T8450"
                            if q.price>0:
                                self.nxt_integrated_last_ok=time.time();self.nxt_integrated_error=""
                                self.nxt_integrated_success+=1
                                if q.volume>0:
                                    self.nxt_volume_positive+=1
                                    pv=self.nxt_last_volume_by_code.get(code)
                                    if pv is not None and q.volume>pv:self.nxt_volume_changed+=1
                                    self.nxt_last_volume_by_code[code]=q.volume
                            else:self.nxt_integrated_zero+=1

                        if q.price<=0:continue
                        self.tracking_quote_ok[market]+=1
                        pp=self.tracking_prev_price[market].get(code)
                        if pp is not None and q.price!=pp:self.tracking_price_changes[market]+=1
                        self.tracking_prev_price[market][code]=q.price
                        st.history.append(q);self.score(st)
                        if st.status in {"BUILDING","PRE-BUY"}:
                            self.record_occurrence_lane(st,st.status,market)
                    except asyncio.CancelledError:raise
                    except Exception as e:
                        if market=="NXT":self.nxt_integrated_error=f"{type(e).__name__}: {e}"
                        log.warning("%s TRACK30 quote %s: %s",market,code,e)

                for row in self.lane_igniting(market):
                    st=states.get(row.get("code"))
                    if st:self.record_occurrence_lane(st,"IGNITING",market)
                self.last_scan[market]=time.time()
                self.tracking_passes[market]+=1
                self.tracking_last_pass_end[market]=time.time()
            finally:
                self.tracking_busy[market]=False

            await asyncio.sleep(max(1,POLL_SECONDS-(time.time()-started)))
    def selection_session_key(self,phase):
        return self.lane_session_key("KRX" if phase.get("code")=="REGULAR" else "NXT",phase)

    def reset_selection_history_if_session_changed(self,phase):
        return

    def record_occurrence(self,st:StockState,kind:str):
        lane="NXT" if str(st.source).startswith("NXT") else "KRX"
        self.record_occurrence_lane(st,kind,lane)

    async def market_loop(self):
        while True:
            await asyncio.sleep(3600)

    def payload(self,st,market=""):
        market=market or ("NXT" if str(st.source).startswith("NXT") else "KRX")
        return self.lane_payload(st,market)

    def purge_old_signal_days(self):
        today=now_kst().date().isoformat()
        for code,row in list(self.signal_memory.items()):
            if str(row.get("signal_day") or "")!=today:
                self.signal_memory.pop(code,None)
                self.store.delete_signal_memory(code)

    def _memory_row_from_state(self, st: StockState, existing: Optional[Dict[str,Any]]=None,
                               display_status: Optional[str]=None):
        q=st.history[-1]
        now=time.time()
        existing=existing or {}
        return {
            "code":st.meta.code,
            "name":st.meta.name,
            "signal_day":existing.get("signal_day") or now_kst().date().isoformat(),
            "signal_ts":float(existing.get("signal_ts") or now),
            "signal_price":float(existing.get("signal_price") or q.price),
            "signal_score":float(existing.get("signal_score") or st.pre_score),
            "max_score":max(float(existing.get("max_score") or 0),float(st.pre_score)),
            "last_valid_ts":now,
            "updated_ts":now,
            "last_price":float(q.price),
            "last_diff":float(q.diff_pct),
            "last_score":float(st.pre_score),
            "display_status":display_status or st.status,
            "why":list(st.why[:4]),
        }

    def update_signal_memory(self, st: StockState):
        if not st.history:
            return
        q=st.history[-1]
        now=time.time()
        self.purge_old_signal_days()
        existing=self.signal_memory.get(st.meta.code)

        fresh_signal=(
            (
                (st.status in {"BUILDING","PRE-BUY"} and st.pre_score>=BUILDING_THRESHOLD)
                or
                (st.status=="REL-BUILDING" and st.pre_score>=REL_BUILDING_MIN_SCORE)
            )
            and q.diff_pct<OVERHEAT_DAILY_PCT
        )

        if fresh_signal:
            row=self._memory_row_from_state(st,existing,st.status)
            self.signal_memory[st.meta.code]=row
            dbrow=dict(row)
            dbrow["reason_json"]=json.dumps(dbrow.pop("why"),ensure_ascii=False)
            self.store.upsert_signal_memory(dbrow)
        elif existing:
            # A signal does not disappear merely because one scan drops below BUILDING.
            # Keep it while the underlying setup is still reasonably intact.
            signal_price=max(1.0,float(existing.get("signal_price") or q.price))
            from_signal=(q.price/signal_price-1)*100
            valid=(
                st.status!="AVOID"
                and st.pre_score>=SIGNAL_RETAIN_MIN_SCORE
                and q.diff_pct<OVERHEAT_DAILY_PCT
                and q.diff_pct>-5
                and from_signal>-3.5
            )
            grace=(
                st.status!="AVOID"
                and st.pre_score>=SIGNAL_GRACE_MIN_SCORE
                and q.diff_pct<OVERHEAT_DAILY_PCT
                and q.diff_pct>-5
                and from_signal>-4.5
                and now-float(existing.get("last_valid_ts") or 0)<=SIGNAL_GRACE_SECONDS
            )
            if valid or grace:
                label=st.status if st.status in {"REL-BUILDING","BUILDING","PRE-BUY"} else ("VALID" if valid else "GRACE")
                row=self._memory_row_from_state(st,existing,label)
                if grace and not valid:
                    # Grace must not continually extend itself.
                    row["last_valid_ts"]=float(existing.get("last_valid_ts") or now)
                self.signal_memory[st.meta.code]=row
                dbrow=dict(row)
                dbrow["reason_json"]=json.dumps(dbrow.pop("why"),ensure_ascii=False)
                self.store.upsert_signal_memory(dbrow)
            else:
                self.signal_memory.pop(st.meta.code,None)
                self.store.delete_signal_memory(st.meta.code)

        # Same-day only. Tomorrow starts with a clean slate.
        self.purge_old_signal_days()

        # Bound monitoring cost.
        if len(self.signal_memory)>SIGNAL_MEMORY_MAX:
            keep=sorted(
                self.signal_memory.values(),
                key=lambda x:(float(x.get("last_score") or 0),float(x.get("last_valid_ts") or 0)),
                reverse=True
            )[:SIGNAL_MEMORY_MAX]
            keep_codes={x["code"] for x in keep}
            for code in list(self.signal_memory):
                if code not in keep_codes:
                    self.signal_memory.pop(code,None)
                    self.store.delete_signal_memory(code)

    def retained_today_next(self):
        return []

    def live_today_next(self,market="KRX"):
        return self.lane_today_next(market)

    def score_delta_at(self, s: StockState, seconds: int):
        if not s.history or not s.score_history:
            return None
        cur_ts=s.history[-1].ts
        for ts,val in reversed(s.score_history):
            if cur_ts-ts>=seconds:
                return round(float(s.pre_score)-float(val),1)
        return None

    def price_return_at(self, s: StockState, seconds: int):
        if not s.history:
            return None
        cur=s.history[-1]
        for q in reversed(s.history):
            if cur.ts-q.ts>=seconds:
                if q.price<=0:
                    return None
                return round((cur.price/q.price-1)*100,2)
        return None

    def buy_pressure_ok(self, s: StockState):
        if not s.history:
            return False,""
        q=s.history[-1]
        denom=max(1.0,float(q.bid_qty)+float(q.offer_qty))
        imbalance=(float(q.bid_qty)-float(q.offer_qty))/denom
        if imbalance>=0.05:
            return True,f"매수호가 +{imbalance*100:.0f}%"
        micro=(self.decision_cache.get(s.meta.code) or {}).get("micro") or {}
        br=micro.get("buy_ratio"); ch=micro.get("chdegree")
        if br is not None and float(br)>=0.52:
            return True,f"매수체결 {float(br)*100:.0f}%"
        if ch is not None and float(ch)>=105:
            return True,f"체결강도 {float(ch):.0f}"
        return False,""

    def igniting_payload(self, s: StockState, stage: str, delta: float, price_mom: float, pressure: str):
        p=self.payload(s)
        p["igniting_stage"]=stage
        p["igniting_delta"]=round(delta,1)
        p["igniting_price_momentum"]=round(price_mom,2)
        p["delta_score"]=round(delta,1)
        why=list(p.get("why") or [])
        if stage=="EARLY":
            why=[f"5분 가속 Δ +{delta:.1f}",f"5분 가격 +{price_mom:.2f}%"]+why
        else:
            why=[f"10분 가속 Δ +{delta:.1f}"]+why
        if pressure:
            why.insert(2,pressure)
        p["why"]=why[:5]
        return p

    def live_igniting(self,market="KRX"):
        return self.lane_igniting(market)

    def maybe_save_eod(self):
        # No rank_snapshots UPSERT in active scan path.
        return

    def ranked_views(self):
        ph=market_phase()
        return {
            "krxTodayNext":self.lane_today_next("KRX"),
            "krxIgniting":self.lane_igniting("KRX"),
            "nxtTodayNext":self.lane_today_next("NXT"),
            "nxtIgniting":self.lane_igniting("NXT"),
            "krxMode":"LIVE" if self.lane_active("KRX",ph) else ("RETAINED" if self.krx_states else "WAIT"),
            "nxtMode":"LIVE" if self.lane_active("NXT",ph) else ("RETAINED" if self.nxt_states else "WAIT"),
            "krxOccurrences":self.store.occurrence_market("KRX",30),
            "nxtOccurrences":self.store.occurrence_market("NXT",30),
        }

    def _reset_warmup_day(self):
        day=now_kst().date().isoformat()
        if self.warmup.get("day")!=day:
            self.warmup.update({
                "day":day,"state":"IDLE","ready":False,"auth":False,
                "master":False,"news":False,"discovery":False,
                "started_ts":None,"completed_ts":None,"last_error":""
            })

    async def run_warmup(self):
        self._reset_warmup_day()
        if self.warmup["state"]=="RUNNING":return
        self.warmup["state"]="RUNNING";self.warmup["started_ts"]=time.time();self.warmup["last_error"]=""
        try:
            if DEMO_MODE:self.warmup["auth"]=True
            else:
                await self.tm.get();self.warmup["auth"]=True

            await self.refresh_stock_master(force=True)
            self.warmup["master"]=bool(self.master_ready)

            try:
                await self.news.refresh_once()
                self.warmup["news"]=bool(self.news.last_ok or self.news.items)
            except Exception as ne:
                self.warmup["news"]=False
                log.warning("warmup news: %s",ne)

            self.warmup["discovery"]=bool(
                self.master_ready and
                len(self.krx_discovery.scout_master)>=MASTER_READY_MIN and
                len(self.nxt_discovery.scout_master)>=MASTER_READY_MIN
            )
            self.warmup["ready"]=bool(self.warmup["auth"] and self.warmup["master"] and self.warmup["discovery"])
            self.warmup["state"]="READY" if self.warmup["ready"] else "PARTIAL"
            if not self.master_ready:
                self.warmup["last_error"]=(
                    f"MASTER {self.master_source} {self.ls_master_count}/{MASTER_READY_MIN}"
                    + (f" · {self.master_error}" if self.master_error else "")
                )
            self.warmup["completed_ts"]=time.time()
        except Exception as e:
            self.warmup["state"]="ERROR";self.warmup["ready"]=False
            self.warmup["last_error"]=f"{type(e).__name__}: {e}"
            log.exception("warmup failed")

    async def warmup_scheduler_loop(self):
        # Render Free cannot wake itself. Once an external HTTP ping starts the
        # service, this loop primes auth, stock master, news, and 08:00 discovery.
        while True:
            try:
                self._reset_warmup_day()
                dt=now_kst()
                hm=hhmm_value(dt)
                weekday=dt.weekday()<5
                if weekday and WARMUP_START_HM <= hm <= WARMUP_END_HM:
                    need=(
                        self.warmup["state"] in {"IDLE","ERROR","PARTIAL"}
                        or (hm>=WARMUP_MARKET_HM and not self.warmup["discovery"])
                    )
                    if need:
                        await self.run_warmup()
                elif weekday and hm > WARMUP_END_HM and self.warmup["state"]=="IDLE":
                    await self.run_warmup()
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("warmup scheduler")
            await asyncio.sleep(WARMUP_RETRY_SECONDS)

    async def refresh_stock_master(self,force:bool=False):
        if not force and self.stock_master_cache and time.time()-self.stock_master_at<MASTER_REFRESH_SECONDS:
            return

        ls_rows=[];err=""
        if not DEMO_MODE:
            try:
                ls_rows=await self.ls.stock_master()
            except Exception as e:
                err=f"{type(e).__name__}: {e}"
                log.warning("LS stock master failed: %s",e)

        real={m.code:m for m in ls_rows
              if isinstance(m,StockMeta) and len(m.code)==6 and valid_equity_name(m.name)}
        self.ls_master_count=len(real)
        self.master_ready=self.ls_master_count>=MASTER_READY_MIN
        self.master_error=err or self.ls.master_last_error

        if self.master_ready:
            scan_master=real;self.master_source="LS_FULL"
        elif real:
            scan_master=real;self.master_source="LS_PARTIAL"
        else:
            scan_master=dict(self.base);self.master_source="FALLBACK_15"

        self.stock_master_cache=scan_master
        self.stock_master_at=time.time()
        self.krx_discovery.set_scout_master(scan_master)
        self.nxt_discovery.set_scout_master(scan_master)
        self.krx_discovery.rebuild_precision()
        self.nxt_discovery.rebuild_precision()

    async def resolve_stock_name(self, name: str):
        q=re.sub(r"\s+","",name or "").lower()
        if not q:
            return {"status":"NOT_FOUND","matches":[]}
        await self.refresh_stock_master()
        rows=list(self.stock_master_cache.values())

        def norm(x):
            return re.sub(r"\s+","",x or "").lower()

        exact=[m for m in rows if norm(m.name)==q]
        if len(exact)==1:
            return {"status":"OK","meta":exact[0],"matches":[exact[0].name]}
        starts=[m for m in rows if norm(m.name).startswith(q)]
        contains=[m for m in rows if q in norm(m.name)]
        cand=[]
        seen=set()
        for m in exact+starts+contains:
            if m.code not in seen:
                cand.append(m); seen.add(m.code)
        if len(cand)==1:
            return {"status":"OK","meta":cand[0],"matches":[cand[0].name]}
        if cand:
            return {"status":"AMBIGUOUS","matches":[x.name for x in cand[:6]]}
        return {"status":"NOT_FOUND","matches":[]}

    def _micro_from_trades(self, rows: List[Dict[str,Any]]):
        if not rows:
            return {"chdegree":None,"buy_ratio":None,"price_momentum":0.0,
                    "trade_count":0,"net_volume":None}
        vals=[]
        for r in rows[:80]:
            vals.append({
                "price":abs(fnum(r.get("price"))),
                "chdegree":fnum(r.get("chdegree"),0),
                "mdvolume":fnum(r.get("mdvolume"),0),
                "msvolume":fnum(r.get("msvolume"),0),
                "revolume":fnum(r.get("revolume"),0),
            })
        valid=[x for x in vals if x["price"]>0]
        if not valid:
            return {"chdegree":None,"buy_ratio":None,"price_momentum":0.0,
                    "trade_count":0,"net_volume":None}
        newest=valid[0]; oldest=valid[-1]
        price_mom=(newest["price"]/oldest["price"]-1)*100 if oldest["price"] else 0.0
        chs=[x["chdegree"] for x in valid[:20] if x["chdegree"]>0]
        ch=sum(chs)/len(chs) if chs else newest["chdegree"]
        buy=max(0,newest["msvolume"]); sell=max(0,newest["mdvolume"])
        br=buy/(buy+sell) if buy+sell>0 else None
        return {
            "chdegree":round(ch,1) if ch is not None else None,
            "buy_ratio":round(br,3) if br is not None else None,
            "price_momentum":round(price_mom,2),
            "trade_count":len(valid),
            "net_volume":round(newest["revolume"],1),
        }

    def _entry_score(self, meta: StockMeta, quote: Dict[str,Any], micro: Dict[str,Any]):
        price=abs(fnum(quote.get("price")))
        diff=fnum(quote.get("diff"))
        high=abs(fnum(quote.get("high")))
        total_bid=fnum(quote.get("bid"))
        total_offer=fnum(quote.get("offer"))
        if total_bid+total_offer<=0:
            total_bid=sum(fnum(quote.get(f"bidrem{i}")) for i in range(1,11))
            total_offer=sum(fnum(quote.get(f"offerrem{i}")) for i in range(1,11))
        bid_ratio=total_bid/(total_bid+total_offer) if total_bid+total_offer>0 else None

        state=self.decision_states.get(meta.code)
        pre=float(state.pre_score) if state else 0.0
        cat,_=self.catalyst(meta)

        score=0.0
        why=[]

        score+=min(30,pre*0.30)
        if pre>=65: why.append(f"PRE {pre:.0f}")

        if bid_ratio is not None:
            if bid_ratio>=0.62:
                score+=16; why.append(f"매수호가 {bid_ratio*100:.0f}%")
            elif bid_ratio>=0.55:
                score+=11; why.append("매수호가 우위")
            elif bid_ratio>=0.48:
                score+=5
            elif bid_ratio<0.40:
                score-=5; why.append("매도호가 우위")

        ch=micro.get("chdegree")
        if ch is not None:
            if ch>=130:
                score+=18; why.append(f"체결강도 {ch:.0f}")
            elif ch>=115:
                score+=14; why.append(f"체결강도 {ch:.0f}")
            elif ch>=100:
                score+=8
            elif ch<80:
                score-=6; why.append(f"체결강도 약함 {ch:.0f}")

        br=micro.get("buy_ratio")
        if br is not None:
            if br>=0.58:
                score+=10; why.append("매수체결 우위")
            elif br>=0.52:
                score+=6
            elif br<0.42:
                score-=5; why.append("매도체결 우위")

        pm=float(micro.get("price_momentum") or 0)
        if pm>=0.7:
            score+=10; why.append(f"단기 +{pm:.1f}%")
        elif pm>=0.25:
            score+=6; why.append("단기 가격 가속")
        elif pm<=-0.7:
            score-=7; why.append(f"단기 {pm:.1f}%")

        if -1.0<=diff<=4.5:
            score+=12; why.append("과열 전 위치")
        elif -2.0<=diff<OVERHEAT_DAILY_PCT:
            score+=6

        if high and price and price>=high*0.97 and diff<OVERHEAT_DAILY_PCT:
            score+=5; why.append("당일고가 근접")

        if cat>=12:
            score+=9; why.append("뉴스 촉매 강함")
        elif cat>=6:
            score+=5; why.append("뉴스 촉매 확인")

        score=max(0,min(100,score))
        phase=market_phase()

        if diff>=OVERHEAT_DAILY_PCT:
            status="AVOID"
            verdict=f"당일 +{diff:.1f}% 과열 · 추격금지"
        elif not phase["active"]:
            status="WAIT"
            verdict="장 종료 · 다음 거래세션에서 실시간 ENTRY 재판정"
        elif score>=80:
            status="ENTRY"
            verdict="진입 가능 구간 · 실제 주문 전 호가 변화를 다시 확인"
        elif score>=68:
            status="PRE-BUY"
            verdict="진입 직전 후보 · 체결/호가 추가 확인"
        elif score>=55:
            status="WATCH"
            verdict="관찰 · 아직 진입 신호 부족"
        else:
            status="WAIT"
            verdict="대기 · 진입 조건 부족"

        return {
            "name":meta.name,"code":meta.code,
            "price":round(price,2),"diff_pct":round(diff,2),
            "entry_score":round(score,1),"status":status,"verdict":verdict,
            "why":why[:6],
            "metrics":{
                "pre_score":round(pre,1),
                "bid_ratio":round(bid_ratio,3) if bid_ratio is not None else None,
                "chdegree":micro.get("chdegree"),
                "buy_ratio":micro.get("buy_ratio"),
                "price_momentum":micro.get("price_momentum"),
                "catalyst":round(cat,1),
            },
            "market":phase,"updated_ts":time.time(),
        }

    async def decision_by_name(self, name: str):
        resolved=await self.resolve_stock_name(name)
        if resolved["status"]!="OK":
            return resolved
        meta=resolved["meta"]
        self.store.upsert_manual_watch(meta.code,meta.name)

        if DEMO_MODE:
            q=self.demo_quote(meta)
            quote={"hname":meta.name,"price":q.price,"diff":q.diff_pct,"volume":q.volume,
                   "bid":q.bid_qty*1.2,"offer":q.offer_qty*1.2,
                   "bidrem1":q.bid_qty,"offerrem1":q.offer_qty,
                   "high":q.high,"low":q.low}
            micro={"chdegree":112.0,"buy_ratio":0.54,"price_momentum":0.35,
                   "trade_count":20,"net_volume":1000}
        else:
            quote=await self.ls.quote(meta.code)
            rows=await self.ls.trades(meta.code)
            micro=self._micro_from_trades(rows)

        st=self.decision_states.get(meta.code)
        if not st:
            st=StockState(meta=meta,source="MANUAL")
            self.decision_states[meta.code]=st
        qobj=self.quote_from(quote)
        if qobj.price>0:
            st.history.append(qobj)
            self.score(st)

        result=self._entry_score(meta,quote,micro)
        self.decision_cache[meta.code]={"result":result,"micro":micro,"ts":time.time()}

        if result["status"]=="ENTRY" and result["price"]>0:
            last=self.last_manual_signal.get(meta.code,0)
            if time.time()-last>=3600:
                self.store.add_signal(meta.code,meta.name,result["price"],result["entry_score"],
                                      "MANUAL-ENTRY"," · ".join(result["why"]))
                self.last_manual_signal[meta.code]=time.time()

        return {"status":"OK","decision":result}

    async def decision_monitor_loop(self):
        while True:
            try:
                codes={clean_code(x["code"]) for x in self.store.manual_watch()}
                codes.update(clean_code(h["code"]) for h in self.store.holdings())
                codes.discard("")
                for code in list(codes)[:20]:
                    try:
                        if DEMO_MODE:
                            continue
                        rows=await self.ls.trades(code)
                        old=self.decision_cache.get(code,{})
                        old["micro"]=self._micro_from_trades(rows)
                        old["ts"]=time.time()
                        self.decision_cache[code]=old
                    except Exception:
                        continue
            except Exception:
                log.exception("decision monitor")
            await asyncio.sleep(60)

    def _rolling_return(self, st: StockState, seconds: int):
        if not st.history:
            return 0.0
        cur=st.history[-1]
        old=self.past(list(st.history),seconds)
        if not old or old.price<=0:
            return 0.0
        return (cur.price/old.price-1)*100

    def decision_watch_payload(self):
        holding_codes={clean_code(h["code"]) for h in self.store.holdings()}
        rows=[]
        for w in self.store.manual_watch():
            code=clean_code(w["code"])
            if not code or code in holding_codes:
                continue
            meta=self.meta_for(code)
            st=self.decision_states.get(code)
            cached=self.decision_cache.get(code) or {}
            d=cached.get("result")
            if st and st.history:
                q=st.history[-1]
                raw={
                    "price":q.price,"diff":q.diff_pct,"high":q.high,
                    "bidrem1":q.bid_qty,"offerrem1":q.offer_qty
                }
                d=self._entry_score(meta,raw,cached.get("micro") or {})
                cached["result"]=d
                cached["ts"]=time.time()
                self.decision_cache[code]=cached
            if d:
                rows.append({
                    "code":code,"name":d["name"],"price":d["price"],
                    "diff_pct":d["diff_pct"],"entry_score":d["entry_score"],
                    "status":d["status"],"why":d.get("why") or [],
                    "updated_sec":round(time.time()-float(d.get("updated_ts") or time.time()),1)
                })
            else:
                rows.append({
                    "code":code,"name":w["name"],"price":None,"diff_pct":None,
                    "entry_score":None,"status":"WAIT","why":["LS 판정 데이터 준비 중"],
                    "updated_sec":None
                })
        rows.sort(key=lambda x:(float(x.get("entry_score") or -1),x["name"]),reverse=True)
        return rows

    def delete_decision_watch(self, code: str):
        code=clean_code(code)
        self.store.delete_manual_watch(code)
        self.decision_cache.pop(code,None)
        # Keep StockState if it is a holding; otherwise release it from memory.
        holding_codes={clean_code(h["code"]) for h in self.store.holdings()}
        if code not in holding_codes:
            self.decision_states.pop(code,None)

    def holdings_payload(self):
        out=[]
        for h in self.store.holdings():
            c=clean_code(h["code"]); st=self.decision_states.get(c)
            if not st or not st.history:
                out.append({
                    "code":c,"name":h["name"],"buy_price":h["buy_price"],"qty":h["qty"],
                    "price":None,"return_pct":None,"risk":None,"verdict":"NO DATA",
                    "why":["LS 시세 대기"]
                })
                continue

            q=st.history[-1]
            peak=max(float(h["peak_price"]),q.price)
            ret=(q.price/float(h["buy_price"])-1)*100
            dd=(q.price/peak-1)*100 if peak else 0.0
            r3=self._rolling_return(st,180)
            r10=self._rolling_return(st,600)
            micro=(self.decision_cache.get(c) or {}).get("micro") or {}
            ch=micro.get("chdegree")
            br=micro.get("buy_ratio")

            risk=15.0
            why=[]

            if ret<=-6:
                risk+=38; why.append("초기 손절선 이탈")
            elif ret<=-3:
                risk+=18; why.append("매입가 대비 약세")

            if dd<=-8:
                risk+=30; why.append(f"고점대비 {dd:.1f}%")
            elif dd<=-5:
                risk+=20; why.append(f"고점대비 {dd:.1f}%")
            elif dd<=-3:
                risk+=10; why.append("고점 후퇴")

            if r3<=-0.8:
                risk+=12; why.append(f"3분 {r3:.1f}%")
            if r10<=-1.5:
                risk+=10; why.append(f"10분 {r10:.1f}%")

            if ch is not None:
                if ch<80:
                    risk+=10; why.append(f"체결강도 {ch:.0f}")
                elif ch<95:
                    risk+=5

            if br is not None and br<0.42:
                risk+=8; why.append("매도체결 우위")

            if st.pre_score<45:
                risk+=8; why.append("PRE 약화")
            if q.diff_pct<-2:
                risk+=6

            if ret>=20 and dd<=-8:
                risk+=18; why.append("+20% 이후 되돌림")
            elif ret>=10 and dd<=-5:
                risk+=12; why.append("+10% 이후 되돌림")

            risk=max(0,min(100,risk))
            verdict="HOLD" if risk<40 else "CAUTION" if risk<65 else "REDUCE" if risk<82 else "EXIT"
            if not why:
                why=["추세/수급 위험 낮음"]

            out.append({
                "code":c,"name":h["name"],"buy_price":round(float(h["buy_price"]),2),
                "qty":h["qty"],"price":round(q.price,2),
                "return_pct":round(ret,2),"drawdown_pct":round(dd,2),
                "risk":round(risk,1),"verdict":verdict,"why":why[:5],
                "metrics":{"pre_score":st.pre_score,"r3":round(r3,2),"r10":round(r10,2),
                           "chdegree":ch,"buy_ratio":br}
            })
        return out

    async def outcome_loop(self):
        checkpoints=[("30M",1800),("1D",86400),("3D",259200),("5D",432000)]
        while True:
            try:
                for sig in self.store.recent_signals(300):
                    s=self.krx_states.get(sig["code"]) or self.nxt_states.get(sig["code"]) or self.decision_states.get(sig["code"])
                    if not s or not s.history:continue
                    p=s.history[-1].price; age=time.time()-float(sig["signal_ts"])
                    for label,sec in checkpoints:
                        if age>=sec and not self.store.has_outcome(sig["id"],label):
                            self.store.add_outcome(sig["id"],label,p,(p/float(sig["signal_price"])-1)*100)
            except Exception:
                log.exception("outcome")
            await asyncio.sleep(60)

    def news_payload(self):
        self.news.prune()
        rows=[];all_states=[st for st in list(self.krx_states.values())+list(self.nxt_states.values()) if st.meta.name]
        by_name={st.meta.name:st for st in all_states};seen_ids=set()
        core=sorted(list(self.news.items),key=lambda x:(float(x.get("ts",0)),float(x.get("quality",0))),reverse=True)
        supplement=sorted(list(self.news.secondary),key=lambda x:(float(x.get("ts",0)),float(x.get("quality",0))),reverse=True)
        for item in core+supplement:
            if item.get("id") in seen_ids:continue
            if time.time()-float(item.get("ts",0))>NEWS_DISPLAY_AGE_HOURS*3600:continue
            seen_ids.add(item.get("id"));x=dict(item);candidates=[]
            for name in item.get("direct_stocks",[]):
                st=by_name.get(name);candidates.append((name,st,100.0))
            sectors=set(item.get("sectors",[]));already={c[0] for c in candidates}
            for st in all_states:
                if st.meta.name in already:continue
                if st.meta.sector in sectors:candidates.append((st.meta.name,st,float(st.pre_score)+max(0,float(st.delta_score))))
            candidates.sort(key=lambda z:z[2],reverse=True);linked=[]
            for name,st,_ in candidates[:3]:
                if st and st.history:
                    reaction="LS PRE-BUY" if st.status=="PRE-BUY" else ("LS BUILDING" if st.status=="BUILDING" else "시장반응 대기")
                    linked.append({"name":name,"reaction":reaction,"pre_score":st.pre_score})
                else:linked.append({"name":name,"reaction":"시장반응 대기","pre_score":None})
            x["linked"]=linked;x["age_sec"]=max(0,round(time.time()-float(x.get("ts",time.time()))))
            rows.append(x)
            if len(rows)>=NEWS_DISPLAY_MAX:break
        return rows

    def tracking_health(self,market:str):
        now=time.time();disc=self.lane_discovery(market);states=self.lane_states(market)
        tracked=list(disc.precision_codes)[:MAX_PRECISION]
        ready5=0;with_history=0;fresh=0;ages=[]
        for c in tracked:
            st=states.get(c)
            if not st or not st.history:continue
            with_history+=1
            elapsed=st.history[-1].ts-st.history[0].ts
            ages.append(elapsed)
            if elapsed>=TRACKING_READY_SECONDS:ready5+=1
            if now-st.history[-1].ts<=max(60,POLL_SECONDS*3):fresh+=1
        return {"tracked":len(tracked),"withHistory":with_history,"ready5":ready5,"fresh":fresh,
                "minHistorySec":round(min(ages),1) if ages else None,
                "maxHistorySec":round(max(ages),1) if ages else None,
                "generation":disc.tracking_generation,"replacements":disc.tracking_replacements,
                "lastChangeSec":round(now-disc.tracking_last_change,1) if disc.tracking_last_change else None,
                "passes":self.tracking_passes[market],"quoteOk":self.tracking_quote_ok[market],
                "priceChanges":self.tracking_price_changes[market],
                "busy":self.tracking_busy[market],
                "lastPassSec":round(now-self.tracking_last_pass_end[market],1) if self.tracking_last_pass_end[market] else None}
    def health(self):
        now=time.time();ph=market_phase()
        if DEMO_MODE:lsstate="DEMO";age=None
        elif self.ls.last_ok and now-self.ls.last_ok<max(90,POLL_SECONDS*4):
            lsstate="CONNECTED";age=round(now-self.ls.last_ok,1)
        elif self.ls.last_ok:
            lsstate="STALE";age=round(now-self.ls.last_ok,1)
        else:
            lsstate="ERROR" if self.ls.last_error or self.tm.last_error else "CONNECTING";age=None
        nfresh=self.news.freshness()
        nstate=nfresh["state"] if not DEMO_MODE else "DEMO"
        def dh(d):
            return {"state":d.status,"rawCandidates":d.raw_count,"precision":len(d.precision_codes),
                    "candidateCap":MAX_CANDIDATES,"precisionCap":MAX_PRECISION,
                    "conditions":len(d.condition_indexes),"fullMaster":len(getattr(d,"full_master",[])),
                    "activeUniverse":len(d.scout_master),"activeUniverseMax":ACTIVE_UNIVERSE_MAX,
                    "background":len(getattr(d,"background_master",[])),
                    "backgroundSeen":getattr(d,"background_seen",0),
                    "backgroundPromoted":getattr(d,"background_promoted",0),
                    "scoutSeen":d.scout_seen,"scoutPasses":d.scout_passes,"scoutCursor":d.scout_cursor,
                    "scoutError":d.scout_error,"error":d.last_error}
        return {"ok":True,"ready":bool(self.warmup.get("ready")),"version":APP_VERSION,
                "mode":"DEMO" if DEMO_MODE else "LIVE","market":ph,
                "master":{"ready":self.master_ready,"source":self.master_source,"lsCount":self.ls_master_count,
                          "scanCount":len(self.stock_master_cache),"readyMin":MASTER_READY_MIN,
                          "rawRows":self.ls.master_raw_rows,"validRows":self.ls.master_valid_rows,
                          "attempts":list(self.ls.master_attempts),"error":self.master_error},
                "ls":{"state":lsstate,"lastDataSec":age,"error":self.ls.last_error or self.tm.last_error},
                "news":{"state":nstate,"count":len(self.news.items)+len(self.news.secondary),
                        "display":len(self.news_payload()),"freshness":nfresh,
                        "feedSuccess":self.news.feed_success,"error":self.news.last_error},
                "db":{"state":"OK","persistent":DATABASE_URL.startswith("postgres"),
                      "storageMode":"SERVER_PERSISTENT" if DATABASE_URL.startswith("postgres") else "LOCAL_SQLITE+DEVICE_BACKUP",
                      "occurrenceMode":"INSERT_ONLY","rankSnapshotOverwriteActive":False,"signalMemorySelectionActive":False},
                "morningCoreSpec":{"source":"v1.2.1-components+5min-timing","scoreComponentsUnchanged":True,
                      "preBuy":PREBUY_THRESHOLD,"building":BUILDING_THRESHOLD,"watch":WATCH_THRESHOLD,
                      "minMinutes":MIN_READY_MINUTES,"deltaLookbackSec":DELTA_LOOKBACK_SECONDS,
                      "ignitingDelta":IGNITING_DELTA_MIN},
                "krx":{"active":self.lane_active("KRX",ph),"source":"t1101","states":len(self.krx_states),
                       "lastScanSec":round(now-self.last_scan["KRX"],1) if self.last_scan["KRX"] else None,
                       "discovery":dh(self.krx_discovery)},
                "nxt":{"active":self.lane_active("NXT",ph),"source":"t8450","states":len(self.nxt_states),
                       "lastScanSec":round(now-self.last_scan["NXT"],1) if self.last_scan["NXT"] else None,
                       "discovery":dh(self.nxt_discovery),
                       "feed":{"lastOkSec":round(now-self.nxt_integrated_last_ok,1) if self.nxt_integrated_last_ok else None,
                               "success":self.nxt_integrated_success,"zero":self.nxt_integrated_zero,
                               "volumePositive":self.nxt_volume_positive,"volumeChanged":self.nxt_volume_changed,
                               "parserVolumeChanges":self.ls.integrated_volume_changes,
                               "volumeFields":dict(self.ls.integrated_volume_field_counts),"error":self.nxt_integrated_error}},
                "warmup":dict(self.warmup),"uptimeSec":int(now-self.started)}

    def state(self):
        return {"health":self.health(),**self.ranked_views(),
                "decisionWatch":self.decision_watch_payload(),
                "holdings":self.holdings_payload(),
                "news":self.news_payload(),"performance":self.store.performance(),
                "serverTime":now_kst().isoformat()}

def load_base():
    rows=[]
    p=DATA_DIR/"watchlist.csv"
    if p.exists():
        for line in p.read_text("utf-8").splitlines()[1:]:
            if not line.strip():continue
            parts=[x.strip() for x in line.split(",",2)]
            if len(parts)>=2:rows.append(StockMeta(parts[0],parts[1],parts[2] if len(parts)>2 else "기타"))
    return rows

store=Store(DATABASE_URL)
nova=Nova(load_base(),store)

@asynccontextmanager
async def lifespan(app:FastAPI):
    await nova.start()
    yield
    await nova.stop()

app=FastAPI(title="NOVA PRE-IGNITION",version=APP_VERSION,lifespan=lifespan)

@app.get("/")
async def root(request:Request):
    if APP_ACCESS_TOKEN and not is_authorized(request):
        supplied=request.query_params.get("token","")
        if supplied and hmac.compare_digest(supplied,APP_ACCESS_TOKEN):
            resp=FileResponse(STATIC_DIR/"index.html")
            resp.set_cookie("nova_session",session_value(),httponly=True,secure=True,samesite="lax",max_age=2592000)
            return resp
        return FileResponse(STATIC_DIR/"login.html")
    return FileResponse(STATIC_DIR/"index.html")

@app.post("/auth/login")
async def login(body:LoginIn):
    if not APP_ACCESS_TOKEN:return {"ok":True}
    if not hmac.compare_digest(body.token,APP_ACCESS_TOKEN):
        raise HTTPException(status_code=401,detail="invalid access token")
    resp=JSONResponse({"ok":True})
    resp.set_cookie("nova_session",session_value(),httponly=True,secure=True,samesite="lax",max_age=2592000)
    return resp

@app.get("/healthz")
async def healthz():
    return {
        "ok":True,
        "version":APP_VERSION,
        "market":market_phase()["code"],
        "warmup":nova.warmup.get("state"),
        "warmupReady":bool(nova.warmup.get("ready")),
    }

@app.get("/health")
async def health():return {"ok":True,"version":APP_VERSION}

@app.get("/api/health")
async def api_health(request:Request):
    require_auth(request);return nova.health()

@app.get("/api/state")
async def api_state(request:Request):
    require_auth(request);return nova.state()

@app.post("/api/decision")
async def decision(body:DecisionNameIn,request:Request):
    require_auth(request)
    return await nova.decision_by_name(body.name)

@app.delete("/api/decision/{code}")
async def delete_decision(code:str,request:Request):
    require_auth(request)
    nova.delete_decision_watch(code)
    return {"ok":True}

@app.post("/api/holdings")
async def add_holding(h:HoldingIn,request:Request):
    require_auth(request);store.upsert_holding(h);return {"ok":True}

@app.delete("/api/holdings/{code}")
async def delete_holding(code:str,request:Request):
    require_auth(request);store.delete_holding(code);return {"ok":True}

@app.get("/api/signals")
async def signals(request:Request):
    require_auth(request);return {"items":store.recent_signals(100)}

@app.get("/api/performance")
async def performance(request:Request):
    require_auth(request);return store.performance()

@app.get("/api/occurrences")
async def occurrences(request:Request,limit:int=100,market:str=""):
    require_auth(request)
    limit=max(1,min(500,limit))
    if market.upper() in {"KRX","NXT"}:
        return store.occurrence_market(market.upper(),limit)
    return store.occurrence_recent(limit)

@app.get("/api/debug/nxt-feed")
async def debug_nxt_feed(request:Request):
    require_auth(request)
    return {
        "version":APP_VERSION,
        "market":market_phase(),
        "tr":"t8450",
        "lastSample":dict(nova.ls.integrated_last_sample),
        "volumeFields":dict(nova.ls.integrated_volume_field_counts),
        "parserVolumeChanges":nova.ls.integrated_volume_changes,
        "priceOk":nova.ls.integrated_price_ok,
        "volumeOk":nova.ls.integrated_volume_ok,
    }
